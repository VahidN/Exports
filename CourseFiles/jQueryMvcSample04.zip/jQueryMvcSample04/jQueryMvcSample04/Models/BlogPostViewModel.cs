﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace jQueryMvcSample04.Models
{
    public class BlogPostViewModel
    {
        [DisplayName("عنوان"), Required(ErrorMessage = "*")]
        public string Title { set; get; }

        [DisplayName("متن"), Required(ErrorMessage = "*")]
        public string Body { set; get; }

        /// <summary>
        /// آرايه‌اي محدود از برچسب‌هاي اين مطلب خاص به صورت جي‌سون كه پيشتر ثبت شده است
        /// هدف استفاده در حين ويرايش مطلب
        /// </summary>
        public string InitialTags { set; get; }

        /// <summary>
        /// آرايه‌اي جي‌سوني از تمام برچسب‌هاي موجود در سيستم
        /// هدف نمايش منوي انتخاب برچسب‌ها از ليست
        /// </summary>
        public string TagsSource { set; get; }

        /// <summary>
        /// آرايه‌اي از برچسب‌هاي وارد شده توسط كاربر در حين ثبت مطلب
        /// </summary>
        [DisplayName("برچسب‌ها"), Required(ErrorMessage = "*")]
        public string[] Tags { set; get; }

        public int? Id { set; get; }
    }
}