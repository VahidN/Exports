﻿using Microsoft.AspNet.SignalR;
using Microsoft.AspNet.SignalR.Hubs;

namespace SignalR02
{
    [HubName("chat")]
    public class ChatHub : Hub
    {
        public void SendMessage(string message)
        {
            var msg = string.Format("{0}:{1}", Context.ConnectionId, message);
            Clients.All.hello(msg);

            //اين دو عبارت هر دو يكي هستند
            /*Clients.Caller.hello(msg);
            Clients.Client(Context.ConnectionId).hello(msg);

            Clients.Others.hello(msg);*/

            //Clients.AllExcept(
        }

        public void JoinRoom(string room)
        {
            this.Groups.Add(Context.ConnectionId, room);
        }

        public void SendMessageToRoom(string room, string msg)
        {
            this.Clients.Group(room).newMesssgae(msg);
        }

        public override System.Threading.Tasks.Task OnDisconnected()
        {
            sendMonitorData("OnDisconnected", Context.ConnectionId);
            return base.OnDisconnected();
        }

        private void sendMonitorData(string type, string connection)
        {
            //var ctx = GlobalHost.ConnectionManager.GetHubContext<MonitorHub>();
            //ctx.Clients.All.newEvenet(type, connection);
        }
    }
}