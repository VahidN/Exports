namespace Sample02.Models
{
    public class UserViewModel
    {
        public int Id { set; get; }
        public string Name { set; get; }
        public string RegistrationDate { set; get; }
    }
}