﻿using System;
using System.Reflection;

namespace FastReflectionTests.FastReflection
{
    public class GetterInfo
    {
        public string Name { set; get; }
        public Func<object, object> GetterFunc { set; get; }
        public Type PropertyType { set; get; }
        public MemberInfo MemberInfo { set; get; }
    }
}