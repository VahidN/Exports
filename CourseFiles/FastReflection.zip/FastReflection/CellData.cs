﻿using System.Diagnostics;

namespace FastReflectionTests.FastReflection
{
    /// <summary>
    /// A class to hold data of the main table's cells
    /// </summary>    
    [DebuggerDisplay("{PropertyIndex} - {PropertyName} - {PropertyValue}")]
    public class CellData
    {
        /// <summary>
        /// Property index of the current cell
        /// </summary>
        public int PropertyIndex { set; get; }

        /// <summary>
        /// Property name of the current cell
        /// </summary>
        public string PropertyName { set; get; }

        /// <summary>
        /// Property value of the current cell
        /// </summary>
        public object PropertyValue { set; get; }
    }
}