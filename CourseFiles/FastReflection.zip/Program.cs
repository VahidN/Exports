﻿using System;
using System.Collections.Generic;
using FastReflectionTests.FastReflection;

namespace FastReflectionTests
{
    public class User
    {
        public int Id { set; get; }
        public string Name { set; get; }
        public Address Address { set; get; }
    }

    public class Address
    {
        public string Address1 { set; get; }
        public string Address2 { set; get; }
    }

    class Program
    {
        static void Main(string[] args)
        {

            // كار با يك شيء بي‌نام
            var data = new
            {
                Id = 1,
                Name = 3,
                Test = new
                {
                    Title = "Test"
                }
            };
            var results = new DumpNestedProperties().DumpPropertyValues(data, dumpLevel: 2);
            foreach (var result in results)
            {
                Console.WriteLine(result.PropertyName + " -> " + result.PropertyValue);
            }


            // كار با يك ليست جنريك تو در تو
            var list = new List<User>();
            for (int i = 0; i < 100; i++)
            {
                list.Add(new User
                {
                    Id = i+1,
                    Name = "name "+i,
                    Address = new Address
                    {
                        Address1 = "Addr1- "+i,
                        Address2 = "Addr2- "+i
                    }
                });
            }
            foreach (var item in list)
            {
                var propertyValues = new DumpNestedProperties().DumpPropertyValues(item, dumpLevel: 2);
                foreach (var result in propertyValues)
                {
                    Console.WriteLine(result.PropertyName + " -> " + result.PropertyValue);
                }
                Console.WriteLine();
            }



            Console.WriteLine("Press a key");
            Console.Read();
        }
    }
}
