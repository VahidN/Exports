﻿namespace WebApiDISample.Services
{
    public interface IEmailsService
    {
        void SendEmail();
    }
}