﻿using System;
using System.Net;
using System.Threading.Tasks;

namespace Async03DotNet4
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var webClient = new WebClient())
            {
                webClient.Headers.Add("User-Agent", "AsyncContext 1.0");
                var data = webClient.DownloadStringTaskAsync("http://www.dotnettips.info").Result;
                Console.WriteLine(data);
            }

            Console.WriteLine("Press a key to terminate.");
            Console.ReadKey();
        }

        private static async Task<string> doWorkAsync()
        {
            return await new WebClient().DownloadStringTaskAsync("http://www.google.com");
        }
    }
}
