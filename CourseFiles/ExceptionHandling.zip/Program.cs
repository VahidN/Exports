﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                BusinessMethod();
            }
            catch ( Exception e )
            {
                Console.WriteLine(e.ToString());
            }
        }

        [WrapException]
        static void BusinessMethod()
        {
            int i = 0;
            int k = 1;
            int l = k/i;
        }
    }
}
