﻿using System;
using System.Diagnostics;
using System.Reflection;
using PostSharp.Aspects;

namespace ExceptionHandling
{
    [Serializable]
    public sealed class WrapExceptionAttribute : OnExceptionAspect
    {
        [NonSerialized] private readonly Type exceptionType;

        public WrapExceptionAttribute()
        {
        }

        public WrapExceptionAttribute( Type exceptionType )
        {
            this.exceptionType = exceptionType;
        }

        public override Type GetExceptionType( MethodBase targetMethod )
        {
            return this.exceptionType;
        }

        public override void OnException( MethodExecutionArgs args )
        {
            // Create a unique identifier for this exception.
            Guid guid = Guid.NewGuid();

            // Trace the exception to log.
            Trace.TraceError( "Exception {0}: {1}", guid, args.Exception );


            // Replace the exception by a BusinessException.
            args.Exception =
                new BusinessException( string.Format( "An unexpected error has occurred. Please contact the system administrator and report the number {0}.",
                                                      guid ) );
            args.FlowBehavior = FlowBehavior.ThrowException;
        }
    }
}