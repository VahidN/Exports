﻿using System;

namespace Sample03.Models
{
    public class User
    {
        public int Id { set; get; }
        public string Name { set; get; }
        public DateTime RegistrationDate { set; get; }
    }
}