﻿using System.ComponentModel.DataAnnotations;

namespace RavenDB25Mvc4Sample.Models
{
    public class User
    {
        public string Id { set; get; }

        [Required]
        public string Name { set; get; }
    }
}