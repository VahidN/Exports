﻿using System;
using System.Threading;
using WebFormsSample03.Common;

namespace WebFormsSample03
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }        
    }
}