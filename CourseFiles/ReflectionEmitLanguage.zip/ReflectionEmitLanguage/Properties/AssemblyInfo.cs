﻿// Assembly Reflector.ReflectionEmitLanguage, Version 1.0.0.0

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]
[assembly: System.Runtime.InteropServices.ComVisible(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Diagnostics.Debuggable(true, true)]
[assembly: System.Reflection.AssemblyFileVersion("1.0.0.0")]
[assembly: System.Runtime.InteropServices.Guid("8bdef441-f150-4ea4-8acd-8df6fdc46e37")]
[assembly: System.Reflection.AssemblyCompany("Jonathan de Halleux")]
[assembly: System.Reflection.AssemblyTitle("Reflection.Emit Language for Reflector")]
[assembly: System.Reflection.AssemblyProduct("ReflectionEmitLanguage")]
[assembly: System.Reflection.AssemblyCopyright("Copyright \x00a9 Jonathan de Halleux 2007")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("")]

