﻿using System.Windows.Forms;

namespace WinFormsIoc
{
    public partial class Form3 : Form
    {
        public Form3()
        {
            InitializeComponent();
        }
    }
}