﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Castle.DynamicProxy;
using StructureMap;
using System.Diagnostics;

namespace Test_ExceptionAspect
{
    class Program
    {
        static void Main(string[] args)
        {
            ObjectFactory.Initialize(x =>
            {
                x.Scan(scan =>
                {
                    scan.TheCallingAssembly();
                    scan.WithDefaultConventions();
                });

                var proxyGenerator = new ProxyGenerator();
                x.For<IMyMath>().EnrichAllWith(r => proxyGenerator.CreateInterfaceProxyWithTargetInterface(r, new ExceptionAspect()));
            });

            var obj = ObjectFactory.GetInstance<IMyMath>();
            //var result = obj.Divide(5, 3);
            var result = obj.Divide(5, 0);
            Console.WriteLine("Result: " + result );

            Console.ReadKey();
        }
    }

    public interface IMyMath
    {
        double Divide(double a, double b);
    }

    public class MyMath : IMyMath
    {
        public double Divide(double a, double b)
        {
            return a / b;
        }
    }

    public class ExceptionAspect : IInterceptor
    {
        public void Intercept(IInvocation invocation)
        {
            try
            {
                invocation.Proceed();
                Console.WriteLine("In Exception Aspect : Calculated Successfully.");
            }
            catch (Exception ex)
            {
                Console.WriteLine("In Exception Aspect : error occured at => " + DateTime.Now);
                Console.WriteLine("\n" + ex.Message);
            }
        }
    }
}
