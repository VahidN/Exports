namespace Sample04.Models
{
    public abstract class BaseEntity
    {
        public int Id { set; get; }
    }
}