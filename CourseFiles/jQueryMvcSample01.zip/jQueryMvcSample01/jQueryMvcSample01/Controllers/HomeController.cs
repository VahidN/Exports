﻿using System.Web.Mvc;
using jQueryMvcSample01.Models;
using jQueryMvcSample01.Security;

namespace jQueryMvcSample01.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View(); //نمايش فرم
        }

        [HttpPost]
        [AjaxOnly] //فقط در حالت اي‌جكس قابل دسترسي باشد
        [ValidateAntiForgeryToken]
        public ActionResult Index(User user)
        {
            if (this.ModelState.IsValid)
            {
                // ذخيره سازي در بانك اطلاعاتي ...
                System.Threading.Thread.Sleep(3000);

                return Content("ok");//اعلام موفقيت آميز بودن كار
            }

            return Content(null);//ارسال خطا
        }
    }
}