﻿using System.Collections.Generic;
using jQueryMvcSample05.Models;

namespace jQueryMvcSample05.DataSource
{
    /// <summary>
    /// يك منبع داده فرضي جهت دموي ساده‌تر برنامه
    /// </summary>
    public static class SurveysDataSource
    {
        private static IList<Survey> _surveysCache;
        static SurveysDataSource()
        {
            _surveysCache = createSurveys();
        }

        public static IList<Survey> SystemSurveys
        {
            get { return _surveysCache; }
        }

        private static IList<Survey> createSurveys()
        {
            var results = new List<Survey>();
            for (int i = 1; i < 6; i++)
            {
                results.Add(new Survey
                {
                    Id = i,
                    Title = "نظر سنجي " + i,
                    SurveyItems = new List<SurveyItem>
                    {
                       new SurveyItem{ Id = 1, SurveyId = i, Title = "گزينه 1", Order = 1 },
                       new SurveyItem{ Id = 2, SurveyId = i, Title = "گزينه 2", Order = 2 },
                       new SurveyItem{ Id = 3, SurveyId = i, Title = "گزينه 3", Order = 3 },
                       new SurveyItem{ Id = 4, SurveyId = i, Title = "گزينه 4", Order = 4 }
                    }
                });
            }
            return results;
        }
    }
}