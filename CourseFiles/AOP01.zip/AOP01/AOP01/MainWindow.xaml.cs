﻿using AOP01.ViewModels;
using StructureMap;

namespace AOP01
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();

            //علاوه بر تشكيل پروكسي
            //كار وهله سازي و تزريق وابستگي‌ها در سازنده را هم به صورت خودكار انجام مي‌دهد
            var vm = ObjectFactory.GetInstance<TestViewModel>(); 
            this.DataContext = vm;
        }
    }
}