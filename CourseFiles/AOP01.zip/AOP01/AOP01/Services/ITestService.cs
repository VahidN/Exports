﻿
namespace AOP01.Services
{
    public interface ITestService
    {
        int GetCount();
    }
}
