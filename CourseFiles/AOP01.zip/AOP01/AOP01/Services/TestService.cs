﻿
namespace AOP01.Services
{
    public class TestService: ITestService
    {     
        public int GetCount()
        {
            return 10; //اين فقط يك مثال است براي بررسي تزريق وابستگي‌ها
        }
    }
}