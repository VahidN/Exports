﻿var posts = [
  {
      id: '1',
      title: "Getting Started with Ember.js",
      body: "Bla bla bla 1."
  },
  {
      id: '3',
      title: "Controllers",
      body: "Bla bla bla 3."
  },
  {
      id: '2',
      title: "Routes and Templates",
      body: "Bla bla bla 2."
  }
];

var comments = [
    {
        id: '1',
        postId: '3',
        text: 'Thanks!'
    },
    {
        id: '2',
        postId: '3',
        text: 'Good to know that!'
    },
    {
        id: '3',
        postId: '1',
        text: 'Great!'
    }
];
