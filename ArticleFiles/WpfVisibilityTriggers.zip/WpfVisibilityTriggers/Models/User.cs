﻿namespace WpfVisibilityTriggers.Models
{
    public class User
    {
        public string Name { set; get; }
        public int Rating { set; get; }
    }
}