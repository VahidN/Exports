﻿using System;
using System.Collections.Generic;
using WpfVisibilityTriggers.Models;

namespace WpfVisibilityTriggers
{
    public class MainWindowViewModel
    {
        public IList<User> Users { set; get; }

        public MainWindowViewModel()
        {
            var rnd = new Random();

            Users = new List<User>();
            for (var i = 1; i <= 100; i++)
            {
                Users.Add(new User
                {
                    Rating = rnd.Next(0, 3),
                    Name = "User " + i
                });
            }
        }
    }
}