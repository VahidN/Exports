﻿namespace WpfVisibilityTriggers
{
    public partial class App
    {
    }
}