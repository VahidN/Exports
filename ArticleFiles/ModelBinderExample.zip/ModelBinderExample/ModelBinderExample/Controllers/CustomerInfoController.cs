﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using ModelBinderExample.CustomModelBinder;
using ModelBinderExample.Models;

namespace ModelBinderExample.Controllers
{
    public class CustomerInfoController : Controller
    {
        //
        // GET: /CustomerInfo/

        [HttpGet]
        public ActionResult Create()
        {
            FillList();

            return View();
        }

        private void FillList()
        {
            var years = new List<SelectListItem>();
            for (int i = 1350; i <= 1392; i++)
            {
                years.Add(new SelectListItem {Text = i.ToString(), Value = i.ToString()});
            }

            var Month = new List<SelectListItem>();
            Month.Add(new SelectListItem {Text = "فروردین", Value = "1"});
            Month.Add(new SelectListItem {Text = "اردیبهشت", Value = "2"});
            Month.Add(new SelectListItem {Text = "خرداد", Value = "3"});
            Month.Add(new SelectListItem {Text = "تیر", Value = "4"});
            Month.Add(new SelectListItem {Text = "مرداد", Value = "5"});
            Month.Add(new SelectListItem {Text = "شهریور", Value = "6"});
            Month.Add(new SelectListItem {Text = "مهر", Value = "7"});
            Month.Add(new SelectListItem {Text = "آبان", Value = "8"});
            Month.Add(new SelectListItem {Text = "آذر", Value = "9"});
            Month.Add(new SelectListItem {Text = "دی", Value = "10"});
            Month.Add(new SelectListItem {Text = "بهمن", Value = "11"});
            Month.Add(new SelectListItem {Text = "اسفند", Value = "12"});

            var monthList = new SelectList(Month, "Value", "Text");
            ViewBag.monthList = monthList;

            var yearsList = new SelectList(years, "Value", "Text");
            ViewBag.yearsList = yearsList;
        }

        [HttpPost]
        public ActionResult Create([ModelBinder(typeof (CustomerInfoModelBinder))] CustomerInfo customerInfo)
        {
            if (ModelState.IsValid)
            {
                ViewBag.FirstName = customerInfo.FirstName;
                ViewBag.LastName = customerInfo.LastName;
                ViewBag.BirthDate = customerInfo.BirthDate;

                FillList();
            }
            return View();
        }

    }
}
