52 pluralsight courses
NO ........ VIDEOS
ONLY ........ SUBTITLES and COURSE MATERIALS (slides and code files)

exercises probably already downloaded
advanced analysis services
advanced windows debugging - part 1
advanced windows debugging - part 2
analysis services fundamentals
android programming with intents
angularjs fundamentals
backbone.js fundamentals
creating n-tier applications in c#, part 1
creating n-tier applications in c#, part 2
creating powershell modules
cross platform game development with monogame
data layer validation with entity framework 4.1+
enterprise library caching application block
enterprise library data access application block
enterprise library exception handling application block
enterprise library overview
enterprise library security and cryptography application blocks
enterprise library validation application block
entity framework code first migrations
entity framework in the enterprise
everyday powershell for developers
extending powershell
force.com for developers
formatting with powershell
generating html5 layouts using photoshop
html5 canvas fundamentals
introduction to .net debugging using visual studio 2010
introduction to node.js
introduction to visual studio 2012 - part 1
introduction to visual studio 2012 - part 2
javascript design patterns
javascript for c# developers
linq data access
linq fundamentals
monotouch with xcode 4 and ios 5
node on windows and azure
photoshop for technical drawings
powershell and sql server
practical phonegap
raspberry pi for developers
reporting services report development fundamentals - part 1
sql server - collecting and analyzing trace data
sql server - common performance issue patterns
sql server - deadlock analysis and prevention
sql server - introduction to extended events
sql server - transact-sql basic data modification
sql server - transact-sql basic data retrieval
testing clientside javascript
top 10 cool powershell v3 features with windows server 2012
using servicestack to build apis
web development with expressjs
what's new in powershell version 3