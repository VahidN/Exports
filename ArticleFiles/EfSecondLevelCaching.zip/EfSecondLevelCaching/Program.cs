﻿using System;
using System.Data.Entity;
using System.Linq;
using EfSecondLevelCaching.Core;
using EfSecondLevelCaching.Test.DataLayer;
using EfSecondLevelCaching.Test.Models;

namespace EfSecondLevelCaching
{
    public static class TestUsages
    {
        public static void RunQueries()
        {
            using (ProductContext context = new ProductContext())
            {
                var isActive = true;
                var name = "Product1";

                // reading from db
                var list1 = context.Products
                                   .OrderBy(one => one.ProductNumber)
                                   .Where(x => x.IsActive == isActive && x.ProductName == name)
                                   .ToCacheableList();

                // reading from cache
                var list2 = context.Products
                                   .OrderBy(one => one.ProductNumber)
                                   .Where(x => x.IsActive == isActive && x.ProductName == name)
                                   .ToCacheableList();

                // reading from cache
                var list3 = context.Products
                                   .OrderBy(one => one.ProductNumber)
                                   .Where(x => x.IsActive == isActive && x.ProductName == name)
                                   .ToCacheableList();

                // reading from db
                var list4 = context.Products
                                   .OrderBy(one => one.ProductNumber)
                                   .Where(x => x.IsActive == isActive && x.ProductName == "Product2")
                                   .ToCacheableList();
            }

            // removes products cache
            using (ProductContext context = new ProductContext())
            {
                var p = new Product()
                {
                    IsActive = false,
                    ProductName = "P4",
                    ProductNumber = "004"
                };
                context.Products.Add(p);
                context.SaveChanges();
            }

            using (ProductContext context = new ProductContext())
            {
                var data = context.Products.AsQueryable().Cacheable(x => x.FirstOrDefault());
                var data2 = context.Products.AsQueryable().Cacheable(x => x.FirstOrDefault());
                context.SaveChanges();
            }
        }

        public static void InsertData()
        {
            using (ProductContext context = new ProductContext())
            {
                context.Products.ToList().ForEach(one => context.Products.Remove(one));
                context.SaveChanges();
                Product p = new Product()
                {
                    IsActive = true,
                    ProductName = "Product1",
                    ProductNumber = "001"
                };
                context.Products.Add(p);

                p = new Product()
                {
                    IsActive = true,
                    ProductName = "Product2",
                    ProductNumber = "002"
                };
                context.Products.Add(p);

                p = new Product()
                {
                    IsActive = false,
                    ProductName = "Product3",
                    ProductNumber = "003"
                };
                context.Products.Add(p);
                context.SaveChanges();
            }
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<ProductContext, Configuration>());

            TestUsages.InsertData();
            TestUsages.RunQueries();

            Console.WriteLine("See Output/Debug window of VS.NET for more info.");
            Console.Read();
        }
    }
}
