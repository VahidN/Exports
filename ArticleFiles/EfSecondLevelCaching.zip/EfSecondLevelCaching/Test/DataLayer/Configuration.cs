﻿using System.Data.Entity.Migrations;

namespace EfSecondLevelCaching.Test.DataLayer
{
    public class Configuration : DbMigrationsConfiguration<ProductContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }
    }
}
