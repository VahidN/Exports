﻿using System;

namespace EfSecondLevelCaching.WebApplication
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            TestUsages.InsertData();
            TestUsages.RunQueries();
            Response.Write("See Output/Debug window of VS.NET for more info.");
        }
    }
}