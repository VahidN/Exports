﻿using Farayan;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Xml;
using Microsoft.Win32;
using SolutionExplorer.Properties;

namespace SolutionExplorer
{
	/// <summary>
	/// Interaction logic for MainWindow.xaml
	/// </summary>
	public partial class MainWindow : Window
	{
		public MainWindow()
		{
			InitializeComponent();
		}

		private void SolutionBrowseButton_Click(object sender, RoutedEventArgs e)
		{
			OpenFileDialog dialog = new OpenFileDialog();
			dialog.DefaultExt = "sln";
			if (dialog.ShowDialog().GetValueOrDefault(true)) {
				SolutionFileTextBox.Text = dialog.FileName;
			}
		}

		class Project
		{
			public string Name { get; set; }

			public string RelativeUrl { get; set; }

			public string PhysicalUrl { get; set; }

			public string ID { get; set; }

			public readonly List<string> AssemblyRefrences = new List<string>();

			public readonly List<string> ProjectRefrences = new List<string>();

			private XmlDocument xml;
			public XmlDocument Xml
			{
				get
				{
					if (xml != null)
						return xml;
					if (string.IsNullOrEmpty(PhysicalUrl))
						return null;
					xml = new XmlDocument();
					xml.Load(PhysicalUrl);
					return xml;
				}
			}
		}

		private void StartButton_Click(object sender, RoutedEventArgs e)
		{
			if (string.IsNullOrEmpty(SolutionFileTextBox.Text))
				return;
			if (File.Exists(SolutionFileTextBox.Text) == false)
				return;
			string a = RelativeUrl(@"D:\a\file.ext", @"D:\a\");		//	b.ext
			string b = RelativeUrl(@"D:\a\file.ext", @"D:\1\2\");	//	..\..\a\b.ext
			string c = RelativeUrl(@"D:\a\file.ext", @"D:\a\c\d\");	//	..\..\..\b.ext

			string solutionFolder = System.IO.Path.GetDirectoryName(SolutionFileTextBox.Text).EnsureEndsWith('\\');
			List<Project> projectsPlain = new List<Project>();
			string solution = File.ReadAllText(SolutionFileTextBox.Text);
			string pattern = @"Project\(\""\{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC\}\""\) = \""(?<name>[^\""]*)\"", \""(?<url>[^\""]*)\.csproj\"", \""\{(?<id>[^\""]*)\}\""";
			pattern = pattern.Replace("'", "\"");
			foreach (Match match in Regex.Matches(solution, pattern)) {
				Project project = new Project();
				project.Name = match.Groups["name"].Value;
				project.RelativeUrl = match.Groups["url"].Value + ".csproj";
				project.PhysicalUrl = solutionFolder + project.RelativeUrl;
				project.ID = match.Groups["id"].Value;
				foreach (XmlNode xn in project.Xml.GetElementsByTagName("Reference")) {
					string value = xn.Attributes["Include"].Value;
					if (value.IndexOf(',') >= 0)
						value = value.Substring(0, value.IndexOf(','));
					project.AssemblyRefrences.Add(value);
				}
				foreach (XmlNode xn in project.Xml.GetElementsByTagName("ProjectReference")) {
					string value = xn.Attributes["Include"].Value;
					if (string.IsNullOrEmpty(value))
						continue;
					string projectName = value.SplitToNonEmptyParts('/', '\\').LastOrDefault();
					if (string.IsNullOrEmpty(projectName))
						continue;
					projectName = projectName.Substring(0, projectName.LastIndexOf('.'));
					project.ProjectRefrences.Add(projectName);
				}
				projectsPlain.Add(project);
			}

			//return;

			var ns = "http://schemas.microsoft.com/developer/msbuild/2003";
			int projectsCount = 0, referenceProjectsCount = 0;
			foreach (Project project in projectsPlain) {
				bool changed = false;
				AssemblyRefrences(project, projectsPlain, ref changed, ref referenceProjectsCount);
				ProjectRefrences(project, projectsPlain, ref changed, ref referenceProjectsCount, AssemblyFolderTextBox.Text.EnsureEndsWith('\\'));

				if (changed) {
					string folder = System.IO.Path.GetDirectoryName(project.PhysicalUrl).EnsureEndsWith('\\');
					string filename = System.IO.Path.GetFileNameWithoutExtension(project.PhysicalUrl);
					string extension = System.IO.Path.GetExtension(project.PhysicalUrl).EnsureStartsWith('.');

					string backupFile = folder + filename + "-backup-" +
										PersianDateTime.Now.ToString(PersianDateTimeFormats.CancatenatedFull, false) + extension;
					string targetFile = project.PhysicalUrl;

					bool real = true;

					if (real) {
						File.Move(project.PhysicalUrl, backupFile);

						project.Xml.Save(targetFile);
						string xml = File.ReadAllText(targetFile);
						xml = xml.Replace("xmlns=\"\"", "");
						File.WriteAllText(targetFile, xml);
					} else {
						project.Xml.Save(backupFile);
						string xml = File.ReadAllText(backupFile);
						xml = xml.Replace("xmlns=\"\"", "");
						File.WriteAllText(backupFile, xml);
					}

					LogTextBlock.Text += "Project {0} has been saved in file. A backup of old project file saved with name {1}\r\n".FormatText(project.Name, Path.GetFileNameWithoutExtension(backupFile));
					projectsCount++;
				}
			}

			if (projectsCount > 0) {
				System.Windows.MessageBox.Show("تعداد {0} ارجاع به {1} پروژه تغییر کرد".FormatText(referenceProjectsCount,
																									projectsCount));
			} else {
				System.Windows.MessageBox.Show("هیچ پروژه ای تغییر نکرد");
			}
		}

		private void ProjectRefrences(Project project, List<Project> projectsPlain, ref bool changed, ref int referenceProjectsCount, string assembliesFolder)
		{
			foreach (string projectRefrence in project.ProjectRefrences) {
				Project referencedProject = projectsPlain.FirstOrDefault(v => projectRefrence == v.Name);
				if (referencedProject != null)
					continue;

				string assemblyFileName = Directory.GetFiles(assembliesFolder).FirstOrDefault(s => s.EndsWith(projectRefrence + ".dll"));
				
				if (string.IsNullOrEmpty(assemblyFileName)) {
					continue;
				}
				
				XmlNode xn = FindProjectReference(project.Xml.ChildNodes, projectRefrence);

				//project.Xml.Cast<XmlNode>().FirstOrDefault(
				//	x => x.Name == "Reference" &&
				//	x.Attributes["Include"].Value.StartsWith(assemblyRefrence)
				//);
				if (xn == null)
					continue;

				changed = true;
				XmlNode referenceNode = project.Xml.CreateNode(XmlNodeType.Element, "Reference", null);
				string relativeUrl = RelativeUrl(assemblyFileName, System.IO.Path.GetDirectoryName(project.PhysicalUrl));
				XmlAttribute attribute = project.Xml.CreateAttribute("Include");
				attribute.Value = Path.GetFileNameWithoutExtension(assemblyFileName);
				referenceNode.Attributes.Append(attribute);

				var specificVersion = project.Xml.CreateElement("SpecificVersion");
				specificVersion.InnerText = bool.FalseString;
				referenceNode.AppendChild(specificVersion);

				var hintPath = project.Xml.CreateElement("HintPath");
				hintPath.InnerText = relativeUrl;
				referenceNode.AppendChild(hintPath);

				//XmlNode projectNode = project.Xml.CreateNode(XmlNodeType.Element, null, "Project", null);
				//projectNode.InnerText = "{" + referencedProject.ID + "}";
				//referenceNode.AppendChild(projectNode);
				//XmlNode nameNode = project.Xml.CreateNode(XmlNodeType.Element, null, "Name", null);
				//nameNode.InnerText = assemblyRefrence;
				//referenceNode.AppendChild(nameNode);
				xn.ParentNode.AppendChild(referenceNode);
				xn.ParentNode.RemoveChild(xn);
				LogTextBlock.Text += "Reference of {0} replaced with its related assembly in project {1}\r\n".FormatText(projectRefrence, project.Name);
				referenceProjectsCount++;
			}
		}

		private void AssemblyRefrences(Project project, List<Project> projects, ref bool changed, ref int referenceProjectsCount)
		{
			foreach (string assemblyRefrence in project.AssemblyRefrences) {
				Project referencedProject = projects.FirstOrDefault(v => assemblyRefrence.EndsWith(v.Name));
				if (referencedProject == null)
					continue;
				XmlNode xn = FindAssemblyReference(project.Xml.ChildNodes, assemblyRefrence);

				//project.Xml.Cast<XmlNode>().FirstOrDefault(
				//	x => x.Name == "Reference" &&
				//	x.Attributes["Include"].Value.StartsWith(assemblyRefrence)
				//);
				if (xn == null)
					continue;

				changed = true;
				XmlNode referenceNode = project.Xml.CreateNode(XmlNodeType.Element, "ProjectReference", null);
				string relativeUrl = RelativeUrl(referencedProject.PhysicalUrl, System.IO.Path.GetDirectoryName(project.PhysicalUrl));
				XmlAttribute attribute = project.Xml.CreateAttribute("Include");
				attribute.Value = relativeUrl;
				referenceNode.Attributes.Append(attribute);
				XmlNode projectNode = project.Xml.CreateNode(XmlNodeType.Element, null, "Project", null);
				projectNode.InnerText = "{" + referencedProject.ID + "}";
				referenceNode.AppendChild(projectNode);
				XmlNode nameNode = project.Xml.CreateNode(XmlNodeType.Element, null, "Name", null);
				nameNode.InnerText = assemblyRefrence;
				referenceNode.AppendChild(nameNode);
				xn.ParentNode.AppendChild(referenceNode);
				xn.ParentNode.RemoveChild(xn);
				LogTextBlock.Text += "Reference of {0} replaced with its related project in project {1}\r\n".FormatText(referencedProject.Name, project.Name);
				referenceProjectsCount++;
			}
		}

		private XmlNode FindAssemblyReference(XmlNodeList list, string assemblyRefrence)
		{
			foreach (XmlNode childNode in list) {
				if (childNode.Name == "Reference" && childNode.Attributes["Include"].Value.StartsWith(assemblyRefrence))
					return childNode;
				XmlNode found = FindAssemblyReference(childNode.ChildNodes, assemblyRefrence);
				if (found != null)
					return found;
			}
			return null;
		}

		private XmlNode FindProjectReference(XmlNodeList list, string projectRefrence)
		{
			foreach (XmlNode childNode in list) {
				if (childNode.Name == "ProjectReference" && childNode.Attributes["Include"].Value.ToLowerInvariant().Contains(projectRefrence.ToLowerInvariant() + ".csproj"))
					return childNode;
				XmlNode found = FindProjectReference(childNode.ChildNodes, projectRefrence);
				if (found != null)
					return found;
			}
			return null;
		}

		private string RelativeUrl(string fromFile, string toFolder)
		{
			string fromFolder = System.IO.Path.GetDirectoryName(fromFile);
			if (string.Compare(fromFolder, toFolder, true) == 0)
				return Path.GetFileName(fromFile);
			fromFile = fromFile.Replace('/', '\\');

			string[] fromParts = fromFolder.SplitToNonEmptyParts('\\');
			string[] toParts = toFolder.SplitToNonEmptyParts('\\');

			int startDiff = 0;
			for (int i = 0; i < Math.Min(fromParts.Length, toParts.Length); i++) {
				startDiff++;
				if (fromParts[i] == toParts[i])
					continue;
				startDiff = i;
				break;
			}
			string fileDiff = string.Join("\\", fromParts.Skip(startDiff));
			string folderDiff = string.Join("\\", toParts.Skip(startDiff));
			string result = Repeat(toParts.Length - startDiff, "..\\") + fileDiff;
			result = result.IsUsable() ? result.EnsureEndsWith('\\') : "";
			result += Path.GetFileName(fromFile);

			return result;

			//file	=	d:\a\b\c.txt
			//folder=	d:\a\
			//where toFolder is one of file parent directories
			if (fromFile.ToLower().StartsWith(toFolder.ToLower()))
				return fromFile.Substring(toFolder.Length);

			//file	=	d:\a\b\c.txt
			//folder=	d:\a\e
			//result=	..\b\c.txt
			//where toFolder is one of file parent directories
			//string shared=
			//if (fromFile.ToLower().StartsWith(toFolder.ToLower()))
			//	return fromFile.Substring(toFolder.Length);
		}

		private string Repeat(int count, string str)
		{
			string result = "";
			for (int i = 0; i < count; i++)
				result += str;
			return result;
		}

		private void AssembliesBrowseButton_Click(object sender, RoutedEventArgs e)
		{
			var dialog = new System.Windows.Forms.FolderBrowserDialog();
			if (Settings.Default.AssembliesFolder.IsUsable())
				dialog.SelectedPath = Settings.Default.AssembliesFolder;
			System.Windows.Forms.DialogResult result = dialog.ShowDialog();

			if (result == System.Windows.Forms.DialogResult.OK) {
				Settings.Default.AssembliesFolder = dialog.SelectedPath;
				Settings.Default.Save();
				AssemblyFolderTextBox.Text = dialog.SelectedPath;
			}
		}
	}
}
