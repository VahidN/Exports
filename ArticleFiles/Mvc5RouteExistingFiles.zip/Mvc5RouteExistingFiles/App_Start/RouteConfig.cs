﻿using System.Web.Mvc;
using System.Web.Routing;

namespace Mvc5RouteExistingFiles
{
    public class RouteConfig
    {
        public static void RegisterRoutes(RouteCollection routes)
        {
            routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            //routes.IgnoreRoute("{resource}.axd/{*pathInfo}");
            //routes.IgnoreRoute("content/{*pathInfo}");
            //routes.IgnoreRoute("scripts/{*pathInfo}");
            //routes.IgnoreRoute("favicon.ico");
            //routes.IgnoreRoute("{resource}.ico");
            //routes.IgnoreRoute("{resource}.png");
            routes.IgnoreRoute("{resource}.jpg");
            //routes.IgnoreRoute("{resource}.gif");
            //routes.IgnoreRoute("{resource}.txt");

            routes.IgnoreRoute("images/{resource}.jpg");
            //routes.IgnoreRoute("export/{resource}.jpg");
            
            routes.RouteExistingFiles = true;

            routes.MapRoute(
               name: "ExportRoute",
               url: "Export/{id}",
               defaults: new { controller = "Export", action = "Index", id = UrlParameter.Optional }
           );

            routes.MapRoute(
                name: "Default",
                url: "{controller}/{action}/{id}",
                defaults: new { controller = "Home", action = "Index", id = UrlParameter.Optional }
            );
        }
    }
}