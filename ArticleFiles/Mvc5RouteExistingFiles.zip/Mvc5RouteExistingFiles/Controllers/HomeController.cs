﻿using System.Web.Mvc;

namespace Mvc5RouteExistingFiles.Controllers
{
    public class HomeController:Controller
    {
        public ActionResult Index()
        {
            return View();
        }
    }
}