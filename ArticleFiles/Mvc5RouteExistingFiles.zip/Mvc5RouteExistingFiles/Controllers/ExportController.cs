﻿using System.IO;
using System.Web.Mvc;

namespace Mvc5RouteExistingFiles.Controllers
{
    public class ExportController : Controller
    {
        public ActionResult Index(string id)
        {
            if (string.IsNullOrWhiteSpace(id))
            {
                return Redirect("/");
            }

            var fileName = Path.GetFileName(id);
            var path = Server.MapPath("~/export/" + fileName);
            return File(path, System.Net.Mime.MediaTypeNames.Application.Octet, fileName);
        }
	}
}