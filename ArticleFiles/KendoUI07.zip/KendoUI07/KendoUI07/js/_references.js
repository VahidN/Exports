﻿/// <reference path="jquery.min.js" />
/// <reference path="kendo.all.min.js" />
/// <autosync enabled="true" />