﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using MvcJSTree.Models;

namespace MvcJSTree.Controllers
{
    //طراحي ويژه مدل‌هاي خود ارجاع دهنده در ايي اف
    public class BlogComment
    {
        public int Id { set; get; }
        public string Body { set; get; }

        public virtual BlogComment Parent { set; get; }
        public int? ParentId { get; set; }

        public ICollection<BlogComment> Children { get; set; }
    }

    //منبع داده فرضي جهت سهولت دموي برنامه
    public static class DataSource
    {
        public static IList<BlogComment> GetPost1Comments()
        {

            /*
                // اگر از ايي اف استفاده مي‌كنيد همين يك سطر كافي است
                return ctx.BlogComments
                          .Where(x=> x.PostId == 1)
                          .ToList() // اين مورد در ايي اف خاصيت فرزندان را هم به صورت خودكار پر مي‌كند
                          .Where(x => x.Reply == null) // for TreeView
                          .ToList();
             */

            var comment1 = new BlogComment
            {
                Id = 1, // اگر از ايي اف استفاده مي‌كنيد اين آي دي ها را به صورت خودكار از بانك اطلاعاتي دريافت مي‌كند
                Body = "نظر من اين است که" ,
                ParentId = null
            };
            var comment12 = new BlogComment
            {
                Id = 2,
                Body = "پاسخي به نظر اول",
                Parent = comment1, //اگر از ايي اف استفاده مي‌كنيد يكي از دو مقدار والد يا شماره آي دي آن بايد پر شوند
                ParentId = 1
            };
            var comment121 = new BlogComment
            {
                Id = 3,
                Body = "پاسخي به پاسخ به نظر اول",
                Parent = comment12,
                ParentId = 2
            };

            // اگر از ايي اف استفاده مي‌كنيد نيازي به پر كردن دستي اين موارد نيست. خودش اين موارد را مقدار دهي مي‌كند
            comment1.Children = new List<BlogComment>{ comment12 };
            comment12.Children = new List<BlogComment> { comment121 };

            return new List<BlogComment>
            {
              comment1,
              comment121,
              comment12
            };
        }
    }


    public class CommentsController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult DoJsTreeOperation(JsTreeOperationData data)
        {
            switch (data.Operation)
            {
                case JsTreeOperation.CopyNode:
                case JsTreeOperation.CreateNode:
                    //todo: save data
                    var rnd = new Random(); // آي دي ركورد پس از ثبت در بانك اطلاعاتي دريافت و بازگشت داده شود
                    return Json(new { id = rnd.Next() }, JsonRequestBehavior.AllowGet);

                case JsTreeOperation.DeleteNode:
                    //todo: save data
                    return Json(new { result = "ok" }, JsonRequestBehavior.AllowGet);

                case JsTreeOperation.MoveNode:
                    //todo: save data
                    return Json(new { result = "ok" }, JsonRequestBehavior.AllowGet);

                case JsTreeOperation.RenameNode:
                    //todo: save data
                    return Json(new { result = "ok" }, JsonRequestBehavior.AllowGet);

                default:
                    throw new InvalidOperationException(string.Format("{0} is not supported.", data.Operation));
            }
        }


        [HttpPost]
        public ActionResult GetTreeJson()
        {
            var nodesList = new List<JsTreeNode>();

            var comments = DataSource.GetPost1Comments();
            var rootComment = comments.FirstOrDefault(x => x.ParentId == null);

            var rootNode = new JsTreeNode
            {
                id = rootComment.Id.ToString(),
                text = rootComment.Body,
                icon = Url.Content("~/Content/images/tree_icon.png"),
                a_attr = { href = "http://www.bing.com" }
            };
            PopulateTree(rootComment, rootNode);
            nodesList.Add(rootNode);

            return Json(nodesList, JsonRequestBehavior.AllowGet);
        }

        public void PopulateTree(BlogComment root, JsTreeNode node)
        {
            if (root.Children == null) return;
            foreach (var item in root.Children)
            {
                var jsTreeNode = new JsTreeNode
                {
                    id = item.Id.ToString(),
                    text = item.Body,
                    icon = Url.Content("~/Content/images/bookmark_book_open.png"),
                    a_attr = { href = "http://www.bing.com" }
                };
                node.children.Add(jsTreeNode);

                PopulateTree(item, jsTreeNode);
            }
        }
    }
}