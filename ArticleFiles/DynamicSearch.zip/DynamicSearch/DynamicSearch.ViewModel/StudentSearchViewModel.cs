﻿using System.Windows;
using DynamicSearch.Model;
using DynamicSearch.ViewModel.Base;

namespace DynamicSearch.ViewModel
{
    public class StudentSearchViewModel : BaseSearchViewModel<Student>
    {
        private static readonly SearchFilterBase<Student> service = new StudentSearchFilter();

        public StudentSearchViewModel()
            : base(service)
        {
            BindFilter.Add(new StudentSearchFilter { IsOtherFilters = false });
        }

        public override void ExecuteAddFilter()
        {
            BindFilter.Add(new StudentSearchFilter());
        }
    }
}