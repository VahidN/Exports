﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Linq.Expressions;

namespace DynamicSearch.ViewModel.Base
{
    /// <summary>
    /// کلاس پایه ویوو مدل‌های برنامه که جهت علامتگذاری آن‌ها برای سیم کشی‌های تزریق وابستگی‌های برنامه نیز استفاده می‌شود
    /// </summary>
    public abstract class BaseViewModel : DataErrorInfoBase, INotifyPropertyChanged, IViewModel
    {
        /// <summary>
        /// جهت اطلاع رسانی در مورد تغییر مقدار یک خاصیت بکار می‌رود
        /// </summary>
        public event PropertyChangedEventHandler PropertyChanged;

        /// <summary>
        /// تغییر مقدار یک خاصیت را اطلاع رسانی خواهد کرد
        /// </summary>
        /// <param name="propertyName">نام خاصیت</param>
        public void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        /// <summary>
        /// تغییر مقدار یک خاصیت را اطلاع رسانی خواهد کرد
        /// </summary>
        /// <param name="expression">نام خاصیت مورد نظر</param>
        public void NotifyPropertyChanged(Expression<Func<object>> expression)
        {
            MemberExpression memberExpression = null;
            if (expression.Body.NodeType == ExpressionType.Convert)
            {
                var body = (UnaryExpression)expression.Body;
                memberExpression = body.Operand as MemberExpression;
            }
            else if (expression.Body.NodeType == ExpressionType.MemberAccess)
            {
                memberExpression = expression.Body as MemberExpression;
            }

            if (memberExpression == null)
                throw new ArgumentException("Not a property or field", "expression");

            var handler = PropertyChanged;
            if (handler == null) return;
            handler(this, new PropertyChangedEventArgs(memberExpression.Member.Name));
        }

        /// <summary>
        /// آیا در حین نمایش صفحه‌ای دیگر باید به کاربر پیغام داد که اطلاعات ذخیره نشده‌ای وجود دارد؟
        /// </summary>
        public virtual bool ViewModelContextHasChanges { get { return false; } }
    }

    public interface IViewModel
    {
    }

    /// <summary>
    /// کلاس پایه‌ایی برای یکپارچه سازی اعتبارسنجی مدل‌های ایی اف با دبلیو پی اف
    /// </summary>
    public abstract class DataErrorInfoBase : IDataErrorInfo
    {
        /// <summary>
        /// کلیه خطاهای حاصل از اعتبارسنجی شیء جاری را بر می‌گرداند
        /// </summary>
        public string Error
        {
            get
            {
                var errors = ValidationHelper.GetErrors(this);
                return string.Join(Environment.NewLine, errors.Select(x => x.ErrorMessage));
            }
        }

        /// <summary>
        /// خطاهای حاصل از اعتبارسنجی خاصیتی مشخص را بر می‌گرداند
        /// </summary>
        /// <param name="columnName">نام خاصیت</param>
        /// <returns>خطاهای احتمالی</returns>
        public string this[string columnName]
        {
            get
            {
                var errors = ValidationHelper.ValidateProperty(this, columnName);
                return string.Join(Environment.NewLine, errors.Select(x => x.ErrorMessage));
            }
        }
    }

    /// <summary>
    /// جهت اعتبار سنجی بر مبنای ویژگی‌های یکپارچه با ایی اف طراحی شده است
    /// </summary>
    public static class ValidationHelper
    {
        /// <summary>
        /// جهت اعتبار سنجی بر مبنای ویژگی‌های یکپارچه با ایی اف طراحی شده است        
        /// این متد کلیه خطاهای مرتبط با یک شیء را بر می‌گرداند
        /// </summary>
        /// <param name="instance">وهله‌ایی از شیءایی که باید اعتبارسنجی شود</param>
        /// <returns>لیستی از خطاهای احتمالی</returns>
        public static IList<ValidationResult> GetErrors(object instance)
        {
            var results = new List<ValidationResult>();
            Validator.TryValidateObject(instance, new ValidationContext(instance, null, null), results, true);
            return results;
        }

        /// <summary>
        /// جهت اعتبار سنجی بر مبنای ویژگی‌های یکپارچه با ایی اف طراحی شده است        
        /// </summary>
        /// <param name="value">وهله‌ایی از شیءایی که باید اعتبارسنجی شود</param>
        /// <param name="propertyName">نام خاصیت مد نظر جهت اعتبار سنجی</param>
        /// <returns>لیستی از خطاهای احتمالی</returns>
        public static IList<ValidationResult> ValidateProperty(object value, string propertyName)
        {
            if (string.IsNullOrEmpty(propertyName))
                throw new ArgumentException("Invalid property name", propertyName);

            var propertyValue = value.GetType().GetProperty(propertyName).GetValue(value, null);
            var results = new List<ValidationResult>();
            var context = new ValidationContext(value, null, null) { MemberName = propertyName };
            Validator.TryValidateProperty(propertyValue, context, results);
            return results;
        }
    }
}
