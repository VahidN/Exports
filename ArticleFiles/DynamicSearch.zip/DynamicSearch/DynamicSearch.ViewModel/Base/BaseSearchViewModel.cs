﻿using System.Collections.ObjectModel;
using System.Linq;
using System.Linq.Expressions;
using System.Windows;
using GalaSoft.MvvmLight.Command;

namespace DynamicSearch.ViewModel.Base
{
    public abstract class BaseSearchViewModel<T> : BaseViewModel where T : class
    {
        public SearchFilterBase<T> SearchFilter { get; set; }

        protected BaseSearchViewModel(SearchFilterBase<T> service)
        {
            Studentes = service.GetQuarable();
            BindFilter = new ObservableCollection<SearchFilterBase<T>>();
            ExecuteSearchFilter = new RelayCommand(ExecuteSearchFilterExecute, CanExecuteRunSearch);
            AddFilter = new RelayCommand(ExecuteAddFilter);
        }

        public abstract void ExecuteAddFilter();

        public RelayCommand ExecuteSearchFilter { get; set; }
        public RelayCommand AddFilter { get; set; }

        private void ExecuteSearchFilterExecute()
        {
            _canExecSearch = false;
            Expression expression = null;
            var isFirst = true;
            var pe = Expression.Parameter(typeof(T), "lambdaExParameter");
            foreach (var searchFilter in BindFilter.Where(a => a.SelectedAndOr.Name != "Suppress" || !a.IsOtherFilters))
            {
                Expression right;
                Expression left;
                ExpressionExtensions.CreateLeftAndRightExpression<T>(searchFilter.SelectedFeild.Name, searchFilter.SelectedFeild.Type, searchFilter.SearchValue, pe, out left, out right);
                var ex = ExpressionExtensions.AddOperatorExpression(searchFilter.SelectedOperator.Func, left, right);
                expression = ExpressionExtensions.JoinExpressions(isFirst, searchFilter.SelectedAndOr.Func, expression, ex);
                isFirst = false;
            }
            
            if (expression == null)
            {
                _canExecSearch = true;
                return;
            }

            var whereCallExpression = ExpressionExtensions.CreateWhereCall<T>(expression, pe, Studentes);
            var Studenteses2 = ExpressionExtensions.CreateQuery<T>(whereCallExpression, Studentes);
            Results = new ObservableCollection<T>(Studenteses2);
            _canExecSearch = true;

        }
        private bool CanExecuteRunSearch()
        {
            return _canExecSearch;
        }

        public ObservableCollection<SearchFilterBase<T>> BindFilter
        {
            get { return _bindFilter; }
            set { _bindFilter = value; NotifyPropertyChanged("BindFilter"); }
        }
        public ObservableCollection<T> Results
        {
            get { return _results; }
            set { _results = value; NotifyPropertyChanged("Results"); }
        }

        private ObservableCollection<SearchFilterBase<T>> _bindFilter;
        private ObservableCollection<T> _results;
        private bool _canExecSearch = true;
        public IQueryable<T> Studentes;
    }
}