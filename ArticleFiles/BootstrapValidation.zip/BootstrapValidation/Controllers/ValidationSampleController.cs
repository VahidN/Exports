﻿using System.Web.Mvc;
using Mvc4TwitterBootStrapTest.Models;

namespace Mvc4TwitterBootStrapTest.Controllers
{
    public class ValidationSampleController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(User user)
        {
            if (this.ModelState.IsValid)
            {
                if (user.Name != "Vahid")
                {
                    this.ModelState.AddModelError("", "لطفا مشكلات را برطرف كنيد!");
                    this.ModelState.AddModelError("Name", "نام فقط بايد وحيد باشد!");
                    return View(user);
                }
                // todo: save ...
                return RedirectToAction("Index", "ValidationSample");
            }
            return View(user);
        }
    }
}