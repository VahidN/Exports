﻿using System.Web.Mvc;

namespace AspNetIdentityDependencyInjectionSample
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}