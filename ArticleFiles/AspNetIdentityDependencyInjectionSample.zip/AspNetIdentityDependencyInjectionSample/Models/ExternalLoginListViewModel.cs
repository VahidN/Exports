﻿namespace AspNetIdentityDependencyInjectionSample.Models
{
    public class ExternalLoginListViewModel
    {
        public string ReturnUrl { get; set; }
    }
}