﻿namespace AspNetIdentityDependencyInjectionSample.Models
{
    public class FactorViewModel
    {
        public string Purpose { get; set; }
    }
}