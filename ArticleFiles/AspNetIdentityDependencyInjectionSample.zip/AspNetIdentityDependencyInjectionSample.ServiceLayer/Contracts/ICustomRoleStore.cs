namespace AspNetIdentityDependencyInjectionSample.ServiceLayer.Contracts
{
    public interface ICustomRoleStore
    {
    }
}