﻿namespace AspNetIdentityDependencyInjectionSample.ServiceLayer.Contracts
{
    public interface ICustomUserStore
    {
    }
}