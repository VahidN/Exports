﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace AspNetIdentityDependencyInjectionSample.DomainClasses
{
    public class CustomUserLogin : IdentityUserLogin<int>
    {

    }
}