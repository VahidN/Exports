﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace AspNetIdentityDependencyInjectionSample.DomainClasses
{
    public class CustomUserRole : IdentityUserRole<int>
    {

    }
}