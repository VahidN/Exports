﻿using Microsoft.AspNet.Identity.EntityFramework;

namespace AspNetIdentityDependencyInjectionSample.DomainClasses
{
    public class CustomUserClaim : IdentityUserClaim<int>
    {

    }
}