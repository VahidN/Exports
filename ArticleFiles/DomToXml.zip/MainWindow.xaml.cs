﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Xml;
using ICSharpCode.AvalonEdit;
using ICSharpCode.AvalonEdit.Highlighting;
using ICSharpCode.AvalonEdit.Highlighting.Xshd;
using Microsoft.Win32;

namespace SqlDomAnalyzer
{
    public partial class MainWindow
    {
        private static readonly Dictionary<string, IHighlightingDefinition> _cache = new Dictionary<string, IHighlightingDefinition>();

        public MainWindow()
        {
            InitializeComponent();
            loadHighlighter(TxtSql, "SqlDomAnalyzer.sql-ce.xshd");
        }

        private static IHighlightingDefinition getHighlightingDefinition(string resourceName)
        {
            IHighlightingDefinition result;
            if (_cache.TryGetValue(resourceName, out result))
            {
                return result;
            }

            if (string.IsNullOrWhiteSpace(resourceName))
                throw new NullReferenceException("Please specify SyntaxHighlightingResourceName.");

            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                    throw new NullReferenceException(string.Format("{0} resource is null.", resourceName));

                using (var reader = new XmlTextReader(stream))
                {
                    result = HighlightingLoader.Load(reader, HighlightingManager.Instance);
                    _cache.Add(resourceName, result);
                    return result;
                }
            }
        }

        private static void loadHighlighter(TextEditor @this, string resourceName)
        {
            if (@this.SyntaxHighlighting != null)
                return;

            @this.SyntaxHighlighting = getHighlightingDefinition(resourceName);
        }

        private void BtnSave_OnClick(object sender, RoutedEventArgs e)
        {
            var saveDialog = new SaveFileDialog
            {
                Filter = "XML files (*.xml)|*.xml|All files (*.*)|*.*"
            };
            var result = saveDialog.ShowDialog();
            if (result == null || !result.Value)
                return;

            File.WriteAllText(saveDialog.FileName,
                string.Format("<!--{1}{0}{1}-->{1}{2}", TxtSql.Text, Environment.NewLine, TxtResult.Text));

            Process.Start(saveDialog.FileName);
        }

        private void BtnStart_OnClick(object sender, RoutedEventArgs e)
        {
            TxtResult.Text = new DomToXml().Start(TxtSql.Text);
        }
    }
}