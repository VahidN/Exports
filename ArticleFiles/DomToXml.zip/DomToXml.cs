﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Xml;
using System.Xml.Linq;
using Microsoft.SqlServer.TransactSql.ScriptDom;

namespace SqlDomAnalyzer
{
    public class DomToXml
    {
        readonly StringBuilder _result = new StringBuilder();
        public string Start(string script)
        {

            IList<ParseError> parseErrors;
            var sql120Parser = new TSql120Parser(true);
            TSqlFragment fragment;
            using (var stringReader = new StringReader(script))
            {
                fragment = sql120Parser.Parse(stringReader, out parseErrors);
            }
            if (parseErrors.Count > 0)
            {
                Console.WriteLine(@"Errors encountered: ""{0}""", parseErrors[0].Message);
            }

            scriptDomWalk(fragment, "root");
            var xml = _result.ToString();
            return prettyXml(xml);
        }


        static string prettyXml(string xml)
        {
            var stringBuilder = new StringBuilder();

            var element = XElement.Parse(xml);

            var settings = new XmlWriterSettings
            {
                Indent = true,
                Encoding = Encoding.UTF8
            };

            using (var xmlWriter = XmlWriter.Create(stringBuilder, settings))
            {
                element.Save(xmlWriter);
            }

            return stringBuilder.ToString();
        }

        private void scriptDomWalk(object fragment, string memberName)
        {
            var baseType = fragment.GetType().BaseType;
            if (baseType != null && baseType.Name != "Enum")
            {
                _result.AppendLine(string.Format("<{0} memberName = '{1}'>", fragment.GetType().Name, memberName));
            }
            else
            {
                _result.AppendLine(string.Format("<{0}.{1}/>", fragment.GetType().Name, fragment));
                return;
            }

            var type = fragment.GetType();
            foreach (var pi in type.GetProperties())
            {
                if (pi.GetIndexParameters().Length != 0)
                {
                    continue;
                }

                if (pi.PropertyType.BaseType != null)
                {
                    if (pi.PropertyType.BaseType.Name == "ValueType")
                    {
                        _result.AppendFormat("<{0}>{1}</{0}>", pi.Name, pi.GetValue(fragment, null));
                        continue;
                    }
                }

                if (pi.PropertyType.Name.Contains(@"IList`1"))
                {
                    if ("ScriptTokenStream" == pi.Name)
                        continue;

                    var listMembers = pi.GetValue(fragment, null) as IEnumerable<object>;

                    if (listMembers == null) continue;
                    foreach (var listItem in listMembers)
                    {
                        scriptDomWalk(listItem, pi.Name);
                    }
                }
                else
                {
                    var childObj = pi.GetValue(fragment, null);
                    if (childObj == null)
                        continue;

                    if (childObj is string)
                    {
                        _result.Append(pi.GetValue(fragment, null));
                    }
                    else
                    {
                        scriptDomWalk(childObj, pi.Name);
                    }
                }
            }

            _result.AppendLine(string.Format("</{0}>", fragment.GetType().Name));
        }
    }
}