﻿using System.Collections.Generic;

namespace DataTablesTutorial04.Models
{
    public class Browsers
    {
        public IEnumerable<Browser> CreateInMemoryDataSource()
        {
            return new List<Browser>
                {
                    new Browser
                        {
                            Id = 1,
                            Engine = "Trident", 
                            Name = "Internet Explorer 4.0", 
                            Platform = "Win95+", 
                            Version = 4,
                            Grade = "X"
                        },
                    new Browser
                        {
                            Id = 2,
                            Engine = "Trident", 
                            Name = "Internet Explorer 5.0", 
                            Platform = "Win95+", 
                            Version = 5,
                            Grade = "C"
                        },
                    new Browser
                        {
                            Id = 3,
                            Engine = "Trident", 
                            Name = "Internet Explorer 5.5", 
                            Platform = "Win95+", 
                            Version = 5.5F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 4,
                            Engine = "Trident", 
                            Name = "Internet Explorer 6", 
                            Platform = "Win98+", 
                            Version = 6,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 5,
                            Engine = "Trident", 
                            Name = "Internet Explorer 7", 
                            Platform = "Win XP SP2+", 
                            Version = 7,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 6,
                            Engine = "Trident", 
                            Name = "AOL browser (AOL desktop)", 
                            Platform = "Win XP", 
                            Version = 6,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 7,
                            Engine = "Gecko", 
                            Name = "Firefox 1.0", 
                            Platform = "Win 98+ / OSX.2+", 
                            Version = 1.7F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 8,
                            Engine = "Gecko", 
                            Name = "Firefox 1.5", 
                            Platform = "Win 98+ / OSX.2+", 
                            Version = 1.8F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 9,
                            Engine = "Gecko", 
                            Name = "Firefox 2", 
                            Platform = "Win 98+ / OSX.2+", 
                            Version = 1.8F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 10,
                            Engine = "Gecko", 
                            Name = "Firefox 3", 
                            Platform = "Win 2k+ / OSX.3+", 
                            Version = 1.9F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 11,
                            Engine = "Gecko", 
                            Name = "Camino 1.0", 
                            Platform = "OSX.2+", 
                            Version = 1.8F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 12,
                            Engine = "Gecko", 
                            Name = "Camino 1.5", 
                            Platform = "OSX.3+", 
                            Version = 1.8F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 13,
                            Engine = "Gecko", 
                            Name = "Netscape 7.2", 
                            Platform = "Win 95+ / Mac OS 8.6-9.2", 
                            Version = 1.7F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 14,
                            Engine = "Gecko", 
                            Name = "Netscape Browser 8", 
                            Platform = "Win 98SE+", 
                            Version = 1.7F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 15,
                            Engine = "Gecko", 
                            Name = "Netscape Navigator 9", 
                            Platform = "Win 98+ / OSX.2+", 
                            Version = 1.8F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 16,
                            Engine = "Gecko", 
                            Name = "Mozilla 1.0", 
                            Platform = "Win 95+ / OSX.1+", 
                            Version = 1F,
                            Grade = "A"
                        },
                    new Browser
                        {
                            Id = 17,
                            Engine = "Gecko", 
                            Name = "Mozilla 1.1", 
                            Platform = "Win 95+ / OSX.1+", 
                            Version = 1.1F,
                            Grade = "A"
                        },
                };
        }
    }
}