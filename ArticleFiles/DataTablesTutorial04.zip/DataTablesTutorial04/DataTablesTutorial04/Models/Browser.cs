﻿namespace DataTablesTutorial04.Models
{
    public class Browser
    {
        public int Id { get; set; }
        public string Engine { get; set; }
        public string Name { get; set; }
        public string Platform { get; set; }
        public float Version { get; set; }
        public string Grade { get; set; }
    }
}