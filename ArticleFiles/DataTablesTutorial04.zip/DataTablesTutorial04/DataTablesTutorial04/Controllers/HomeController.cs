﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using DataTablesTutorial04.Models;

namespace DataTablesTutorial04.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetBrowsers(jQueryDataTableParamModel param)
        {
            IQueryable<Browser> allBrowsers = new Browsers().CreateInMemoryDataSource().AsQueryable();

            IEnumerable<Browser> filteredBrowsers;

            // Apply Filtering
            if (!string.IsNullOrEmpty(param.sSearch))
            {
                filteredBrowsers = new Browsers().CreateInMemoryDataSource()
                    .Where(x => x.Engine.Contains(param.sSearch)
                                       || x.Grade.Contains(param.sSearch)
                                       || x.Name.Contains(param.sSearch)
                                       || x.Platform.Contains(param.sSearch)
                    ).ToList();
                float f;
                if (float.TryParse(param.sSearch, out f))
                {
                    filteredBrowsers = filteredBrowsers.Where(x => x.Version.Equals(f));
                }
            }
            else
            {
                filteredBrowsers = allBrowsers;
            }

            // Apply Sorting
            var sortColumnIndex = Convert.ToInt32(Request["iSortCol_0"]);
            Func<Browser, string> orderingFunction = (x => sortColumnIndex == 0 ? x.Engine :
                                                            sortColumnIndex == 1 ? x.Name :
                                                            sortColumnIndex == 2 ? x.Platform :
                                                            sortColumnIndex == 3 ? x.Version.ToString() :
                                                            sortColumnIndex == 4 ? x.Grade :
                                                                x.Name);

            var sortDirection = Request["sSortDir_0"]; // asc or desc
            filteredBrowsers = sortDirection == "asc" ? filteredBrowsers.OrderBy(orderingFunction) : filteredBrowsers.OrderByDescending(orderingFunction);

            // Apply Paging
            var enumerable = filteredBrowsers.ToArray();
            IEnumerable<Browser> displayedBrowsers = enumerable.Skip(param.iDisplayStart).
                Take(param.iDisplayLength).ToList();

            return Json(new
            {
                sEcho = param.sEcho,
                iTotalRecords = allBrowsers.Count(),
                iTotalDisplayRecords = enumerable.Count(),
                aaData = displayedBrowsers
            }, JsonRequestBehavior.AllowGet);
        }

    }
}
