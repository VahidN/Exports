﻿using System;

namespace Roslyn04.Tests
{
    class Foo
    {
        void Bar()
        {
            Console.WriteLine("test");
        }
    }
}
