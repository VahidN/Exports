using System.Collections.Generic;
using System.Linq;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace Roslyn03
{
    class ConsoleWriteLineWalker : CSharpSyntaxWalker
    {
        public ConsoleWriteLineWalker()
        {
            Arguments = new List<ExpressionSyntax>();
        }

        public List<ExpressionSyntax> Arguments { get; }

        public override void VisitInvocationExpression(InvocationExpressionSyntax node)
        {
            var member = node.Expression as MemberAccessExpressionSyntax;
            var type = member?.Expression as IdentifierNameSyntax;
            if (type != null && type.Identifier.Text == "Console" && member.Name.Identifier.Text == "WriteLine")
            {
                if (node.ArgumentList.Arguments.Count == 1)
                {
                    var arg = node.ArgumentList.Arguments.Single().Expression;
                    Arguments.Add(arg);
                    return;
                }
            }

            base.VisitInvocationExpression(node);
        }
    }
}