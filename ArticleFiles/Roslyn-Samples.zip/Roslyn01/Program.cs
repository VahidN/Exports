﻿using System;
using System.Linq;
using Microsoft.CodeAnalysis;
using Microsoft.CodeAnalysis.CSharp;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace Roslyn01
{
    class MyVisitor : CSharpSyntaxWalker
    {
        public override void VisitMethodDeclaration(MethodDeclarationSyntax node)
        {
            if (node.Identifier.Text == "Bar")
            {
                // do stuff
            }

            base.VisitMethodDeclaration(node);
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            createTree();
            parseText();
            querySyntaxTree();
        }

        static void querySyntaxTree()
        {
            var tree = CSharpSyntaxTree.ParseText("class Foo { void Bar() {} }");
            var node = (CompilationUnitSyntax)tree.GetRoot();

            // Using the object model
            foreach (var member in node.Members)
            {
                if (member.Kind() == SyntaxKind.ClassDeclaration)
                {
                    var @class = (ClassDeclarationSyntax)member;

                    foreach (var member2 in @class.Members)
                    {
                        if (member2.Kind() == SyntaxKind.MethodDeclaration)
                        {
                            var method = (MethodDeclarationSyntax)member2;
                            // do stuff
                        }
                    }
                }
            }


            // Using LINQ query methods
            var bars = from member in node.Members.OfType<ClassDeclarationSyntax>()
                       from member2 in member.Members.OfType<MethodDeclarationSyntax>()
                       where member2.Identifier.Text == "Bar"
                       select member2;
            var res = bars.ToList();


            // Using visitors
            new MyVisitor().Visit(node);
        }

        static void parseText()
        {
            var tree = CSharpSyntaxTree.ParseText("class Foo { void Bar(int x) {} }");
            Console.WriteLine(tree.ToString());
            Console.WriteLine(tree.GetRoot().NormalizeWhitespace().ToString());

            var res = SyntaxFactory.ClassDeclaration("Foo")
                .WithMembers(SyntaxFactory.List<MemberDeclarationSyntax>(new[] {
                    SyntaxFactory.MethodDeclaration(
                        SyntaxFactory.PredefinedType(
                            SyntaxFactory.Token(SyntaxKind.VoidKeyword)
                        ),
                        "Bar"
                    )
                    .WithBody(SyntaxFactory.Block())
                }))
                .NormalizeWhitespace();

            Console.WriteLine(res);
        }

        static void createTree()
        {
            // using http://roslynquoter.azurewebsites.net/
            // with "class Foo { void Bar(int x) {} }"
            var compilationUnitSyantx =
                SyntaxFactory.CompilationUnit()
                    .WithMembers(
                        SyntaxFactory.SingletonList<MemberDeclarationSyntax>(
                            SyntaxFactory.ClassDeclaration(@"Foo")
                                .WithKeyword(SyntaxFactory.Token(SyntaxKind.ClassKeyword))
                                .WithOpenBraceToken(SyntaxFactory.Token(SyntaxKind.OpenBraceToken))
                                .WithMembers(
                                    SyntaxFactory.SingletonList<MemberDeclarationSyntax>(
                                        SyntaxFactory.MethodDeclaration(
                                            SyntaxFactory.PredefinedType(SyntaxFactory.Token(SyntaxKind.VoidKeyword)),
                                            SyntaxFactory.Identifier(@"Bar"))
                                            .WithParameterList(
                                                SyntaxFactory.ParameterList(
                                                    SyntaxFactory.SingletonSeparatedList<ParameterSyntax>(
                                                        SyntaxFactory.Parameter(SyntaxFactory.Identifier(@"x"))
                                                            .WithType(
                                                                SyntaxFactory.PredefinedType(
                                                                    SyntaxFactory.Token(SyntaxKind.IntKeyword)))))
                                                    .WithOpenParenToken(SyntaxFactory.Token(SyntaxKind.OpenParenToken))
                                                    .WithCloseParenToken(SyntaxFactory.Token(SyntaxKind.CloseParenToken)))
                                            .WithBody(
                                                SyntaxFactory.Block()
                                                    .WithOpenBraceToken(SyntaxFactory.Token(SyntaxKind.OpenBraceToken))
                                                    .WithCloseBraceToken(SyntaxFactory.Token(SyntaxKind.CloseBraceToken)))))
                                .WithCloseBraceToken(SyntaxFactory.Token(SyntaxKind.CloseBraceToken))))
                    .WithEndOfFileToken(SyntaxFactory.Token(SyntaxKind.EndOfFileToken))
                    .NormalizeWhitespace();

            var tree = CSharpSyntaxTree.Create(compilationUnitSyantx);
            Console.WriteLine(tree);
        }
    }
}