﻿namespace JqGridHelper.DynamicSearch
{
    public enum DateTimeType
    {
        Persian,
        Gregorian
    }
}