﻿using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmberJS03.Models;
using Newtonsoft.Json.Linq;

namespace EmberJS03.Controllers
{
    public class PostsController : ApiController
    {
        public object Get()
        {
            return new { posts = DataSource.PostsList };
        }

        //GET api/posts/id
        //GET api/posts/id/comments -> api/{controller}/{id}/{name}
        public object Get(int id)
        {
            return
                new
                {
                    posts = DataSource.PostsList.FirstOrDefault(post => post.Id == id),
                    comments = DataSource.CommentsList.Where(comment => comment.Post == id).ToList()
                };
        }

        public HttpResponseMessage Post(HttpRequestMessage requestMessage)
        {
            var jsonContent = requestMessage.Content.ReadAsStringAsync().Result;
            // {"post":{"title":"test0","body":"test1"}}
            var jObj = JObject.Parse(jsonContent);
            var post = jObj.SelectToken("post", false).ToObject<Post>();


            var id = 1;
            var lastItem = DataSource.PostsList.LastOrDefault();
            if (lastItem != null)
            {
                id = lastItem.Id + 1;
            }
            post.Id = id;
            DataSource.PostsList.Add(post);

            // ارسال آي دي با فرمت خاص مهم است
            return Request.CreateResponse(HttpStatusCode.Created, new { post = post });
        }

        [HttpPut] // Add it to fix this error: The requested resource does not support http method 'PUT'
        public HttpResponseMessage Update(int id, HttpRequestMessage requestMessage)
        {
            var jsonContent = requestMessage.Content.ReadAsStringAsync().Result;
            // {"post":{"title":"test0","body":"test1"}}
            var jObj = JObject.Parse(jsonContent);
            var updatedPost = jObj.SelectToken("post", false).ToObject<Post>();
            updatedPost.Id = id;


            var existingRecord = DataSource.PostsList
                                        .Select(
                                            (item, index) =>
                                                new
                                                {
                                                    Post = item,
                                                    Index = index
                                                })
                                        .FirstOrDefault(x => x.Post.Id == id);
            if (existingRecord == null)
                return Request.CreateResponse(HttpStatusCode.NotFound);


            if (!ModelState.IsValid || id != existingRecord.Post.Id)
                return Request.CreateResponse(HttpStatusCode.BadRequest);

            DataSource.PostsList[existingRecord.Index] = updatedPost;
            return Request.CreateResponse(HttpStatusCode.OK, new { post = updatedPost });
        }

        public HttpResponseMessage Delete(int id)
        {
            var item = DataSource.PostsList.FirstOrDefault(x => x.Id == id);
            if (item == null)
                return Request.CreateResponse(HttpStatusCode.NotFound);

            DataSource.PostsList.Remove(item);

            //حذف كامنت‌هاي مرتبط
            var relatedComments = DataSource.CommentsList.Where(comment => comment.Post == id).ToList();
            relatedComments.ForEach(comment => DataSource.CommentsList.Remove(comment));

            return Request.CreateResponse(HttpStatusCode.OK, new { post = item });
        }
    }
}