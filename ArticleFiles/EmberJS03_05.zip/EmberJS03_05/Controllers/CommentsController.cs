﻿using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using EmberJS03.Models;
using Newtonsoft.Json.Linq;

namespace EmberJS03.Controllers
{
    public class CommentsController : ApiController
    {
        public object Get()
        {
            return new { comments = DataSource.CommentsList };
        }

        public object Get(int id)
        {
            return new { comments = DataSource.CommentsList.FirstOrDefault(comment => comment.Id == id) };
        }

        public HttpResponseMessage Post(HttpRequestMessage requestMessage)
        {
            var jsonContent = requestMessage.Content.ReadAsStringAsync().Result;
            // {"comment":{"text":"data...","post":"3"}}
            var jObj = JObject.Parse(jsonContent);
            var comment = jObj.SelectToken("comment", false).ToObject<Comment>();


            var id = 1;
            var lastItem = DataSource.CommentsList.LastOrDefault();
            if (lastItem != null)
            {
                id = lastItem.Id + 1;
            }
            comment.Id = id;
            DataSource.CommentsList.Add(comment);

            // ارسال آي دي با فرمت خاص مهم است
            return Request.CreateResponse(HttpStatusCode.Created, new { comment = comment });
        }


        public HttpResponseMessage Delete(int id)
        {
            var item = DataSource.CommentsList.FirstOrDefault(x => x.Id == id);
            if (item == null)
                return Request.CreateResponse(HttpStatusCode.NotFound);

            DataSource.CommentsList.Remove(item);

            return Request.CreateResponse(HttpStatusCode.OK, new { comment = item });
        }
    }
}