﻿using System.Collections.Generic;

namespace EmberJS03.Models
{
    /// <summary>
    /// منبع داده فرضی جهت سهولت دموی برنامه
    /// </summary>
    public static class DataSource
    {
        private static readonly IList<Post> _cachedItems;
        private static readonly IList<Comment> _commentsList;

        static DataSource()
        {
            _cachedItems = createPostsDataSource();
            _commentsList = createCommentsDataSource();
        }

        public static IList<Comment> CommentsList
        {
            get { return _commentsList; }
        }

        public static IList<Post> PostsList
        {
            get { return _cachedItems; }
        }

        private static IList<Comment> createCommentsDataSource()
        {
            return new List<Comment>
            {
                new Comment
                {
                    Id = 1,
                    Post = 3,
                    Text = "Thanks!"
                },
                new Comment
                {
                    Id = 2,
                    Post = 3,
                    Text = "Good to know that!"
                },
                new Comment
                {
                    Id = 3,
                    Post = 1,
                    Text = "Great!"
                }
            };
        }

        private static IList<Post> createPostsDataSource()
        {
            return new List<Post>
            {
                new Post
                {
                    Id = 1,
                    Title = "Getting Started with Ember.js",
                    Body = "Body 1",
                    //Comments = new[] { 3 }
                },
                new Post
                {
                    Id = 2,
                    Title = "Routes and Templates",
                    Body = "Body 2"
                },
                new Post
                {
                    Id = 3,
                    Title = "Controllers",
                    Body = "Body 3",
                    //Comments = new[] { 1, 2 }
                }
            };
        }
    }
}