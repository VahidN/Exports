﻿namespace EmberJS03.Models
{
    public class Post
    {
        public int Id { set; get; }
        public string Title { set; get; }
        public string Body { set; get; }

        // lazy loading via an array of IDs
        //public int[] Comments { set; get; }

        // load related models via URLs instead of an array of IDs
        // ref. https://github.com/emberjs/data/pull/1371
        public object Links { set; get; }

        public Post()
        {
            Links = new { comments = "comments" }; // api/posts/id/comments
        }
    }
}