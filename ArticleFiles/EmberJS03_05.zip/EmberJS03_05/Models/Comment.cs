﻿namespace EmberJS03.Models
{
    public class Comment
    {
        public int Id { set; get; }
        public int Post { set; get; }
        public string Text { set; get; }
    }
}