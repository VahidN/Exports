﻿DS.RESTAdapter.reopen({
    namespace: 'api'
});