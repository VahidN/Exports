﻿using System.Windows;

namespace TwoViews
{
    /// <summary>
    /// Nothing to do here.  Everything should be in the XAML.
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
    }
}
