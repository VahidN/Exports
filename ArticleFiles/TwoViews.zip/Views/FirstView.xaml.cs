﻿using System.Windows.Controls;

namespace TwoViews.Views
{
    /// <summary>
    /// Nothing to do here.  Everything should be in the XAML.
    /// </summary>
    public partial class SecondView : UserControl
    {
        public SecondView()
        {
            InitializeComponent();
        }
    }
}
