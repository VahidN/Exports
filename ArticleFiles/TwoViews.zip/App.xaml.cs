﻿using System.Windows;

namespace TwoViews
{
    /// <summary>
    /// Nothing to do here either!
    /// </summary>
    public partial class App : Application
    {
    }
}
