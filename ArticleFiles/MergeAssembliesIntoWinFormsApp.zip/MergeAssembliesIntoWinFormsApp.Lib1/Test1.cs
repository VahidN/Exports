﻿
namespace MergeAssembliesIntoWinFormsApp.Lib1
{
    public static class Test1
    {
        public static string GetData()
        {
            return "Test String";
        }
    }
}