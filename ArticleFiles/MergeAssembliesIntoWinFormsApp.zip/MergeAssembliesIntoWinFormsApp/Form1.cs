﻿using System;
using System.Windows.Forms;

namespace MergeAssembliesIntoWinFormsApp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            label1.Text = Lib1.Test1.GetData();
        }
    }
}