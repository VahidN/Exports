﻿using System;
using System.Data.Entity;
using System.Data.Entity.Spatial;
using System.Globalization;
using System.Linq;
using EFGeoTests.Config;
using EFGeoTests.Models;

namespace EFGeoTests
{
    class Program
    {
        static void Main(string[] args)
        {
            startDb();
            addData();
            query();
        }

        private static void query()
        {
            var tehran = createPoint(51.4179604, 35.6884243);

            using (var context = new MyContext())
            {
                // find any locations within 5 kilometers ordered by distance
                var tehranLocation = context.GeoLocations.FirstOrDefault(loc => loc.Location.SpatialEquals(tehran));
                if (tehranLocation != null)
                {
                    Console.WriteLine(tehranLocation.Type);
                }
            }

            using (var context = new MyContext())
            {
                foreach (var location in context.GeoLocations)
                {
                    Console.WriteLine("Location {0} has a {1} distance in meters from Tehran.", location.Name, tehran.Distance(location.Location));
                }
            }

            using (var context = new MyContext())
            {
                // find any locations within 5 kilometers ordered by distance
                var locations = context.GeoLocations
                    .Where(loc => loc.Location.Distance(tehran) < 5000)
                    .OrderBy(loc => loc.Location.Distance(tehran))
                    .ToList();

                foreach (var location in locations)
                {
                    Console.WriteLine(location.Name);
                }
            }
        }

        private static void addData()
        {
            var points = ShapeReader.ReadShapeFile("IranShapeFiles\\places.shp");
            using (var context = new MyContext())
            {
                context.Configuration.AutoDetectChangesEnabled = false;
                context.Configuration.ProxyCreationEnabled = false;
                context.Configuration.ValidateOnSaveEnabled = false;

                if (context.GeoLocations.Any())
                    return;

                foreach (var point in points)
                {
                    context.GeoLocations.Add(new GeoLocation
                    {
                        Name = point.Metadata["name"],
                        Type = point.Metadata["type"],
                        Location = createPoint(point.X, point.Y)
                    });
                }

                context.SaveChanges();
            }
        }

        /// <summary>
        /// Coordinate System (from .prj file): GCS_WGS_1984 (4326)
        /// </summary>
        private static DbGeography createPoint(double longitude, double latitude,  int coordinateSystemId = 4326)
        {
            var text = string.Format(CultureInfo.InvariantCulture.NumberFormat,
                                     "POINT({0} {1})", longitude, latitude);
            return DbGeography.PointFromText(text, coordinateSystemId);
        }

        private static void startDb()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyContext, Configuration>());
            using (var context = new MyContext())
            {
                context.Database.Initialize(force: true);
            }
        }
    }
}
