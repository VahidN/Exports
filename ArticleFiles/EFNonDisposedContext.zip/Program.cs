﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.Entity;
using System.Data.Entity.Infrastructure.Interception;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using EFNonDisposedContext.Config;
using EFNonDisposedContext.Core;

namespace EFNonDisposedContext
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Look at the Output window of VS.NET for more details.");

            DbInterception.Add(new DatabaseInterceptor());
            startDb();

            nonDisposedContext();
            nonDisposedContext();
            nonDisposedContext();
            disposedContext();
            nonDisposedContext();
            disposedContext();
            disposedContext();
            nonDisposedContext();


            prinNonDisposedContexts();
        }

        private static void prinNonDisposedContexts()
        {
            Debug.WriteLine("\nList of non-disposed ObjectContexts:");

            var connectionsTable = UniqueIdExtensions<DbConnection>.RecordedIds;
            var valuesInfo = connectionsTable.GetType().GetProperty("Values", BindingFlags.NonPublic | BindingFlags.Instance);
            var aliveConnectionsKeys = (ICollection<string>)valuesInfo.GetValue(connectionsTable, null);

            var nonDisposedItems = Connections.ConnectionsInfo
                                              .Where(info => info.Status != ConnectionStatus.Disposed &&
                                                             aliveConnectionsKeys.Contains(info.ConnectionId));
            foreach (var connectionInfo in nonDisposedItems)
            {
                Debug.WriteLine("+--------ConnectionId:" + connectionInfo.ConnectionId + "----------+");
                Debug.WriteLine(connectionInfo.StackTrace);
            }
        }

        private static void disposedContext()
        {
            Debug.WriteLine("\nCalling disposedContext();");

            using (var context = new MyContext())
            {
                Debug.WriteLine("Posts count: " + context.BlogPosts.Count());
            }
        }

        private static void nonDisposedContext()
        {
            Debug.WriteLine("\nCalling nonDisposedContext();");

            var context = new MyContext();
            Debug.WriteLine("Posts count: " + context.BlogPosts.Count());
        }

        private static void startDb()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyContext, Configuration>());
            using (var context = new MyContext())
            {
                context.Database.Initialize(force: true);
            }
        }
    }
}