using System.Data.Entity;
using System.Diagnostics;
using EFNonDisposedContext.Models;

namespace EFNonDisposedContext.Config
{
    public class MyContext : DbContext
    {
        public DbSet<User> Users { get; set; }
        public DbSet<BlogPost> BlogPosts { get; set; }

        public MyContext()
            : base("Connection1")
        {
            this.Database.Log = sql => Debug.Write(sql);
        }

        protected override void Dispose(bool disposing)
        {
            Debug.WriteLine("MyContext Dispose() is called.");
            base.Dispose(disposing);
        }
    }
}