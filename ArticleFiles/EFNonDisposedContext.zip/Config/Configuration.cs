﻿using System;
using System.Data.Entity.Migrations;
using EFNonDisposedContext.Models;

namespace EFNonDisposedContext.Config
{
    public class Configuration : DbMigrationsConfiguration<MyContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(MyContext context)
        {
            var rnd = new Random();
            var number = rnd.Next();

            var user1 = new User
            {
                Name = "User " + number
            };

            var post1 = new BlogPost
            {
                Title = "Title " + number,
                Content = "Content " + number,
                User = user1
            };

            context.Users.Add(user1);
            context.BlogPosts.Add(post1);

            base.Seed(context);
        }
    }
}