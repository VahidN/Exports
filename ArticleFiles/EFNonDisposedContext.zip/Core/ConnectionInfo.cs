﻿using System.Collections.Generic;
using System.Data.Common;
using System.Linq;

namespace EFNonDisposedContext.Core
{
    public enum ConnectionStatus
    {
        None,
        Opened,
        Closed,
        Disposed
    }

    public class ConnectionInfo
    {
        public string ConnectionId { set; get; }
        public string StackTrace { set; get; }
        public ConnectionStatus Status { set; get; }

        public override string ToString()
        {
            return string.Format("{0}:{1} [{2}]",ConnectionId, Status, StackTrace);
        }
    }

    public static class Connections
    {
        private static readonly ICollection<ConnectionInfo> _connectionsInfo = new List<ConnectionInfo>();

        public static ICollection<ConnectionInfo> ConnectionsInfo
        {
            get { return _connectionsInfo; }
        }

        public static void AddOrUpdate(ConnectionInfo connection)
        {
            var info = _connectionsInfo.FirstOrDefault(x => x.ConnectionId == connection.ConnectionId);
            if (info!=null)
            {
                info.Status = connection.Status;
            }
            else
            {
                _connectionsInfo.Add(connection);
            }
        }

        public static void AddOrUpdate(DbConnection connection, ConnectionStatus status)
        {
            AddOrUpdate(
                new ConnectionInfo
                {
                    ConnectionId = UniqueIdExtensions<DbConnection>.GetUniqueId(connection),
                    StackTrace = CallingMethod.GetCallingMethodInfo(),
                    Status = status
                });
        }
    }
}