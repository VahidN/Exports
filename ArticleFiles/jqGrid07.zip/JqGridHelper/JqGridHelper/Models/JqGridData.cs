﻿using System.Collections.Generic;

namespace JqGridHelper.Models
{
    public class JqGridData
    {
        /// <summary>
        /// تعداد صفحات
        /// </summary>
        public int Total { get; set; }

        /// <summary>
        /// شماره صفحه جاري
        /// </summary>
        public int Page { get; set; }

        /// <summary>
        /// تعداد كل رديف‌ها
        /// </summary>
        public int Records { get; set; }

        /// <summary>
        /// اطلاعات رديف‌ها
        /// </summary>
        public IList<JqGridRowData> Rows { get; set; }

        /// <summary>
        /// اطلاعاتي اختياري جهت نمايش در فوتر گريد
        /// </summary>
        public object UserData { get; set; }
    }

    public class JqGridRowData
    {
        public int Id { set; get; }
        public IList<string> RowCells { set; get; }
    }
}