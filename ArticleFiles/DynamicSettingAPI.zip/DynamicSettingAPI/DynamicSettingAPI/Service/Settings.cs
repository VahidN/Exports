﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using DynamicSettingAPI.Models;

namespace DynamicSettingAPI.Service
{
    public class Settings:ISettings
    {
        private readonly Lazy<GeneralSettings> _generalSettings;
        public GeneralSettings General { get { return _generalSettings.Value; } }

        private readonly Lazy<SeoSettings> _seoSettings;
        public SeoSettings Seo { get { return _seoSettings.Value; } }

        private readonly IUnitOfWork _unitOfWork;
        public Settings(IUnitOfWork unitOfWork)
        {
            // ARGUMENT CHECKING SKIPPED FOR BREVITY
            _unitOfWork = unitOfWork;
            // 3
            _generalSettings = new Lazy<GeneralSettings>(CreateSettings<GeneralSettings>);
            _seoSettings = new Lazy<SeoSettings>(CreateSettings<SeoSettings>);
        }
        public void Save()
        {
            // only save changes to settings that have been loaded
            if (_generalSettings.IsValueCreated)
                _generalSettings.Value.Save(_unitOfWork);

            if (_seoSettings.IsValueCreated)
                _seoSettings.Value.Save(_unitOfWork);

            _unitOfWork.SaveChanges();
        }
        // 4
        private T CreateSettings<T>() where T : SettingsBase, new()
        {
            var settings = new T();
            settings.Load(_unitOfWork);
            return settings;
        }
    }
}