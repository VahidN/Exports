﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicSettingAPI.Service
{
    public class GeneralSettings : SettingsBase
    {
        public string SiteName { get; set; }
        public string AdminEmail { get; set; }
        public bool RegisterUsersEnabled { get; set; }
    }
}