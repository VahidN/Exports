﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicSettingAPI.Service
{
    public class SeoSettings: SettingsBase
    {
        public string HomeMetaTitle { get; set; }
        public string HomeMetaDescription { get; set; }
        public string MetaKeywords { get; set; }
    }
}