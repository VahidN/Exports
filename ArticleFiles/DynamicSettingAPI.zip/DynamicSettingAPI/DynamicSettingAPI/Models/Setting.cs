﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DynamicSettingAPI.Models
{
    public class Setting
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Value { get; set; }
    }
}