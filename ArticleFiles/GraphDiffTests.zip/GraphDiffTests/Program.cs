﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Data.Entity.Validation;
using GraphDiffTests.Config;
using GraphDiffTests.Models;
using RefactorThis.GraphDiff;

namespace GraphDiffTests
{
    class Program
    {

        // If you are adding a new image it needs to be an owned collection. 
        // Associated collections do not add or modify the right side of the relation.

        // where you have a One-To-Many or One-To-One where the right hand side of the relationship 
        // is owned by the parent. This is defined within the mapping as an OwnedCollection/OwnedEntity.

        // The other scenario is that you have a Many-To-Many, or a One-To-Many and the related record exists 
        // in its own right as it not a defined part of the aggregate you are updating.
        // That scenario is defined as an AssociatedCollection/AssociatedEntity.

        // Associated asks GraphDiff to only change relations 
        // while Owned extends this to change the 
        // referenced entities themselves too (change meaning insert/update/delete).


        // Associated means the entity is not a part of the aggregate to be updated, owned means it is. 
        // This means associations only update the references and owned updates the entity details and 
        // the references. 

        static void Main(string[] args)
        {
            startDb();

            using (var context = new MyContext())
            {
                var user1 = new User { Id = 1, Name = "User 1_1_1" };
                var post1 = new BlogPost { Id = 1, Title = "Title...1_1", Content = "Body...1_1",
                    User = user1, UserId = user1.Id };
                var tags = new List<Tag>
                {
                    new Tag {Id = 1, Name = "Tag1_1"},
                    new Tag {Id=12, Name = "Tag2_1"},
                    new Tag {Name = "Tag3"},
                    new Tag {Name = "Tag4"},
                };
                tags.ForEach(tag => post1.Tags.Add(tag));

                context.UpdateGraph(post1, map => map
                    .OwnedEntity(p => p.User)
                    .OwnedCollection(p => p.Tags)
                    );

                context.SaveChanges();
            }

            Console.WriteLine("Press a key ...");
            Console.Read();
        }

        private static void startDb()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyContext, Configuration>());
            using (var context = new MyContext())
            {
                context.Database.Initialize(force: true);
            }
        }
    }
}