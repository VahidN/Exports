﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace GraphDiffTests.Models
{
    public class Tag
    {
        public int Id { set; get; }

        [StringLength(maximumLength: 450), Required]
        public string Name { set; get; }

        public virtual ICollection<BlogPost> BlogPosts { set; get; } // many-to-many

        public Tag()
        {
            BlogPosts = new List<BlogPost>();
        }
    }
}