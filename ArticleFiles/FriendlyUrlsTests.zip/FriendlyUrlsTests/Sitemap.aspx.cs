﻿using System;

namespace FriendlyUrlsTests.App_Start
{
    public partial class Sitemap : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("Test");
            //Response.End();
        }
    }
}