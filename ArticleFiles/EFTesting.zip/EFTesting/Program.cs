﻿namespace EFTesting
{
    internal class Program
    {
        private static void Main(string[] args)
        {
        }
    }
}