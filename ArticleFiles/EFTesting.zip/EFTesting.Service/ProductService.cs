﻿using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using EFTesting.DataLayer;

namespace EFTesting.Service
{
    //public class ProductService
    //{
    //    public OperationResult Create(Product product)
    //    {
    //        using (var ctx = new Entites())
    //        {
    //            ctx.Products.Add(product);
    //            ctx.SaveChanges();
    //            return new OperationResult("Done!", true);
    //        }
    //    }
    //}
    public class ProductService
    {
        private readonly IDbSet<Product> _products;
        private readonly IUnitOfWork _uow;

        public ProductService(IUnitOfWork uow)
        {
            _uow = uow;
            _products = _uow.Set<Product>();
        }
        public IEnumerable<Product> GetOrderedProducts()
        {
            return _products.OrderBy(x => x.Name).ToList();
        }
    }
}