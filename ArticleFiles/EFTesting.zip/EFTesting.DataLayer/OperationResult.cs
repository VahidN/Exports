﻿namespace EFTesting.DataLayer
{
    public class OperationResult
    {
        public OperationResult(string message, bool isSuccessed)
        {
            Message = message;
            IsSuccessed = isSuccessed;
        }

        public bool IsSuccessed { get; set; }
        public string Message { get; set; }
    }
}