﻿Public Class News
    Inherits System.Web.UI.Page

    Protected Sub Page_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        ltr.Text = " This Is News ID " + Me.Request.RequestContext.RouteData.Values("ID").ToString()
    End Sub

End Class