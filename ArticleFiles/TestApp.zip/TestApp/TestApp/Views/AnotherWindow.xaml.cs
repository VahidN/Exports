﻿namespace TestApp.Views
{
    using Catel.Windows;

    using ViewModels;

    /// <summary>
    /// Interaction logic for AnotherWindow.xaml.
    /// </summary>
    public partial class AnotherWindow : DataWindow
    {
        public AnotherWindow(AnotherWindowViewModel viewModel)
            : base(viewModel)
        {
            InitializeComponent();
        }
    }
}
