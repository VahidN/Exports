﻿namespace TestApp.ViewModels
{
    using Catel.ExceptionHandling;
    using Catel.MVVM;
    using Catel.MVVM.Services;
    using System;
    using System.Threading;

    public class MainWindowViewModel : ViewModelBase
    {
        public MainWindowViewModel()
            : base()
        {
            ShowPleaseWait = new Command(OnShowPleaseWaitExecute);
            ShowAnotherWindowWithShow = new Command(OnShowAnotherWindowWithShowExecute);
            ShowAnotherWindowWithShowDialog = new Command(OnShowAnotherWindowWithShowDialogExecute);
            ShowOpenFile = new Command(OnShowOpenFileExecute);
            ShowSaveFile = new Command(OnShowSaveFileExecute);
            ShowConfirm = new Command(OnShowConfirmExecute);
        }

        public override string Title { get { return "View model title"; } }

        public Command ShowPleaseWait { get; private set; }
        private void OnShowPleaseWaitExecute()
        {
            var pleaseWaitService = GetService<IPleaseWaitService>();
            pleaseWaitService.Show(() =>
            {
                Thread.Sleep(3000);
            });
        }

        public Command ShowAnotherWindowWithShow { get; private set; }
        private void OnShowAnotherWindowWithShowExecute()
        {
            var uiService = GetService<IUIVisualizerService>();
            var viewModel = new AnotherWindowViewModel();
            uiService.Show(viewModel);
        }

        public Command ShowAnotherWindowWithShowDialog { get; private set; }
        private void OnShowAnotherWindowWithShowDialogExecute()
        {
            var uiService = GetService<IUIVisualizerService>();
            var viewModel = new AnotherWindowViewModel();
            uiService.ShowDialog(viewModel);
        }

        public Command ShowOpenFile { get; private set; }
        private void OnShowOpenFileExecute()
        {
            var openFileService = GetService<IOpenFileService>();
            openFileService.Filter = "ZIP files (*.zip)|*.zip";
            openFileService.IsMultiSelect = false;
            openFileService.Title = "Open file";
            if (openFileService.DetermineFile())
            {
                // ?
            }
        }

        public Command ShowSaveFile { get; private set; }
        private void OnShowSaveFileExecute()
        {
            var saveFileService = GetService<ISaveFileService>();
            saveFileService.Filter = "ZIP files (*.zip)|*.zip";
            saveFileService.FileName = "test";
            saveFileService.Title = "Save file";
            if (saveFileService.DetermineFile())
            {
                // ?
            }
        }

        public Command ShowConfirm { get; private set; }
        private void OnShowConfirmExecute()
        {
            var messageService = GetService<IMessageService>();
            if (messageService.Show("Are you sure?", "?", MessageButton.YesNo, MessageImage.Warning) == MessageResult.Yes)
            {
                // ?
            }
        }
    }
}
