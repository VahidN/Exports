﻿namespace TestApp.ViewModels
{
    using Catel.MVVM;

    public class AnotherWindowViewModel : ViewModelBase
    {
        public AnotherWindowViewModel()
        {
        }

        public override string Title { get { return "This is another window!"; } }
    }
}
