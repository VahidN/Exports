using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Reflection;

namespace Console
{
    public class SelectBuilder<T>
    {
        public static Func<T, T> CreateNewStatement(string fields)
        {
            // input parameter "o"
            ParameterExpression xParameter = Expression.Parameter(typeof (T), "o");


            // new statement "new T()"
            NewExpression xNew = Expression.New(typeof (T));

            // create initializers
            List<MemberAssignment> bindings = fields.Split(',').Select(o => o.Trim())
                .Select(o =>
                            {
                                // property "Field1"
                                PropertyInfo property = typeof (T).GetProperty(o);

                                // original value "o.Field1"
                                MemberExpression xOriginal = Expression.Property(xParameter, property);

                                // set value "Field1 = o.Field1"
                                return Expression.Bind(property, xOriginal);
                            }
                ).ToList();

            // initialization "new T { Field1 = o.Field1, Field2 = o.Field2 }"
            MemberInitExpression xInit = Expression.MemberInit(xNew, bindings);

            // expression "o => new T { Field1 = o.Field1, Field2 = o.Field2 }"
            Expression<Func<T, T>> lambda = Expression.Lambda<Func<T, T>>(xInit, xParameter);

            // compile to Func<T, T>
            return lambda.Compile();
        }
    }
}