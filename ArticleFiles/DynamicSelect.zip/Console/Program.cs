﻿using System.Collections.Generic;
using System.Linq;

namespace Console
{
    public class Program
    {
        private static void Main(string[] args)
        {
            System.Console.WriteLine("Specify the desired fields : ");
            System.Console.WriteLine("");
            string fields = System.Console.ReadLine();
            IEnumerable<Student> students = Student.GetStudentSource();
            System.Console.WriteLine("");

            //// Using Dynamic LINQ

            //var result = students.AsQueryable().Select(string.Format("new({0})", fields));
            //foreach ( object value in result)
            //{
            //    System.Console.WriteLine(value);
            //}


            //// Using SelectBuilder 
            IEnumerable<Student> result = students.Select(SelectBuilder<Student>.CreateNewStatement(fields)).ToList();

            foreach (Student student in result)
            {
                System.Console.WriteLine(student.Field1);
            }
            System.Console.ReadKey();
        }
    }
}