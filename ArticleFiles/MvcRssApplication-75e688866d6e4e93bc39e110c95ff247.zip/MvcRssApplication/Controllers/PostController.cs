﻿using System.Web.Mvc;

namespace MvcRssApplication.Controllers
{
    public class PostController : Controller
    {
        public ActionResult Details(int id)
        {
            // todo: query ... show data
            return View();
        }
    }
}
