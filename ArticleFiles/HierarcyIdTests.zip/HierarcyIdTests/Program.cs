﻿using System;
using System.ComponentModel.DataAnnotations;
using System.Data.Entity;
using System.Data.Entity.Hierarchy;
using System.Data.Entity.Migrations;
using System.Linq;

namespace HierarchyIdTests
{
    public class Employee
    {
        public int Id { get; set; }

        [Required, MaxLength(100)]
        public string Name { get; set; }

        [Required]
        public HierarchyId Node { get; set; } // نوع داده جديد
    }

    public class MyContext : DbContext
    {
        public DbSet<Employee> Employees { get; set; }

        public MyContext()
            : base("Connection1")
        {
            this.Database.Log = log => Console.WriteLine(log);
        }
    }

    public class Configuration : DbMigrationsConfiguration<MyContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(MyContext context)
        {
            if (context.Employees.Any())
                return;

            context.Database.ExecuteSqlCommand(
                "ALTER TABLE [dbo].[Employees] ADD NodePath as Node.ToString() persisted");
            context.Database.ExecuteSqlCommand(
                "ALTER TABLE [dbo].[Employees] ADD Level AS Node.GetLevel() persisted");
            context.Database.ExecuteSqlCommand(
                "ALTER TABLE [dbo].[Employees] ADD ManagerNode as Node.GetAncestor(1) persisted");
            context.Database.ExecuteSqlCommand(
                "ALTER TABLE [dbo].[Employees] ADD ManagerNodePath as Node.GetAncestor(1).ToString() persisted");

            context.Database.ExecuteSqlCommand(
                "ALTER TABLE [dbo].[Employees] ADD CONSTRAINT [UK_EmployeeNode] UNIQUE NONCLUSTERED (Node)");
            context.Database.ExecuteSqlCommand(
                "ALTER TABLE [dbo].[Employees]  WITH CHECK ADD CONSTRAINT [EmployeeManagerNodeNodeFK] " +
                "FOREIGN KEY([ManagerNode]) REFERENCES [dbo].[Employees] ([Node])");

            context.Employees.Add(new Employee { Name = "Root", Node = new HierarchyId("/") });
            context.Employees.Add(new Employee { Name = "Emp1", Node = new HierarchyId("/1/") });
            context.Employees.Add(new Employee { Name = "Emp2", Node = new HierarchyId("/2/") });
            context.Employees.Add(new Employee { Name = "Emp3", Node = new HierarchyId("/1/1/") });
            context.Employees.Add(new Employee { Name = "Emp4", Node = new HierarchyId("/1/1/1/") });
            context.Employees.Add(new Employee { Name = "Emp5", Node = new HierarchyId("/2/1/") });
            context.Employees.Add(new Employee { Name = "Emp6", Node = new HierarchyId("/1/2/") });

            base.Seed(context);
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            startDB();

            using (var context = new MyContext())
            {
                Console.WriteLine("\ngetItems OrderByDescending(employee => employee.Node)");

                var employees = context.Employees.OrderByDescending(employee => employee.Node).ToList();
                foreach (var employee in employees)
                {
                    Console.WriteLine("{0} {1}", employee.Id, employee.Node);
                }


                Console.WriteLine("\nGetAncestor(1) of /1/");

                var firstItem = context.Employees.Single(employee => employee.Node == new HierarchyId("/1/"));
                foreach (var item in context.Employees.Where(employee => firstItem.Node == employee.Node.GetAncestor(1)))
                {
                    Console.WriteLine("{0} {1}", item.Id, item.Name);
                }


                var list = context.Employees.Where(
                    employee => employee.Node.IsDescendantOf(new HierarchyId("/1/")) &&
                                employee.Node.GetLevel() == 2).ToList();

                foreach (var item in list)
                {
                    Console.WriteLine("{0} {1}", item.Id, item.Name);
                }

                Console.WriteLine("\nMoving the nodes to different locations");

                var items = context.Employees.Where(employee => employee.Node.IsDescendantOf(new HierarchyId("/1/")))
                    .Select(employee => new
                    {
                        Id = employee.Id,
                        OrigPath = employee.Node,
                        ReparentedValue = employee.Node.GetReparentedValue(new HierarchyId("/1/"), HierarchyId.GetRoot()),
                        Level = employee.Node.GetLevel()
                    }).ToList();

                foreach (var item in items)
                {
                    Console.WriteLine("Id:{0}; OrigPath:{1}; ReparentedValue:{2}; Level:{3}", item.Id, item.OrigPath, item.ReparentedValue, item.Level);
                }
            }


            Console.WriteLine("Press a key...");
            Console.Read();
        }

        private static void startDB()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyContext, Configuration>());
            // Forces initialization of database on model changes.
            using (var context = new MyContext())
            {
                context.Database.Initialize(force: true);
            }
        }
    }
}