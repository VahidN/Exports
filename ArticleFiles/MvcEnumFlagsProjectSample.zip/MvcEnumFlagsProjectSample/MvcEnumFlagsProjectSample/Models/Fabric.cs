﻿using System;
using System.ComponentModel;

namespace MvcEnumFlagsProjectSample.Models
{
    [Flags]
    public enum Fabric
    {
        [Description("پنبه")]
        Cotton = 1,

        [Description("ابریشم")]
        Silk = 2,

        [Description("پشم")]
        Wool = 4,

        [Description("ابریشم مصنوعی")]
        Rayon = 8,

        [Description("پارچه های دیگر")]
        Other = 128
    }
}