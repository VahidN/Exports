﻿namespace MvcEnumFlagsProjectSample.Models
{
public class MyViewModel
{
    public Fabric Fabric { get; set; }
}
}