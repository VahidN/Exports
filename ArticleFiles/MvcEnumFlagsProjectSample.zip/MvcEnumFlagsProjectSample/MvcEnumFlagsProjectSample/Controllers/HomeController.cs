﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcEnumFlagsProjectSample.Models;

namespace MvcEnumFlagsProjectSample.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            Fabric cotWool = Fabric.Cotton | Fabric.Wool;
            int cotWoolValue = (int) cotWool;

            var model = new MyViewModel();
            return View(model);
        }

        [HttpPost]
        public ActionResult Index(MyViewModel model)
        {
            int value = (int) model.Fabric;
            return View(model);
        }
    }
}
