﻿using System;
using System.Windows.Forms;
using WinFormsThemes.Lib;

namespace WinFormsThemes
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();

            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
            menuStrip1.Renderer = new BlueToolStrip();
        }

        private void FrmMain_Load(object sender, EventArgs e)
        {
        }

        private void BlueMenuStripMenuItem_Click(object sender, EventArgs e)
        {
            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
            menuStrip1.Renderer = new BlueMenuStrip();
        }

        private void BlueToolStripMenuItem_Click(object sender, EventArgs e)
        {
            menuStrip1.RenderMode = ToolStripRenderMode.Professional;
            menuStrip1.Renderer = new BlueToolStrip();
        }

        private void ExitMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}