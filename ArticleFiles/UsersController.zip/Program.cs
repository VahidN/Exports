﻿using System.Net.Http.Formatting;
using Microsoft.Owin.Hosting;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace WebApiSelfHostTests
{
    class Program
    {
        const string BaseAddress = "http://localhost:9000/";

        static void Main(string[] args)
        {
            var server = WebApp.Start<Startup>(url: BaseAddress);

            getUsers();
            postUser();

            Console.WriteLine("Press Enter to quit.");
            Console.ReadLine();

            server.Dispose();
        }

        private static void postUser()
        {
            Console.WriteLine("\npostUser()");

            var user = new User
            {
                Id = 1,
                Name = "User 1",
                Type = UserType.Writer
            };

            var client = new HttpClient();
            client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));

            //var response = client.PostAsJsonAsync(BaseAddress + "api/users", user).Result;
            //Console.WriteLine("Response: {0}", response);

            // drop to lower level than "PostAsJsonAsync" for some config
            var jsonMediaTypeFormatter = new JsonMediaTypeFormatter
            {
                SerializerSettings = new JsonSerializerSettings
                {
                    Converters = { new StringEnumConverter() }
                }
            };
            var response = client.PostAsync(BaseAddress + "api/users", user, jsonMediaTypeFormatter).Result;
            Console.WriteLine("Response: {0}", response);
        }

        private static void getUsers()
        {
            Console.WriteLine("getUsers()");

            using (var client = new HttpClient())
            {
                var response = client.GetAsync(BaseAddress + "api/users").Result;
                Console.WriteLine("Response: {0}", response);
                Console.WriteLine("JsonContent (Client Side): {0}", response.Content.ReadAsStringAsync().Result);
            }
        }
    }
}