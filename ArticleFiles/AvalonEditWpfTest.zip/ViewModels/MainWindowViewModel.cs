﻿using System.ComponentModel;

namespace AvalonEditTests.ViewModels
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private string _sourceCode;

        public MainWindowViewModel()
        {
            SourceCode = @"IF db_id(N'testdb2012') IS NOT NULL 
SELECT 1 
ELSE 
SELECT Count(*) FROM sys.databases WHERE [name]=N'testdb2012'";
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public string SourceCode
        {
            get { return _sourceCode; }
            set
            {
                if (_sourceCode == value)
                    return;

                _sourceCode = value;
                NotifyPropertyChanged("SourceCode");
            }
        }

        public void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}