Blogger = Ember.Application.create();
