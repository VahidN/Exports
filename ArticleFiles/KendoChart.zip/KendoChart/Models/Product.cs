﻿namespace KendoChart.Models
{
    public class Product
    {
        public int Id { set; get; }
        public string Name { set; get; }
    }
}