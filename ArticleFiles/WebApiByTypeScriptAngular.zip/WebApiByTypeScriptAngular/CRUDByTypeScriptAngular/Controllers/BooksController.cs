﻿using CRUDByTypeScriptAngular.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace CRUDByTypeScriptAngular.Controllers
{
    public class BooksController : ApiController
    {
        public static BookRepository repository = new BookRepository();

        public BooksController()
        {
            repository.Add(new Book 
            {
                Id=Guid.NewGuid(),
                Name="C#",
                Author="Masoud Pakdel"
            });

            repository.Add(new Book
            {
                Id = Guid.NewGuid(),
                Name = "F#",
                Author = "Masoud Pakdel"
            });

            repository.Add(new Book
            {
                Id = Guid.NewGuid(),
                Name = "TypeScript",
                Author = "Masoud Pakdel"
            });
        }

        public IEnumerable<Book> Get()
        {
            return repository.GetAll().ToArray();
        }

        public Book Get(Guid id)
        {
            Book entity = repository.Get(id);
            if (entity == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return entity;
        }

        public HttpResponseMessage Post(Book value)
        {
            var result = repository.Add(value);
            if (result == null)
            {                
                throw new HttpResponseException(HttpStatusCode.Conflict);
            }
            var response = Request.CreateResponse<Book>(HttpStatusCode.Created, value);
            string uri = Url.Link("DefaultApi", new { id = value.Id });
            response.Headers.Location = new Uri(uri);
            return response;
        }

        public HttpResponseMessage Put(Guid id, Book value)
        {
            value.Id = id;
            var result = repository.Update(value);
            if (result == null)
            {               
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return Request.CreateResponse(HttpStatusCode.NoContent);
        }

        public HttpResponseMessage Delete(Guid id)
        {
            var result = repository.Delete(id);
            if (result == null)
            {
                throw new HttpResponseException(HttpStatusCode.NotFound);
            }
            return Request.CreateResponse(HttpStatusCode.NoContent);
        }

    }
}
