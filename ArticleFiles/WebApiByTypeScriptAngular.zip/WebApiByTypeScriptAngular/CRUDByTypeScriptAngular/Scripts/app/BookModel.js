var Model;
(function (Model) {
    var Book = (function () {
        function Book() {
        }
        return Book;
    })();
    Model.Book = Book;
})(Model || (Model = {}));
//# sourceMappingURL=BookModel.js.map
