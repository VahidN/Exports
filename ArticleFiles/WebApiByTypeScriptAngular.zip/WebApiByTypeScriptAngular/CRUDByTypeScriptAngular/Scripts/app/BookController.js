/// <reference path='AngularModule.ts' />
/// <reference path='BookModel.ts' />
var Books;
(function (Books) {
    var Controller = (function () {
        function Controller($scope, $http) {
            this.httpService = $http;

            this.getAllBooks(function (data) {
                $scope.books = data;
            });

            var controller = this;
        }
        Controller.prototype.getAllBooks = function (successCallback) {
            this.httpService.get('/api/books').success(function (data, status) {
                successCallback(data);
            });
        };
        return Controller;
    })();
    Books.Controller = Controller;
})(Books || (Books = {}));
//# sourceMappingURL=BookController.js.map
