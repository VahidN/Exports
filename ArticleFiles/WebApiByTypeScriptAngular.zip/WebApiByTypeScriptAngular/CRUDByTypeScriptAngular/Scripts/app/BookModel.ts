module Model {
    export class Book {
        Id: string;
        Name: string;
        Author: string;
    }
}
 