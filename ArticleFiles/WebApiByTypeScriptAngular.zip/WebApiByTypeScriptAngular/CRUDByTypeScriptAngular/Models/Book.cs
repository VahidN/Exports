﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRUDByTypeScriptAngular.Models
{
    public class Book : EntityBase
    {
        public string Name { get; set; }
        public string Author { get; set; }
    }
}