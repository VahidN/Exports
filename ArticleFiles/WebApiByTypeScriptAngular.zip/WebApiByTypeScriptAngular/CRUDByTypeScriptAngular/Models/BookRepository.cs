﻿using CRUDByTypeScriptAngular.Models;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace CRUDByTypeScriptAngular.Controllers
{
    public class BookRepository
    {
        private readonly ConcurrentDictionary<Guid, Book> result = new ConcurrentDictionary<Guid, Book>();

        public IQueryable<Book> GetAll()
        {
            return result.Values.AsQueryable();
        }

        public Book Get(Guid id)
        {
            if (!result.ContainsKey(id)) return null;

            Book entity;
            if (!result.TryGetValue(id, out entity)) return null;

            return entity;
        }

        public Book Add(Book entity)
        {
            if (entity.Id == Guid.Empty) entity.Id = Guid.NewGuid();

            if (result.ContainsKey(entity.Id)) return null;

            if (!result.TryAdd(entity.Id, entity)) return null;

            return entity;
        }

        public Book Delete(Guid id)
        {
            Book removedEntity;
            if (!result.ContainsKey(id)) return null;

            if (!result.TryRemove(id, out removedEntity)) return null;

            return removedEntity;
        }

        public Book Update(Book entity)
        {
            if (!result.ContainsKey(entity.Id)) return null;

            result[entity.Id] = entity;

            return entity;
        }
    }
}