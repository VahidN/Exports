﻿using System.ComponentModel.DataAnnotations;

namespace MvcApplication27.Models
{
    public class User
    {
        [Required]
        public string Name { set; get; }
    }
}