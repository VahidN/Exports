﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Weather
{
    public class YahooWeatherRssItem
    {
        public string Day { get; set; }
        public string Low { get; set; }
        public string High { get; set; }
        public int Code { get; set; }
        public string Text { get; set; }
      
    }
}