﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Mvc4TwitterBootStrapTest.Models
{
    public class User
    {
        public int Id { set; get; }

        [DisplayName("نام")]
        [Required(ErrorMessage="لطفا نام را تكميل كنيد")]
        public string Name { set; get; }

        [DisplayName("نام خانوادگي")]
        [Required(ErrorMessage = "لطفا نام خانوادگي را تكميل كنيد")]
        public string LastName { set; get; }

        [DisplayName("فعال است؟")]
        [UIHint("BootstrapBoolean")]
        public bool? IsActive { set; get; }
    }
}