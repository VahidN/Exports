﻿namespace OnlineCustomSignalRWhiteboard.Models
{
    public class Point
    {
        public float X { get; set; }
        public float Y { get; set; }
    }
}