﻿using OnlineCustomSignalRWhiteboard.Models;
using SignalR.Hubs;

namespace OnlineCustomSignalRWhiteboard.Hubs
{
    [HubName("onWhiteboard")]
    public class Whiteboard : Hub
    {
        public void OnDrawPen(Point prev, Point current, string color, int width)
        {
            Clients.drawPen(prev, current, color, width);
        }

        public void ClearBoard()
        {
            Clients.clear();
        }

    }
}