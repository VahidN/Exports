﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Test
{
    public class Products
    {
        public int Id { set; get; }
        public string Name { set; get; }
    }

    public static class GetProducts
    {
        public static IList<Products> Get()
        {
            List<Products> MyProducts = new List<Products>();
            for (int i = 1; i <= 10; i++)
            {
                MyProducts.Add(new Products(){ Id = i , Name = "محصول شماره ی " + i.ToString()});
            }
            return MyProducts;
        }
    }
}