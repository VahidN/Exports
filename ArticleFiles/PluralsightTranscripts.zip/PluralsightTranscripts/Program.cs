﻿namespace PluralsightTranscripts
{
    class Program
    {
        static void Main(string[] args)
        {
            ExtractSubtitle.ConvertToSrt("test.txt");
        }
    }
}