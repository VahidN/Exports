﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ModelBinderExample.Models
{
    public class CustomerInfo
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime BirthDate { get; set; }
    }
}