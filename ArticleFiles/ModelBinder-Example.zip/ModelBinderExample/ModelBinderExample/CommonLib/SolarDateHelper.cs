﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ModelBinderExample.CommonLib
{
    /// <summary>
    /// Common static methods to work with solar date
    /// </summary>
    public static class SolarDateHelper
    {
        /// <summary>
        /// Get current solar date
        /// </summary>
        /// <returns></returns>
        public static string GetSolarDate()
        {
            return GetSolarDate(DateTime.Now);
        }

        /// <summary>
        /// Get DateTime as parameter and convert to solar date
        /// </summary>
        /// <param name="date"></param>
        /// <returns></returns>
        public static string GetSolarDate(DateTime date)
        {
            Persia.SolarDate solarDate = Persia.Calendar.ConvertToPersian(date);
            return solarDate.ToString();
        }
    }
}
