﻿using System.Collections.Generic;
using System.Data.Entity;
using EF_Sample07.DataLayer.Context;
using EF_Sample07.DomainClasses;
using EF_Sample07.ServiceLayer;
using StructureMap;
using StructureMap.Web;

namespace EF_Sample07
{
    class Program
    {
        static void Main(string[] args)
        {
            startDb();

            //todo: در برنامه‌هاي دسكتاپ از حالت هيبريد استفاده نكنيد

            ObjectFactory.Initialize(x =>
            {
                x.For<IUnitOfWork>().Use<Sample07Context>();
                x.For<ICategoryService>().Use<EfCategoryService>();
            });

            using (var container = ObjectFactory.Container.GetNestedContainer()) // كانتكست را به صورت خودكار ديسپوز مي‌كند
            {
                var uow = container.GetInstance<IUnitOfWork>();
                var categoryService = container.GetInstance<ICategoryService>();

                var product1 = new Product {Name = "P100", Price = 100};
                var product2 = new Product {Name = "P200", Price = 200};
                var category1 = new Category
                {
                    Name = "Cat100",
                    Title = "Title100",
                    Products = new List<Product> {product1, product2}
                };
                categoryService.AddNewCategory(category1);
                uow.SaveAllChanges();
            }
        }

        private static void startDb()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<Sample07Context, Configuration>());
            using (var ctx = new Sample07Context())
            {
                ctx.Database.Initialize(force: true);
            }
        }
    }
}
