﻿using System;
using EF_Sample07.ServiceLayer;

namespace EF_Sample07.WebFormsAppSample
{
    public partial class _Default : BasePage
    {
        public IProductService ProductService { set; get; }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                GridView1.DataSource = ProductService.GetAllProducts();
                GridView1.DataBind();
            }
        }
    }
}
