﻿using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using TestHiddenEncrypt.Models;

namespace TestHiddenEncrypt.Controllers
{
    public class ProductController : Controller
    {
        private readonly List<Product> _products;

        public ProductController()
        {
            _products = new List<Product>
          {
              new Product
              {
                  Id = 1,
                  ProductNo = "1",
                  ProductName = "Car"
              },
              new Product
              {
                  Id = 2,
                  ProductNo = "2",
                  ProductName = "Pc"
              }
          };
        }

        [HttpGet]
        public ActionResult Index()
        {
            return View(_products.ToList());
        }

        //
        // GET: /Product/1
        [HttpGet]
        public ActionResult Edit(int id)
        {
            return View(_products.First(a => a.Id == id));
        }

        //
        // POST: /Product/1
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Product product)
        {
            ViewData["DataAfterIncryption"] = product.Id;
            return View(product);
        }

    }
}
