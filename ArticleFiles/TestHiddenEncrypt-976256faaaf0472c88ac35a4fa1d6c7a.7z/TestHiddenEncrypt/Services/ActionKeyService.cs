﻿using System.Collections.Generic;
using System.Linq;
using TestHiddenEncrypt.Models;

namespace TestHiddenEncrypt.Services
{
    public class ActionKeyService : IActionKeyService
    {

        private readonly IList<ActionKey> _actionKeys;

        public ActionKeyService()
        {
            _actionKeys = new List<ActionKey>
            {
                new ActionKey
                {
                    Area = "",
                    Controller = "Product",
                    Action = "Edit",
                    ActionKeyValue = "E702E4C2-A3B9-446A-912F-8DAC6B0444BC",
                }
            };
        }

        public ActionKey GetActionKey(string action, string controller, string area = "")
        {
            area = area ?? "";
            return _actionKeys.First(a =>
                a.Action.ToLower() == action.ToLower() &&
                a.Controller.ToLower() == controller.ToLower() &&
                a.Area.ToLower() == area.ToLower());
        }

    }
}