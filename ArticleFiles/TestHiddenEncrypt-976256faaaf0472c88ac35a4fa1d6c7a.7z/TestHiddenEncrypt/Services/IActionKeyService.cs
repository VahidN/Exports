﻿using TestHiddenEncrypt.Models;

namespace TestHiddenEncrypt.Services
{
    public interface IActionKeyService
    {
        ActionKey GetActionKey(string action, string controller, string area = "");
    }
}