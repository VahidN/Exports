﻿using System;

namespace TestHiddenEncrypt.Helpers
{
    public interface IRijndaelStringEncrypter : IDisposable
    {
        string Encrypt(string value);
        string Decrypt(string value);
    }
}
