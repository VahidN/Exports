﻿using System.IO;
using iTextSharp.tool.xml;
using iTextSharp.tool.xml.css;

namespace XMLWorkerRTLsample
{
    public static class XmlWorkerUtils
    {
        /// <summary>
        /// نحوه تعريف يك فايل سي اس اس خارجي
        /// </summary>
        public static ICssFile GetCssFile(string filePath)
        {
            using (var stream = new FileStream(filePath, FileMode.Open, FileAccess.Read, FileShare.ReadWrite))
            {
                return XMLWorkerHelper.GetCSS(stream);
            }
        }
    }
}