﻿using System.IO;
using System.Text;
using HtmlAgilityPack;

namespace XMLWorkerRTLsample
{
    public static class XHtmlUtils
    {
        public static string ToXHtml(this string htmlContent)
        {
            var sb = new StringBuilder();
            using (var stringWriter = new StringWriter(sb))
            {
                var doc = new HtmlDocument
                {
                    OptionOutputAsXml = true,
                    OptionCheckSyntax = true,
                    OptionFixNestedTags = true,
                    OptionAutoCloseOnEnd = true,
                    OptionDefaultStreamEncoding = Encoding.UTF8
                };
                doc.LoadHtml(htmlContent);
                doc.Save(stringWriter);
                var xhtml = sb.ToString();
                return xhtml;
            }
        }
    }
}