using System;
using System.IO;
using iTextSharp.text;
using iTextSharp.text.pdf;

namespace XMLWorkerRTLsample
{
    public class UnicodeFontProvider : FontFactoryImp
    {
        static UnicodeFontProvider()
        {
            // ��� ���� ����� ����   
            var systemRoot = Environment.GetEnvironmentVariable("SystemRoot");
            FontFactory.Register(Path.Combine(systemRoot, "fonts\\tahoma.ttf"));
            // ��� ���� ���ʝ�� �� �����
            //FontFactory.Register(Path.Combine(Environment.CurrentDirectory, "fonts\\irsans.ttf"));
        }

        public override Font GetFont(string fontname, string encoding, bool embedded, float size, int style,
            BaseColor color, bool cached)
        {
            if (string.IsNullOrWhiteSpace(fontname))
                fontname = "tahoma";
                
            return FontFactory.GetFont(fontname, BaseFont.IDENTITY_H, BaseFont.EMBEDDED, size, style, color);
        }
    }
}