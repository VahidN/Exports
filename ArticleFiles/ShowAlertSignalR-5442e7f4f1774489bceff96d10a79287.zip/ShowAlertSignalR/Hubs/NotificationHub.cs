﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using ShowAlertSignalR.Data;
using ShowAlertSignalR.Models;

namespace ShowAlertSignalR.Hubs
{
    public class NotificationHub : Hub
    {
        private ProductDbContext _dbContext;
        public void SendNotification()
        {
            _dbContext = new ProductDbContext();
            Clients.Others.ShowNotification(_dbContext.Products.Find(_dbContext.Products.Max(p => p.Id)));
        }
    }
}