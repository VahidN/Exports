﻿using System.Data.Entity;
using System.Diagnostics;
using ShowAlertSignalR.Models;

namespace ShowAlertSignalR.Data
{
    public class ProductDbContext : DbContext
    {
        public ProductDbContext() : base("productSample")
        {
            Database.Log = sql => Debug.Write(sql);
        }
        public DbSet<Product> Products { get; set; }
    }
}