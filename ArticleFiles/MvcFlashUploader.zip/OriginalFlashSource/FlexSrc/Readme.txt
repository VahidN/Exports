This folder contains the source for the Flash upload component.  It is built using the Flex sdk. 

To build it, download the Flex 2 sdk (http://labs.adobe.com/technologies/flex/sdk/flex2sdk.html as of this writing).
build: mxmlc.exe FlashFileUpload.mxml


Flex Docs: http://livedocs.adobe.com/flex/201/html/wwhelp/wwhimpl/common/html/wwhelp.htm?context=LiveDocs_Book_Parts&file=apparch_116_14.html
