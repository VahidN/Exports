﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;

namespace EF_General.Models.Ex38
{
    public class User
    {
        public int Id { set; get; }
        public string Name { set; get; }

        public virtual ICollection<Category> Categories { set; get; }
        public virtual ICollection<Product> Products { set; get; }
    }

    public class Category
    {
        public int Id { get; set; }

        [Index(IsUnique = true)]
        [MaxLength(450)]
        [Required]
        public string Name { get; set; }

        [MaxLength(450)]
        public string Title { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; }
        public int? UserId { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }

    public class Product
    {
        public int Id { get; set; }

        [Index(IsUnique = true)]
        [MaxLength(450)]
        [Required]
        public string Name { get; set; }

        public int Price { get; set; }

        [ForeignKey("CategoryId")]
        public virtual Category Category { get; set; }
        public int? CategoryId { get; set; }

        [ForeignKey("UserId")]
        public virtual User User { get; set; }
        public int? UserId { get; set; }
    }

    public class MyContext : DbContext
    {
        public DbSet<Product> Products { set; get; }
        public DbSet<Category> Categories { set; get; }
        public DbSet<User> Users { set; get; }

        public MyContext()
            : base("Connection2")
        {
            this.Database.Log = sql => Console.Write(sql);
        }
    }

    public class Configuration : DbMigrationsConfiguration<MyContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(MyContext context)
        {
            var rnd = new Random();
            var product1 = new Product { Name = "P100" + rnd.Next(2000), Price = 100 };
            var product2 = new Product { Name = "P200" + rnd.Next(2000), Price = 200 };
            var product3 = new Product { Name = "P300" + rnd.Next(2000), Price = 300 };
            var category1 = new Category
            {
                Name = "Cat100" + rnd.Next(2000),
                Title = "Title100",
                Products = new List<Product> { product1, product2, product3 }
            };

            var category2 = new Category
            {
                Name = "Cat200" + rnd.Next(2000),
                Title = "Title200",
                Products = new List<Product> { product1, product2, product3 }
            };

            context.Categories.Add(category1);
            context.Categories.Add(category2);

            base.Seed(context);
        }
    }

    /// <summary>
    /// Call EF_General.Models.Ex38.Test.RunTests();
    /// </summary>
    public static class Test
    {
        public static void RunTests()
        {
            startDb();

            using (var ctx = new MyContext())
            {
                Console.WriteLine("Emits 2 joins to the same table");

                var productsList1 = ctx.Products.Where(product => product.Id > 1)
                    .Include(product => product.Category)
                    .Include(product => product.User)
                    .Where(
                        product =>
                            product.Category.Title.Contains("t") && product.Category.Id > 1 && product.Price > 100)
                    .OrderBy(product => product.Price)
                    .ToList();
                foreach (var product in productsList1)
                {
                    Console.WriteLine(product.Category.Name);
                }
            }

            using (var ctx = new MyContext())
            {
                Console.WriteLine("Test `let` with `Include`");
                var query1 = from product in ctx.Products.Include(product => product.Category)
                                     .Include(product => product.User)
                             let category = product.Category
                             where product.Id > 1
                             where category.Title.Contains("t") && category.Id > 1 && product.Price > 100
                             select product;

                var query1ChainedVersion = ctx.Products.Include(product => product.Category)
                                                .Include(product => product.User)
                                                .Select(product => new { product, category = product.Category })
                                                .Where(@t => @t.product.Id > 1)
                                                .Where(@t => @t.category.Title.Contains("t") && @t.category.Id > 1 && @t.product.Price > 100)
                                                .Select(@t => @t.product);


                var productsList1 = query1.ToList();
                foreach (var item in productsList1)
                {
                    // select n+1
                    Console.WriteLine(item.Category.Name);
                }

                Console.WriteLine("Test `let` without `Include`");
                var query2 = from product in ctx.Products
                             let category = product.Category
                             where product.Id > 1
                             where category.Title.Contains("t") && category.Id > 1 && product.Price > 100
                             select new { product, category };

                var query2ChainedVersion = ctx.Products
                                              .Select(product => new { product, category = product.Category })
                                              .Where(@t => @t.product.Id > 1)
                                              .Where(@t => @t.category.Title.Contains("t") && @t.category.Id > 1 && @t.product.Price > 100)
                                              .Select(@t => new { @t.product , @t.category });

                var productsList2 = query2.ToList();
                foreach (var item in productsList2)
                {
                    Console.WriteLine(item.product.Category.Name);
                }
            }
        }

        private static void startDb()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyContext, Configuration>());
            using (var context = new MyContext())
            {
                context.Database.Initialize(force: true);
            }
        }
    }
}