﻿using System.Text;
using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ReadingTime.Tests
{
    [TestClass]
    public class ReadingTimeTests
    {
        [TestMethod]
        public void TestLessThanOnMin()
        {
            var text = "This is a test.";
            Assert.AreEqual("کمتر از یک دقیقه", text.MinReadTime());
        }

        [TestMethod]
        public void TestLessThan5Min()
        {
            var text = new StringBuilder();
            for (var i = 0; i < (2*180); i++)
            {
                text.Append("Test ");
            }

            Assert.AreEqual("2 دقيقه", text.ToString().MinReadTime());
        }

        [TestMethod]
        public void TestMoreThan1Hour()
        {
            var text = new StringBuilder();
            for (var i = 0; i < (120 * 180); i++)
            {
                text.Append("Test ");
            }

            Assert.AreEqual("2 ساعت", text.ToString().MinReadTime());
        }

        [TestMethod]
        public void TestMoreThan2Hours()
        {
            var text = new StringBuilder();
            for (var i = 0; i < ((120 * 180) + (5*180)); i++)
            {
                text.Append("Test ");
            }

            Assert.AreEqual("2 ساعت و 5 دقيقه", text.ToString().MinReadTime());
        }
    }
}
