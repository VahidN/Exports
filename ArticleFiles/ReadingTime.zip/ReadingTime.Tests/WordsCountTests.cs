﻿using Microsoft.VisualStudio.TestTools.UnitTesting;

namespace ReadingTime.Tests
{
    [TestClass]
    public class WordsCountTests
    {
        [TestMethod]
        public void TestSimpleSpaces()
        {
            const string data = "this is a test.";
            Assert.AreEqual(4, data.WordsCount());
        }

        [TestMethod]
        public void TestSimpleSpacesWithNewLine()
        {
            const string data = "this is a test.\nthis is a test.";
            Assert.AreEqual(8, data.WordsCount());
        }

        [TestMethod]
        public void TestWithComma()
        {
            const string data = "To be or not to be, that is the question.";
            Assert.AreEqual(10, data.WordsCount());
        }

        [TestMethod]
        public void TestInvalidChars()
        {
            const string data = "To be . ! < > ( ) !! !!! , ; : ' ? + -";
            Assert.AreEqual(2, data.WordsCount());
        }

        [TestMethod]
        public void TestInvalidPersianChars()
        {
            const string data = "آزمايش «براي آزمايش» و « براي آزمايش »";
            Assert.AreEqual(6, data.WordsCount());
        }

        [TestMethod]
        public void TestSimpleHtmlSpaces()
        {
            const string data = "<b>this is&nbsp;a&nbsp;&nbsp;test.</b>";
            Assert.AreEqual(4, data.WordsCount());
        }

        [TestMethod]
        public void TestSimpleHtmlSpacesWithNewLine()
        {
            const string data = "<b>this is&nbsp;a&nbsp;&nbsp;test.</b>\n\r<b>this is&nbsp;a&nbsp;&nbsp;test.</b>";
            Assert.AreEqual(8, data.WordsCount());
        }
    }
}