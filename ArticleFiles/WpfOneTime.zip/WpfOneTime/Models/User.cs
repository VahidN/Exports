﻿
namespace WpfOneTime.Models
{
    public class User
    {
        public string Name { set; get; }
    }
}