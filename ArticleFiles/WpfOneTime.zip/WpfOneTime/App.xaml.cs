﻿
namespace WpfOneTime
{
    public partial class App
    {
    }
}