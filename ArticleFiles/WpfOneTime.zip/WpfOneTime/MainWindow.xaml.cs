﻿
namespace WpfOneTime
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();
            new ReflectPropertyDescriptorWindow().Show();
        }
    }
}