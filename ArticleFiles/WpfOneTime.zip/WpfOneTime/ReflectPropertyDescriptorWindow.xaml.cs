﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using System.Windows;
using System.Windows.Threading;

namespace WpfOneTime
{
    public class BindingInfo
    {
        public string TypeName { get; set; }
        public string PropertyName { get; set; }
        public int HandlerCount { get; set; }
    }

    public partial class ReflectPropertyDescriptorWindow
    {
        private DispatcherTimer _timer;

        public ReflectPropertyDescriptorWindow()
        {
            InitializeComponent();
            ReflectProperties = getReflectPropertyDescriptorInfo();
            initTimer();
        }

        private void initTimer()
        {
            _timer = new DispatcherTimer();
            _timer.Interval = TimeSpan.FromMilliseconds(2000);
            _timer.Tick += onTimerTick;
            _timer.Start();
        }

        public static readonly DependencyProperty ReflectPropertiesProperty =
            DependencyProperty.Register("ReflectProperties", typeof(IList<BindingInfo>),
            typeof(ReflectPropertyDescriptorWindow), new PropertyMetadata());

        public IList<BindingInfo> ReflectProperties
        {
            get { return (IList<BindingInfo>)GetValue(ReflectPropertiesProperty); }
            set { SetValue(ReflectPropertiesProperty, value); }
        }

        private void onTimerTick(object sender, EventArgs e)
        {
            ReflectProperties = getReflectPropertyDescriptorInfo();
        }

        /// <summary>
        /// Retrieving the ReflectTypeDescriptionProvider._propertyCache field
        /// </summary>        
        private static IList<BindingInfo> getReflectPropertyDescriptorInfo()
        {
            var results = new List<BindingInfo>();

            var reflectTypeDescriptionProvider = typeof(PropertyDescriptor).Module.GetType("System.ComponentModel.ReflectTypeDescriptionProvider");
            var propertyCacheField = reflectTypeDescriptionProvider.GetField("_propertyCache",
                BindingFlags.Static | BindingFlags.NonPublic);
            if (propertyCacheField == null)
                throw new NullReferenceException("`ReflectTypeDescriptionProvider._propertyCache` not found");

            var propertyCacheItems = propertyCacheField.GetValue(null) as Hashtable;
            if (propertyCacheItems == null)
                return results;

            var valueChangedHandlersField = typeof(PropertyDescriptor).GetField("valueChangedHandlers",
                BindingFlags.Instance | BindingFlags.NonPublic);

            if (valueChangedHandlersField == null)
                return results;

            foreach (DictionaryEntry entry in propertyCacheItems)
            {
                var properties = entry.Value as PropertyDescriptor[];
                if (properties == null)
                    continue;

                foreach (var property in properties)
                {
                    var valueChangedHandlers = valueChangedHandlersField.GetValue(property) as Hashtable;
                    if (valueChangedHandlers != null && valueChangedHandlers.Count != 0)
                        results.Add(new BindingInfo
                            {
                                TypeName = entry.Key.ToString(),
                                PropertyName = property.Name,
                                HandlerCount = valueChangedHandlers.Count
                            });
                }
            }

            return results;
        }
    }
}