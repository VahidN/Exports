﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;
using SampleUniqueIndex.Libraries.UniqueIndex;

namespace SampleUniqueIndex.Models
{
    public class DbInitializer : DropCreateDatabaseIfModelChanges<myDbContext>
    {
        protected override void Seed(myDbContext context)
        {
            context.Users.Add(new User { 
                Email = "Sample@emial.com",
                FirstName = "Sample",
                LastName = "UniqueIndex",
                PersonalCode = "pe13456",
                Username = "sampleUnique"
            });

            context.ExecuteUniqueIndexes();
            base.Seed(context);
        }
    }
}