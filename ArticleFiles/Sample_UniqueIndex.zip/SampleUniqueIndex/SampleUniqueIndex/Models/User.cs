﻿using System;
using System.Collections.Generic;
using System.Data.Entity.ModelConfiguration;
using System.Linq;
using System.Web;
using SampleUniqueIndex.Libraries.UniqueIndex;

namespace SampleUniqueIndex.Models
{
    public class User
    {
        public int Id { get; set; }

        [Unique]
        public string Email { get; set; }

        [Unique("MyUniqueIndex", UniqueIndexOrder.ASC)]
        public string Username { get; set; }

        [Unique(UniqueIndexOrder.DESC)]
        public string PersonalCode { get; set; }

        public string Password { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
    }

    public class UserDbConfig : EntityTypeConfiguration<User>
    {
        public UserDbConfig()
        {
            this.Property(u => u.Email).HasMaxLength(300);
            this.Property(u => u.Username).HasMaxLength(300);
            this.Property(u => u.PersonalCode).HasMaxLength(300);
        }
    }
}