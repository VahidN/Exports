﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using SampleUniqueIndex.Models;

namespace SampleUniqueIndex.Controllers
{
    public class HomeController : Controller
    {
        //
        // GET: /Home/

        public ActionResult Index()
        {
            var db = new myDbContext();
            var model = db.Users.FirstOrDefault();
            return View(model);
        }

    }
}
