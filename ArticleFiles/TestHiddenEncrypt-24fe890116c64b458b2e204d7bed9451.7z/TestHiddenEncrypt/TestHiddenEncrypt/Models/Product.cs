﻿namespace TestHiddenEncrypt.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string ProductNo { get; set; }
        public string ProductName { get; set; }
    }
}