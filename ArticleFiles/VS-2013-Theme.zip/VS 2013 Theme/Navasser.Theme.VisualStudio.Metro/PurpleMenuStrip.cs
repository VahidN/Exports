﻿using System.Drawing;
using System.Windows.Forms;

namespace Navasser.Theme.VisualStudio.Metro
{
    public class PurpleMenuStrip : ToolStripProfessionalRenderer
    {
        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
        {

            var borderColor = ColorTranslator.FromHtml("#FFC354");//For border
            var selectedMenuBackColor = ColorTranslator.FromHtml("#FFC354");
            var menuOpenedBackColor = ColorTranslator.FromHtml("#403C4D");
            var borderPen = new Pen(borderColor);

            if (e.Item.Selected)
            {
                var selectedMenuBrush = new SolidBrush(selectedMenuBackColor);
                var selectedItemBounds = new Rectangle(Point.Empty, e.Item.Size);
                e.Graphics.FillRectangle(selectedMenuBrush, selectedItemBounds);
                e.Graphics.DrawRectangle(borderPen, 0, 0, selectedItemBounds.Width - 1, selectedItemBounds.Height - 1);
                e.Item.BackColor = menuOpenedBackColor;
                
            }
            else
            {
                base.OnRenderMenuItemBackground(e);
                e.ToolStrip.BackColor = ColorTranslator.FromHtml("#403C4D");
            }


        }

        protected override void OnRenderItemText(ToolStripItemTextRenderEventArgs e)
        {
            base.OnRenderItemText(e);
            if (e.Item.Selected)
            {
                e.Item.ForeColor = Color.Black;

            }
            else
            {
                e.Item.ForeColor = ColorTranslator.FromHtml("#959596");
               
            }
        }
    }
}
