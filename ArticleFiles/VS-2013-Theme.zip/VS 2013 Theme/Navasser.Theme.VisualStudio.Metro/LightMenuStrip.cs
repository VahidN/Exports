﻿using System.Drawing;
using System.Windows.Forms;

namespace Navasser.Theme.VisualStudio.Metro
{
    public class LightMenuStrip:ToolStripProfessionalRenderer
    {
        protected override void OnRenderMenuItemBackground(ToolStripItemRenderEventArgs e)
        {

            var borderColor = ColorTranslator.FromHtml("#C9DEF5");//For border
            var selectedMenuBackColor = ColorTranslator.FromHtml("#C9DEF5");
            var menuOpenedBackColor = ColorTranslator.FromHtml("#F6F6F6");
            var borderPen = new Pen(borderColor);

            if (e.Item.Selected)
            {
                var selectedMenuBrush = new SolidBrush(selectedMenuBackColor);
                var selectedItemBounds = new Rectangle(Point.Empty,e.Item.Size);
                e.Graphics.FillRectangle(selectedMenuBrush, selectedItemBounds);
                e.Graphics.DrawRectangle(borderPen, 0, 0, selectedItemBounds.Width - 1, selectedItemBounds.Height - 1);
                e.Item.BackColor = menuOpenedBackColor;
            }
            else
            {
                base.OnRenderMenuItemBackground(e);
                e.ToolStrip.BackColor = ColorTranslator.FromHtml("#F6F6F6");
            }


        }
    }
}
