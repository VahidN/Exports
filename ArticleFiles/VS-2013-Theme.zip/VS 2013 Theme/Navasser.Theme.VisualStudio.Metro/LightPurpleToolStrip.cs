﻿using System.Drawing;
using System.Windows.Forms;

namespace Navasser.Theme.VisualStudio.Metro
{
    public class LightPurpleToolStrip:ToolStripProfessionalRenderer
    {
        protected override void OnRenderToolStripBackground(ToolStripRenderEventArgs e)
        {
            var toolStripBackColor = ColorTranslator.FromHtml("#413d4d");
            var toolStripBrush = new SolidBrush(toolStripBackColor);
            e.Graphics.FillRectangle(toolStripBrush, 0, 0, e.AffectedBounds.Width + 10, e.AffectedBounds.Height);
        }

        protected override void OnRenderButtonBackground(ToolStripItemRenderEventArgs e)
        {
            var selectedMenuBackColor = ColorTranslator.FromHtml("#ff8585");
            var selectedItemBrush = new SolidBrush(selectedMenuBackColor);
            var pressedItemBackColor = ColorTranslator.FromHtml("#ff5454");
            var pressedItemBrush = new SolidBrush(pressedItemBackColor);
            


            if (e.Item.Selected)
            {
                e.Graphics.FillRectangle(selectedItemBrush, 0, 0, e.Item.Width, e.Item.Height);
            }

            if (e.Item.Pressed)
            {
                e.Graphics.FillRectangle(pressedItemBrush, 0, 0, e.Item.Width, e.Item.Height);
            }
        }
    }
}
