﻿using System;
using System.Drawing;
using System.Windows.Forms;
using Navasser.Theme.VisualStudio.Metro;

namespace Client
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void radVs2013_CheckedChanged(object sender, EventArgs e)
        {
            menuStrip1.Renderer = new BlueMenuStrip();
            toolStrip1.Renderer = new BlueToolStrip();
            menuStrip1.BackgroundImage = Properties.Resources.BlueBackground;
            BackColor = ColorTranslator.FromHtml("#D6DBE9");
        }

        private void radVs1_CheckedChanged(object sender, EventArgs e)
        {
            menuStrip1.Renderer = new LightMenuStrip();
            toolStrip1.Renderer = new LightToolStrip();
            menuStrip1.BackgroundImage = Properties.Resources.LightBackground;
            BackColor = ColorTranslator.FromHtml("#EEEEF2");
        }

        private void radSystem_CheckedChanged(object sender, EventArgs e)
        {

            menuStrip1.Renderer = new PurpleMenuStrip();
            toolStrip1.Renderer = new PurpleToolstrip();
            menuStrip1.BackgroundImage = Properties.Resources.PurpleBackGround;
            ForeColor = ColorTranslator.FromHtml("#959596");
            BackColor = ColorTranslator.FromHtml("#1D1A24");

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            toolStrip1.Renderer = new LightPurpleToolStrip();
            menuStrip1.Renderer = new LightPurpleMenuStrip();
            BackColor = ColorTranslator.FromHtml("#1D1A24");
            menuStrip1.BackgroundImage = Properties.Resources.LightPurple;
            this.ForeColor = ColorTranslator.FromHtml("#959596");
        }
    }
}
