﻿namespace Metro
{
    class BlueMenuStreap
    {
    }
}
