﻿
namespace WpfLargeLists
{
    public partial class App
    {
    }
}