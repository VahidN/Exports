﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using WpfLargeLists.Models;
using WpfLargeLists.Utils;

namespace WpfLargeLists.ViewModels
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        /// <summary>
        /// مديريت رويداد كليك برگه اول
        /// </summary>
        public DelegateCommand<string> DoLoadDataTab1 { set; get; }

        /// <summary>
        /// مديريت رويداد كليك برگه دوم
        /// </summary>
        public DelegateCommand<string> DoLoadDataTab2 { set; get; }

        IList<User> _usersTab1;

        /// <summary>
        /// منبع داده برگه اول
        /// </summary>
        public IList<User> UsersTab1
        {
            get { return _usersTab1; }
            set
            {
                _usersTab1 = value;
                NotifyPropertyChanged("UsersTab1");
            }
        }

        IList<User> _usersTab2;
        /// <summary>
        /// منبع داده برگه دوم
        /// </summary>
        public IList<User> UsersTab2
        {
            get { return _usersTab2; }
            set
            {
                _usersTab2 = value;
                NotifyPropertyChanged("UsersTab2");
            }
        }

        /// <summary>
        /// هر دو برگه اول و دوم 1000 ركورد يكساني را دريافت مي‌كنند
        /// </summary>
        public MainWindowViewModel()
        {
            DoLoadDataTab1 = new DelegateCommand<string>(data => UsersTab1 = fillList());
            DoLoadDataTab2 = new DelegateCommand<string>(data => UsersTab2 = fillList());
        }

        private IList<User> fillList()
        {
            var users = new List<User>();
            for (int i = 0; i < 1000; i++)
            {
                users.Add(new User
                {
                    Id = i,
                    FirstName = "user-" + i,
                    LastName = "lName-" + i,
                    Address = "addr-" + i,
                    DateOfBirth = DateTime.Now.AddYears(-20).AddDays(-i)
                });
            }
            return users;
        }

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;
        public void NotifyPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}