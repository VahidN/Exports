﻿
namespace PdfReportSamples.Models
{
    public class Payment
    {
        public int Id { set; get; }
        public long UnitPrice { set; get; }
        public long Credit { set; get; }
        public long Debit { set; get; }
    }
}
