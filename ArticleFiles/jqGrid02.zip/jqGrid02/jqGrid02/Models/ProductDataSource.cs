﻿using System.Collections.Generic;

namespace jqGrid02.Models
{
    /// <summary>
    /// منبع داده فرضي جهت سهولت دموي برنامه
    /// </summary>
    public static class ProductDataSource
    {
        private static readonly IList<Product> _cachedItems;
        static ProductDataSource()
        {
            _cachedItems = createProductsDataSource();
        }

        public static IList<Product> LatestProducts
        {
            get { return _cachedItems; }
        }

        /// <summary>
        /// هدف صرفا تهيه يك منبع داده آزمايشي ساده تشكيل شده در حافظه است
        /// </summary>        
        private static IList<Product> createProductsDataSource()
        {
            var list = new List<Product>();
            for (var i = 0; i < 500; i++)
            {
                list.Add(new Product
                {
                    Id = i + 1,
                    Name = "نام " + (i + 1),
                    Price = i * 1000,
                    Supplier = new Supplier
                    {
                        Id = i + 1,
                        CompanyName = "شركت " + (i + 1),
                        Address = "آدرس " + (i + 1),
                        PostalCode = "كدپستي " + (i + 1),
                        City = "شهر " + (i + 1),
                        Country = "كشور " + (i + 1),
                        Phone = "شماره تماس " + (i + 1),
                        HomePage = "سايت " + (i + 1)
                    }
                });
            }
            return list;
        }
    }
}