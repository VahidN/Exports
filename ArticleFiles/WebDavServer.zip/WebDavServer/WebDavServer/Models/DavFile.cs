﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebDavServer.Models
{
    public class DavFile
    {
        public string Name { get; set; }
        
        public string Href(string webAddress)
        {
            return string.Format("ms-word:ofe|u|http://{0}/xdav/{1}", webAddress, Name);
        }
    }
}