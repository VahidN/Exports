﻿using Accord.MachineLearning.VectorMachines;
using Accord.MachineLearning.VectorMachines.Learning;
using Accord.Statistics.Kernels;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class1_KernelSVM
{
    class Program
    {
        static void Main(string[] args)
        {
            // ایجاد ورودی
            double[][] inputs =
            {
                new double[] { 0, 0 }, // 0 xnor 0: 1 (label +1)
                new double[] { 0, 1 }, // 0 xnor 1: 0 (label -1)
                new double[] { 1, 0 }, // 1 xnor 0: 0 (label -1)
                new double[] { 1, 1 }  // 1 xnor 1: 1 (label +1)
            };

            // خروجی دسته بند ماشین بردار پشتیبان باید -1 یا +1 باشد
            int[] labels =
            {
                // 1,  0,  0, 1
                   1, -1, -1, 1
            };


            // ساخت کرنل
            IKernel kernel = createKernel();

            // ساخت دسته بند به کمک کرنل انتخابی و تنظیم تعداد ویژگی ها ورودی ها به مقدار 2
            KernelSupportVectorMachine machine_svm = new KernelSupportVectorMachine(kernel, 2);
            // معرفی دسته بندمان به الگوریتم یادگیری SMO
            SequentialMinimalOptimization teacher_smo = new SequentialMinimalOptimization(machine_svm, inputs, labels);

            // اجرای الگوریتم یادگیری
            double error = teacher_smo.Run();
            Console.WriteLine(string.Format("error rate : {0}", error));


            // بررسی یکی از ورودی ها
            int decision = System.Math.Sign(machine_svm.Compute(inputs[0]));
            Console.WriteLine(string.Format("result for sample '0 xnor 0' is : {0}", decision));

            Console.ReadKey();
        }

        private static IKernel createKernel()
        {
            //var numPolyConstant = 1;
            //return new Linear(numPolyConstant);            

            //var numDegree = 2;
            //var numPolyConstant = 1;
            //return new Polynomial(numDegree, numPolyConstant);

            //var numLaplacianSigma = 1000;
            //return new Laplacian(numLaplacianSigma);

            //var numSigAlpha = 7;
            //var numSigB = 6;
            //return new Sigmoid(numSigAlpha, numSigB);

            var numSigma = 0.1;
            return new Gaussian(numSigma);
        }
    }
}
