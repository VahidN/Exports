Format: Spaced For Quick Selection And Analysis
   - 3 space tab
    - monospaced font (ie courier new)


-- -------------------
--  Tables
-- -------------------
CREATE TABLE admin_assert (
      `assert_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`assert_type`                                                                                        varchar(20)                                               NOT NULL        default ""
     ,`assert_data`                                                                                        text
  ,PRIMARY KEY (assert_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ACL Asserts';

CREATE TABLE admin_role (
      `role_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`tree_level`                                                                                         tinyint(3)        unsigned                                NOT NULL        default "0"
     ,`sort_order`                                                                                         tinyint(3)        unsigned                                NOT NULL        default "0"
     ,`role_type`                                                                                          char(1)                                                   NOT NULL        default "0"
     ,`user_id`                                                                                            int(11)           unsigned                                NOT NULL        default "0"
     ,`role_name`                                                                                          varchar(50)                                               NOT NULL        default ""
  ,PRIMARY KEY (role_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ACL Roles';

CREATE TABLE admin_rule (
      `rule_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`role_id`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`resource_id`                                                                                        varchar(255)                                              NOT NULL        default ""
     ,`privileges`                                                                                         varchar(20)                                               NOT NULL        default ""
     ,`assert_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`role_type`                                                                                          char(1)                                                                   default NULL
     ,`permission`                                                                                         varchar(10)                                                               default NULL
  ,PRIMARY KEY (rule_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ACL Rules';

CREATE TABLE admin_user (
      `user_id`                                                                                            mediumint(9)      unsigned                                NOT NULL        auto_increment
     ,`firstname`                                                                                          varchar(32)                                               NOT NULL        default ""
     ,`lastname`                                                                                           varchar(32)                                               NOT NULL        default ""
     ,`email`                                                                                              varchar(128)                                              NOT NULL        default ""
     ,`username`                                                                                           varchar(40)                                               NOT NULL        default ""
     ,`password`                                                                                           varchar(40)                                               NOT NULL        default ""
     ,`created`                                                                                            datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`modified`                                                                                           datetime                                                                  default NULL
     ,`logdate`                                                                                            datetime                                                                  default NULL
     ,`lognum`                                                                                             smallint(5)       unsigned                                NOT NULL        default "0"
     ,`reload_acl_flag`                                                                                    tinyint(1)                                                NOT NULL        default "0"
     ,`is_active`                                                                                          tinyint(1)                                                NOT NULL        default "1"
     ,`extra`                                                                                              text
  ,PRIMARY KEY (user_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Users';

CREATE TABLE catalog_category_entity (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`path`                                                                                               varchar(255)                                              NOT NULL        default ""
     ,`position`                                                                                           int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Category Entityies';

CREATE TABLE catalog_category_entity_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_category_entity_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_category_entity_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_category_entity_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_category_entity_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_category_product (
      `category_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`position`                                                                                           int(10)           unsigned                                NOT NULL        default "0"
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_compare_item (
      `catalog_compare_item_id`                                                                            int(11)           unsigned                                NOT NULL        auto_increment
     ,`visitor_id`                                                                                         int(11)           unsigned                                NOT NULL        default "0"
     ,`customer_id`                                                                                        int(11)           unsigned                                                default NULL
     ,`product_id`                                                                                         int(11)           unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (catalog_compare_item_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_bundle_option (
      `option_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (option_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_bundle_option_link (
      `link_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`option_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`discount`                                                                                           decimal(10,4)     unsigned                                                default NULL
  ,PRIMARY KEY (link_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_bundle_option_value (
      `value_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`option_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`label`                                                                                              varchar(255)                                                              default NULL
     ,`position`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_entity (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`type_id`                                                                                            varchar(32)                                               NOT NULL        default "simple"
     ,`sku`                                                                                                varchar(64)                                                               default NULL
     ,`category_ids`                                                                                       text
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Product Entityies';

CREATE TABLE catalog_product_entity_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_entity_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_entity_gallery (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`position`                                                                                           int(11)                                                   NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_entity_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     mediumint(8)      unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_entity_media_gallery (
      `value_id`                                                                                           int(11)           unsigned                                NOT NULL        auto_increment
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                                              default NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog product media gallery';

CREATE TABLE catalog_product_entity_media_gallery_value (
      `value_id`                                                                                           int(11)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`label`                                                                                              varchar(255)                                                              default NULL
     ,`position`                                                                                           int(11)           unsigned                                                default NULL
     ,`disabled`                                                                                           tinyint(1)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (value_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog product media gallery values';

CREATE TABLE catalog_product_entity_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     mediumint(8)      unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_entity_tier_price (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`all_groups`                                                                                         tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`customer_group_id`                                                                                  smallint(5)       unsigned                                NOT NULL        default "0"
     ,`qty`                                                                                                decimal(12,4)                                             NOT NULL        default "1.0000"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_entity_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     mediumint(8)      unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_link (
      `link_id`                                                                                            int(11)           unsigned                                NOT NULL        auto_increment
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`linked_product_id`                                                                                  int(10)           unsigned                                NOT NULL        default "0"
     ,`link_type_id`                                                                                       tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (link_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Related products';

CREATE TABLE catalog_product_link_attribute (
      `product_link_attribute_id`                                                                          smallint(6)       unsigned                                NOT NULL        auto_increment
     ,`link_type_id`                                                                                       tinyint(3)        unsigned                                NOT NULL        default "0"
     ,`product_link_attribute_code`                                                                        varchar(32)                                               NOT NULL        default ""
     ,`data_type`                                                                                          varchar(32)                                               NOT NULL        default ""
  ,PRIMARY KEY (product_link_attribute_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Attributes for product link';

CREATE TABLE catalog_product_link_attribute_decimal (
      `value_id`                                                                                           int(11)           unsigned                                NOT NULL        auto_increment
     ,`product_link_attribute_id`                                                                          smallint(6)       unsigned                                                default NULL
     ,`link_id`                                                                                            int(11)           unsigned                                                default NULL
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Decimal attributes values';

CREATE TABLE catalog_product_link_attribute_int (
      `value_id`                                                                                           int(11)           unsigned                                NOT NULL        auto_increment
     ,`product_link_attribute_id`                                                                          smallint(6)       unsigned                                                default NULL
     ,`link_id`                                                                                            int(11)           unsigned                                                default NULL
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_link_attribute_varchar (
      `value_id`                                                                                           int(11)           unsigned                                NOT NULL        auto_increment
     ,`product_link_attribute_id`                                                                          smallint(6)       unsigned                                NOT NULL        default "0"
     ,`link_id`                                                                                            int(11)           unsigned                                                default NULL
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Varchar attributes values';

CREATE TABLE catalog_product_link_type (
      `link_type_id`                                                                                       tinyint(3)        unsigned                                NOT NULL        auto_increment
     ,`code`                                                                                               varchar(32)                                               NOT NULL        default ""
  ,PRIMARY KEY (link_type_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Types of product link (Related, superproduct, bundles)';

CREATE TABLE catalog_product_super_attribute (
      `product_super_attribute_id`                                                                         int(10)           unsigned                                NOT NULL        auto_increment
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`position`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (product_super_attribute_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_super_attribute_label (
      `value_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`product_super_attribute_id`                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_super_attribute_pricing (
      `value_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`product_super_attribute_id`                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`value_index`                                                                                        varchar(255)                                              NOT NULL        default ""
     ,`is_percent`                                                                                         tinyint(1)        unsigned                                                default "0                                                                  "
     ,`pricing_value`                                                                                      decimal(10,4)                                                             default NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_super_link (
      `link_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (link_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalog_product_website (
      `product_id`                                                                                         int(10)           unsigned                                NOT NULL        auto_increment
     ,`website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (product_id,website_id)
)  ENGINE=MyISAM AUTO_INCREMENT=136 DEFAULT CHARSET=utf8;

CREATE TABLE catalogindex_eav (
      `index_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (index_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalogindex_minimal_price (
      `index_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`customer_group_id`                                                                                  smallint(3)       unsigned                                NOT NULL        default "0"
     ,`qty`                                                                                                decimal(12,4)     unsigned                                NOT NULL        default "0.0000"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (index_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalogindex_price (
      `index_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`customer_group_id`                                                                                  smallint(3)       unsigned                                NOT NULL        default "0"
     ,`qty`                                                                                                decimal(12,4)     unsigned                                NOT NULL        default "0.0000"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (index_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE cataloginventory_stock (
      `stock_id`                                                                                           smallint(4)       unsigned                                NOT NULL        auto_increment
     ,`stock_name`                                                                                         varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (stock_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Catalog inventory Stocks list';

CREATE TABLE cataloginventory_stock_item (
      `item_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`stock_id`                                                                                           smallint(4)       unsigned                                NOT NULL        default "0"
     ,`qty`                                                                                                decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`min_qty`                                                                                            decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`use_config_min_qty`                                                                                 tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`is_qty_decimal`                                                                                     tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`backorders`                                                                                         tinyint(3)        unsigned                                NOT NULL        default "0"
     ,`use_config_backorders`                                                                              tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`min_sale_qty`                                                                                       decimal(12,4)                                             NOT NULL        default "1.0000"
     ,`use_config_min_sale_qty`                                                                            tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`max_sale_qty`                                                                                       decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`use_config_max_sale_qty`                                                                            tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`is_in_stock`                                                                                        tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`low_stock_date`                                                                                     datetime                                                                  default NULL
     ,`notify_stock_qty`                                                                                   decimal(12,4)                                                             default NULL
     ,`use_config_notify_stock_qty`                                                                        tinyint(1)        unsigned                                NOT NULL        default "1"
  ,PRIMARY KEY (item_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Invetory Stock Item Data';

CREATE TABLE catalogrule (
      `rule_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`name`                                                                                               varchar(255)                                              NOT NULL        default ""
     ,`description`                                                                                        text                                                      NOT NULL
     ,`from_date`                                                                                          date                                                                      default NULL
     ,`to_date`                                                                                            date                                                                      default NULL
     ,`customer_group_ids`                                                                                 varchar(255)                                              NOT NULL        default ""
     ,`is_active`                                                                                          tinyint(1)                                                NOT NULL        default "0"
     ,`conditions_serialized`                                                                              text                                                      NOT NULL
     ,`actions_serialized`                                                                                 text                                                      NOT NULL
     ,`stop_rules_processing`                                                                              tinyint(1)                                                NOT NULL        default "1"
     ,`sort_order`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`simple_action`                                                                                      varchar(32)                                               NOT NULL        default ""
     ,`discount_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`website_ids`                                                                                        text
  ,PRIMARY KEY (rule_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalogrule_product (
      `rule_product_id`                                                                                    int(10)           unsigned                                NOT NULL        auto_increment
     ,`rule_id`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`from_time`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`to_time`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`customer_group_id`                                                                                  smallint(5)       unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`action_operator`                                                                                    enum("to_fixed","to_percent","by_fixed","by_percent")     NOT NULL        default "to_fixed"
     ,`action_amount`                                                                                      decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`action_stop`                                                                                        tinyint(1)                                                NOT NULL        default "0"
     ,`sort_order`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (rule_product_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalogrule_product_price (
      `rule_product_price_id`                                                                              int(10)           unsigned                                NOT NULL        auto_increment
     ,`rule_date`                                                                                          date                                                      NOT NULL        default "0000-00-00"
     ,`customer_group_id`                                                                                  smallint(5)       unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`rule_price`                                                                                         decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`latest_start_date`                                                                                  date                                                                      default NULL
     ,`earliest_end_date`                                                                                  date                                                                      default NULL
  ,PRIMARY KEY (rule_product_price_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE catalogsearch_query (
      `query_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`query_text`                                                                                         varchar(255)                                              NOT NULL        default ""
     ,`num_results`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`popularity`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`redirect`                                                                                           varchar(255)                                              NOT NULL        default ""
     ,`synonim_for`                                                                                        varchar(255)                                              NOT NULL        default ""
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`display_in_terms`                                                                                   tinyint(1)                                                NOT NULL        default "1"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (query_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE cms_block (
      `block_id`                                                                                           smallint(6)                                               NOT NULL        auto_increment
     ,`title`                                                                                              varchar(255)                                              NOT NULL        default ""
     ,`identifier`                                                                                         varchar(255)                                              NOT NULL        default ""
     ,`content`                                                                                            text
     ,`creation_time`                                                                                      datetime                                                                  default NULL
     ,`update_time`                                                                                        datetime                                                                  default NULL
     ,`is_active`                                                                                          tinyint(1)                                                NOT NULL        default "1"
  ,PRIMARY KEY (block_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Blocks';

CREATE TABLE cms_block_store (
      `block_id`                                                                                           smallint(6)                                               NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (block_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Blocks to Stores';

CREATE TABLE cms_page (
      `page_id`                                                                                            smallint(6)                                               NOT NULL        auto_increment
     ,`title`                                                                                              varchar(255)                                              NOT NULL        default ""
     ,`root_template`                                                                                      varchar(255)                                              NOT NULL        default ""
     ,`meta_keywords`                                                                                      text                                                      NOT NULL
     ,`meta_description`                                                                                   text                                                      NOT NULL
     ,`identifier`                                                                                         varchar(100)                                              NOT NULL        default ""
     ,`content`                                                                                            text
     ,`creation_time`                                                                                      datetime                                                                  default NULL
     ,`update_time`                                                                                        datetime                                                                  default NULL
     ,`is_active`                                                                                          tinyint(1)                                                NOT NULL        default "1"
     ,`sort_order`                                                                                         tinyint(4)                                                NOT NULL        default "0"
     ,`layout_update_xml`                                                                                  text
     ,`custom_theme`                                                                                       varchar(100)                                                              default NULL
     ,`custom_theme_from`                                                                                  date                                                                      default NULL
     ,`custom_theme_to`                                                                                    date                                                                      default NULL
  ,PRIMARY KEY (page_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS pages';

CREATE TABLE cms_page_store (
      `page_id`                                                                                            smallint(6)                                               NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (page_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='CMS Pages to Stores';

CREATE TABLE core_config_data (
      `config_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`scope`                                                                                              enum("default","websites","stores","config")              NOT NULL        default "default"
     ,`scope_id`                                                                                           int(11)                                                   NOT NULL        default "0"
     ,`path`                                                                                               varchar(255)                                              NOT NULL        default "general"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (config_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE core_email_template (
      `template_id`                                                                                        int(7)            unsigned                                NOT NULL        auto_increment
     ,`template_code`                                                                                      varchar(150)                                                              default NULL
     ,`template_text`                                                                                      text
     ,`template_type`                                                                                      int(3)            unsigned                                                default NULL
     ,`template_subject`                                                                                   varchar(200)                                                              default NULL
     ,`template_sender_name`                                                                               varchar(200)                                                              default NULL
     ,`template_sender_email`                                                                              varchar(200)                                                              default NULL
     ,`added_at`                                                                                           datetime                                                                  default NULL
     ,`modified_at`                                                                                        datetime                                                                  default NULL
  ,PRIMARY KEY (template_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Email templates';

CREATE TABLE core_layout_link (
      `layout_link_id`                                                                                     int(10)           unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`package`                                                                                            varchar(64)                                               NOT NULL        default ""
     ,`theme`                                                                                              varchar(64)                                               NOT NULL        default ""
     ,`layout_update_id`                                                                                   int(10)           unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (layout_link_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE core_layout_update (
      `layout_update_id`                                                                                   int(10)           unsigned                                NOT NULL        auto_increment
     ,`handle`                                                                                             varchar(255)                                                              default NULL
     ,`xml`                                                                                                text
  ,PRIMARY KEY (layout_update_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE core_resource (
      `code`                                                                                               varchar(50)                                               NOT NULL        default ""
     ,`version`                                                                                            varchar(50)                                               NOT NULL        default ""
  ,PRIMARY KEY (code)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Resource version registry';

CREATE TABLE core_session (
      `session_id`                                                                                         varchar(255)                                              NOT NULL        default ""
     ,`website_id`                                                                                         smallint(5)       unsigned                                                default NULL
     ,`session_expires`                                                                                    int(10)           unsigned                                NOT NULL        default "0"
     ,`session_data`                                                                                       text                                                      NOT NULL
  ,PRIMARY KEY (session_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Session data store';

CREATE TABLE core_store (
      `store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`code`                                                                                               varchar(32)                                               NOT NULL        default ""
     ,`website_id`                                                                                         smallint(5)       unsigned                                                default "0"
     ,`group_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`name`                                                                                               varchar(32)                                               NOT NULL        default ""
     ,`sort_order`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Stores';

CREATE TABLE core_store_group (
      `group_id`                                                                                           smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`name`                                                                                               varchar(32)                                               NOT NULL        default ""
     ,`root_category_id`                                                                                   int(10)           unsigned                                NOT NULL        default "0"
     ,`default_store_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (group_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE core_translate (
      `key_id`                                                                                             int(10)           unsigned                                NOT NULL        auto_increment
     ,`string`                                                                                             varchar(255)                                              NOT NULL        default ""
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`translate`                                                                                          varchar(255)                                              NOT NULL        default ""
     ,`locale`                                                                                             varchar(20)                                               NOT NULL        default "en_US"
  ,PRIMARY KEY (key_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Translation data';

CREATE TABLE core_url_rewrite (
      `url_rewrite_id`                                                                                     int(10)           unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`category_id`                                                                                        int(10)           unsigned                                                default NULL
     ,`product_id`                                                                                         int(10)           unsigned                                                default NULL
     ,`id_path`                                                                                            varchar(255)                                              NOT NULL        default ""
     ,`request_path`                                                                                       varchar(255)                                              NOT NULL        default ""
     ,`target_path`                                                                                        varchar(255)                                              NOT NULL        default ""
     ,`is_system`                                                                                          tinyint(1)        unsigned                                                default "1                                                                  "
     ,`options`                                                                                            varchar(255)                                              NOT NULL        default ""
     ,`description`                                                                                        varchar(255)                                                              default NULL
  ,PRIMARY KEY (url_rewrite_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE core_website (
      `website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`code`                                                                                               varchar(32)                                               NOT NULL        default ""
     ,`name`                                                                                               varchar(64)                                               NOT NULL        default ""
     ,`sort_order`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`default_group_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`is_default`                                                                                         tinyint(1)        unsigned                                                default "0"

  ,PRIMARY KEY (website_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Websites';

CREATE TABLE cron_schedule (
      `schedule_id`                                                                                        int(10)           unsigned                                NOT NULL        auto_increment
     ,`job_code`                                                                                           varchar(255)                                              NOT NULL        default "0"
     ,`status`                                                                                             enum("pending","running","success","missed","error")      NOT NULL        default "pending"
     ,`messages`                                                                                           text
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`scheduled_at`                                                                                       datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`executed_at`                                                                                        datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`finished_at`                                                                                        datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (schedule_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_address_entity (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`increment_id`                                                                                       varchar(50)                                               NOT NULL        default ""
     ,`parent_id`                                                                                          int(10)           unsigned                                                default NULL
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customer Address Entityies';

CREATE TABLE customer_address_entity_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_address_entity_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_address_entity_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_address_entity_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_address_entity_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_entity (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`website_id`                                                                                         smallint(5)       unsigned                                                default NULL
     ,`email`                                                                                              varchar(255)                                              NOT NULL        default ""
     ,`group_id`                                                                                           smallint(3)       unsigned                                NOT NULL        default "0"
     ,`increment_id`                                                                                       varchar(50)                                               NOT NULL        default ""
     ,`store_id`                                                                                           smallint(5)       unsigned                                                default "0"
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customer Entityies';

CREATE TABLE customer_entity_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_entity_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_entity_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_entity_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_entity_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE customer_group (
      `customer_group_id`                                                                                  smallint(3)       unsigned                                NOT NULL        auto_increment
     ,`customer_group_code`                                                                                varchar(32)                                               NOT NULL        default ""
     ,`tax_class_id`                                                                                       int(10)           unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (customer_group_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Customer groups';

CREATE TABLE dataflow_batch (
      `batch_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`profile_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`adapter`                                                                                            varchar(128)                                                              default NULL
     ,`created_at`                                                                                         datetime                                                                  default NULL
  ,PRIMARY KEY (batch_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE dataflow_batch_export (
      `batch_export_id`                                                                                    bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`batch_id`                                                                                           int(10)           unsigned                                NOT NULL        default "0"
     ,`batch_data`                                                                                         longtext
     ,`status`                                                                                             tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (batch_export_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE dataflow_batch_import (
      `batch_import_id`                                                                                    bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`batch_id`                                                                                           int(10)           unsigned                                NOT NULL        default "0"
     ,`batch_data`                                                                                         longtext
     ,`status`                                                                                             tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (batch_import_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE dataflow_import_data (
      `import_id`                                                                                          int(11)                                                   NOT NULL        auto_increment
     ,`session_id`                                                                                         int(11)                                                                   default NULL
     ,`serial_number`                                                                                      int(11)                                                   NOT NULL        default "0"
     ,`value`                                                                                              text
     ,`status`                                                                                             int(1)                                                    NOT NULL        default "0"
  ,PRIMARY KEY (import_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE dataflow_profile (
      `profile_id`                                                                                         int(10)           unsigned                                NOT NULL        auto_increment
     ,`name`                                                                                               varchar(255)                                              NOT NULL        default ""
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`actions_xml`                                                                                        text
     ,`gui_data`                                                                                           text
     ,`direction`                                                                                          enum("import","export")                                                   default NULL
     ,`entity_type`                                                                                        varchar(64)                                               NOT NULL        default ""
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`data_transfer`                                                                                      enum("file","interactive")                                                default NULL
  ,PRIMARY KEY (profile_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE dataflow_profile_history (
      `history_id`                                                                                         int(10)           unsigned                                NOT NULL        auto_increment
     ,`profile_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`action_code`                                                                                        varchar(64)                                                               default NULL
     ,`user_id`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`performed_at`                                                                                       datetime                                                                  default NULL
  ,PRIMARY KEY (history_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE dataflow_session (
      `session_id`                                                                                         int(11)                                                   NOT NULL        auto_increment
     ,`user_id`                                                                                            int(11)                                                   NOT NULL        default "0"
     ,`created_date`                                                                                       datetime                                                                  default NULL
     ,`file`                                                                                               varchar(255)                                                              default NULL
     ,`type`                                                                                               varchar(32)                                                               default NULL
     ,`direction`                                                                                          varchar(32)                                                               default NULL
     ,`comment`                                                                                            varchar(255)                                                              default NULL
  ,PRIMARY KEY (session_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE design_change (
      `design_change_id`                                                                                   int(11)                                                   NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`design`                                                                                             varchar(255)                                              NOT NULL        default ""
     ,`date_from`                                                                                          date                                                      NOT NULL        default "0000-00-00"
     ,`date_to`                                                                                            date                                                      NOT NULL        default "0000-00-00"
  ,PRIMARY KEY (design_change_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE directory_country (
      `country_id`                                                                                         varchar(2)                                                NOT NULL        default ""
     ,`iso2_code`                                                                                          varchar(2)                                                NOT NULL        default ""
     ,`iso3_code`                                                                                          varchar(3)                                                NOT NULL        default ""
  ,PRIMARY KEY (country_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Countries';

CREATE TABLE directory_country_format (
      `country_format_id`                                                                                  int(10)           unsigned                                NOT NULL        auto_increment
     ,`country_id`                                                                                         varchar(2)                                                NOT NULL        default ""
     ,`type`                                                                                               varchar(30)                                               NOT NULL        default ""
     ,`format`                                                                                             text                                                      NOT NULL
  ,PRIMARY KEY (country_format_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Countries format';

CREATE TABLE directory_country_region (
      `region_id`                                                                                          mediumint(8)      unsigned                                NOT NULL        auto_increment
     ,`country_id`                                                                                         varchar(4)                                                NOT NULL        default "0"
     ,`code`                                                                                               varchar(32)                                               NOT NULL        default ""
     ,`default_name`                                                                                       varchar(255)                                                              default NULL
  ,PRIMARY KEY (region_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Country regions';

CREATE TABLE directory_country_region_name (
      `locale`                                                                                             varchar(8)                                                NOT NULL        default ""
     ,`region_id`                                                                                          mediumint(8)      unsigned                                NOT NULL        default "0"
     ,`name`                                                                                               varchar(64)                                               NOT NULL        default ""
  ,PRIMARY KEY (locale,region_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Regions names';

CREATE TABLE directory_currency_rate (
      `currency_from`                                                                                      char(3)                                                   NOT NULL        default ""
     ,`currency_to`                                                                                        char(3)                                                   NOT NULL        default ""
     ,`rate`                                                                                               decimal(24,12)                                            NOT NULL        default "0.000000000000"
  ,PRIMARY KEY (currency_from,currency_to)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE eav_attribute (
      `attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_code`                                                                                     varchar(255)                                              NOT NULL        default ""
     ,`attribute_model`                                                                                    varchar(255)                                                              default NULL
     ,`backend_model`                                                                                      varchar(255)                                                              default NULL
     ,`backend_type`                                                                                       enum("static","datetime","decimal","int","text","varchar")NOT NULL        default "static"
     ,`backend_table`                                                                                      varchar(255)                                                              default NULL
     ,`frontend_model`                                                                                     varchar(255)                                                              default NULL
     ,`frontend_input`                                                                                     varchar(50)                                                               default NULL
     ,`frontend_label`                                                                                     varchar(255)                                                              default NULL
     ,`frontend_class`                                                                                     varchar(255)                                                              default NULL
     ,`source_model`                                                                                       varchar(255)                                                              default NULL
     ,`is_global`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`is_visible`                                                                                         tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`is_required`                                                                                        tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`is_user_defined`                                                                                    tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`default_value`                                                                                      text
     ,`is_searchable`                                                                                      tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`is_filterable`                                                                                      tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`is_comparable`                                                                                      tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`is_visible_on_front`                                                                                tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`is_unique`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`is_configurable`                                                                                    tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`apply_to`                                                                                           varchar(255)                                              NOT NULL        default ""
     ,`position`                                                                                           int(11)                                                   NOT NULL        default "0"
     ,`note`                                                                                               varchar(255)                                              NOT NULL        default ""
     ,`is_visible_in_advanced_search`                                                                      tinyint(1)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (attribute_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE eav_attribute_group (
      `attribute_group_id`                                                                                 smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_group_name`                                                                               varchar(255)                                              NOT NULL        default ""
     ,`sort_order`                                                                                         smallint(6)                                               NOT NULL        default "0"
     ,`default_id`                                                                                         smallint(5)       unsigned                                                default "0"
  ,PRIMARY KEY (attribute_group_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE eav_attribute_option (
      `option_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`sort_order`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (option_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Attributes option (for source model)';

CREATE TABLE eav_attribute_option_value (
      `value_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`option_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Attribute option values per store';

CREATE TABLE eav_attribute_set (
      `attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_name`                                                                                 varchar(255)                                              NOT NULL        default ""
     ,`sort_order`                                                                                         smallint(6)                                               NOT NULL        default "0"
  ,PRIMARY KEY (attribute_set_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE eav_entity (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`increment_id`                                                                                       varchar(50)                                               NOT NULL        default ""
     ,`parent_id`                                                                                          int(11)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Entityies';

CREATE TABLE eav_entity_attribute (
      `entity_attribute_id`                                                                                int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_group_id`                                                                                 smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`sort_order`                                                                                         smallint(6)                                               NOT NULL        default "0"
  ,PRIMARY KEY (entity_attribute_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE eav_entity_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Datetime values of attributes';

CREATE TABLE eav_entity_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Decimal values of attributes';

CREATE TABLE eav_entity_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Integer values of attributes';

CREATE TABLE eav_entity_store (
      `entity_store_id`                                                                                    int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`increment_prefix`                                                                                   varchar(20)                                               NOT NULL        default ""
     ,`increment_last_id`                                                                                  varchar(50)                                               NOT NULL        default ""
  ,PRIMARY KEY (entity_store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE eav_entity_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Text values of attributes';

CREATE TABLE eav_entity_type (
      `entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`entity_type_code`                                                                                   varchar(50)                                               NOT NULL        default ""
     ,`entity_model`                                                                                       varchar(255)                                              NOT NULL        default ""
     ,`attribute_model`                                                                                    varchar(255)                                              NOT NULL        default ""
     ,`entity_table`                                                                                       varchar(255)                                              NOT NULL        default ""
     ,`value_table_prefix`                                                                                 varchar(255)                                              NOT NULL        default ""
     ,`entity_id_field`                                                                                    varchar(255)                                              NOT NULL        default ""
     ,`is_data_sharing`                                                                                    tinyint(4)        unsigned                                NOT NULL        default "1"
     ,`data_sharing_key`                                                                                   varchar(100)                                                              default "default"
     ,`default_attribute_set_id`                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`increment_model`                                                                                    varchar(255)                                              NOT NULL        default ""
     ,`increment_per_store`                                                                                tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`increment_pad_length`                                                                               tinyint(8)        unsigned                                NOT NULL        default "8"
     ,`increment_pad_char`                                                                                 char(1)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (entity_type_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE eav_entity_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Varchar values of attributes';

CREATE TABLE gift_message (
      `gift_message_id`                                                                                    int(7)            unsigned                                NOT NULL        auto_increment
     ,`customer_id`                                                                                        int(7)            unsigned                                NOT NULL        default "0"
     ,`sender`                                                                                             varchar(255)                                              NOT NULL        default ""
     ,`recipient`                                                                                          varchar(255)                                              NOT NULL        default ""
     ,`message`                                                                                            text                                                      NOT NULL
  ,PRIMARY KEY (gift_message_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE googlecheckout_api_debug (
      `debug_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`dir`                                                                                                enum("in","out")                                                          default NULL
     ,`url`                                                                                                varchar(255)                                                              default NULL
     ,`request_body`                                                                                       text
     ,`response_body`                                                                                      text
  ,PRIMARY KEY (debug_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE log_customer (
      `log_id`                                                                                             int(10)           unsigned                                NOT NULL        auto_increment
     ,`visitor_id`                                                                                         bigint(20)        unsigned                                                default NULL
     ,`customer_id`                                                                                        int(11)                                                   NOT NULL        default "0"
     ,`login_at`                                                                                           datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`logout_at`                                                                                          datetime                                                                  default NULL
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (log_id)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Customers log information';

CREATE TABLE log_quote (
      `quote_id`                                                                                           int(10)           unsigned                                NOT NULL        default "0"
     ,`visitor_id`                                                                                         bigint(20)        unsigned                                                default NULL
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`deleted_at`                                                                                         datetime                                                                  default NULL
  ,PRIMARY KEY (quote_id)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Quote log data';

CREATE TABLE log_summary (
      `summary_id`                                                                                         bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`type_id`                                                                                            smallint(5)       unsigned                                                default NULL
     ,`visitor_count`                                                                                      int(11)                                                   NOT NULL        default "0"
     ,`customer_count`                                                                                     int(11)                                                   NOT NULL        default "0"
     ,`add_date`                                                                                           datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (summary_id)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Summary log information';

CREATE TABLE log_summary_type (
      `type_id`                                                                                            smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`type_code`                                                                                          varchar(64)                                               NOT NULL        default ""
     ,`period`                                                                                             smallint(5)       unsigned                                NOT NULL        default "0"
     ,`period_type`                                                                                        enum("MINUTE","HOUR","DAY","WEEK","MONTH")                NOT NULL        default "MINUTE"
  ,PRIMARY KEY (type_id)
)  ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8 COMMENT='Typeof summary information';

CREATE TABLE log_url (
      `url_id`                                                                                             bigint(20)        unsigned                                NOT NULL        default "0"
     ,`visitor_id`                                                                                         bigint(20)        unsigned                                                default NULL
     ,`visit_time`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='URL visiting history';

CREATE TABLE log_url_info (
      `url_id`                                                                                             bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`url`                                                                                                varchar(255)                                              NOT NULL        default ""
     ,`referer`                                                                                            varchar(255)                                                              default NULL
  ,PRIMARY KEY (url_id)
)  ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8 COMMENT='Detale information about url visit';

CREATE TABLE log_visitor (
      `visitor_id`                                                                                         bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`session_id`                                                                                         char(64)                                                  NOT NULL        default ""
     ,`first_visit_at`                                                                                     datetime                                                                  default NULL
     ,`last_visit_at`                                                                                      datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`last_url_id`                                                                                        bigint(20)        unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (visitor_id)
)  ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8 COMMENT='System visitors log';

CREATE TABLE log_visitor_info (
      `visitor_id`                                                                                         bigint(20)        unsigned                                NOT NULL        default "0"
     ,`http_referer`                                                                                       varchar(255)                                                              default NULL
     ,`http_user_agent`                                                                                    varchar(255)                                                              default NULL
     ,`http_accept_charset`                                                                                varchar(255)                                                              default NULL
     ,`http_accept_language`                                                                               varchar(255)                                                              default NULL
     ,`server_addr`                                                                                        bigint(20)                                                                default NULL
     ,`remote_addr`                                                                                        bigint(20)                                                                default NULL
  ,PRIMARY KEY (visitor_id)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Additional information by visitor';

CREATE TABLE newsletter_problem (
      `problem_id`                                                                                         int(7)            unsigned                                NOT NULL        auto_increment
     ,`subscriber_id`                                                                                      int(7)            unsigned                                                default NULL
     ,`queue_id`                                                                                           int(7)            unsigned                                NOT NULL        default "0"
     ,`problem_error_code`                                                                                 int(3)            unsigned                                                default "0"
     ,`problem_error_text`                                                                                 varchar(200)                                                              default NULL
  ,PRIMARY KEY (problem_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter problems';

CREATE TABLE newsletter_queue (
      `queue_id`                                                                                           int(7)            unsigned                                NOT NULL        auto_increment
     ,`template_id`                                                                                        int(7)            unsigned                                NOT NULL        default "0"
     ,`queue_status`                                                                                       int(3)            unsigned                                NOT NULL        default "0"
     ,`queue_start_at`                                                                                     datetime                                                                  default NULL
     ,`queue_finish_at`                                                                                    datetime                                                                  default NULL
  ,PRIMARY KEY (queue_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter queue';

CREATE TABLE newsletter_queue_link (
      `queue_link_id`                                                                                      int(9)            unsigned                                NOT NULL        auto_increment
     ,`queue_id`                                                                                           int(7)            unsigned                                NOT NULL        default "0"
     ,`subscriber_id`                                                                                      int(7)            unsigned                                NOT NULL        default "0"
     ,`letter_sent_at`                                                                                     datetime                                                                  default NULL
  ,PRIMARY KEY (queue_link_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter queue to subscriber link';

CREATE TABLE newsletter_queue_store_link (
      `queue_id`                                                                                           int(7)            unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (queue_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE newsletter_subscriber (
      `subscriber_id`                                                                                      int(7)            unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                                default "0"
     ,`change_status_at`                                                                                   datetime                                                                  default NULL
     ,`customer_id`                                                                                        int(11)           unsigned                                NOT NULL        default "0"
     ,`subscriber_email`                                                                                   varchar(150)                                              NOT NULL        default ""
     ,`subscriber_status`                                                                                  int(3)                                                    NOT NULL        default "0"
     ,`subscriber_confirm_code`                                                                            varchar(32)                                                               default "NULL"
  ,PRIMARY KEY (subscriber_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter subscribers';

CREATE TABLE newsletter_template (
      `template_id`                                                                                        int(7)            unsigned                                NOT NULL        auto_increment
     ,`template_code`                                                                                      varchar(150)                                                              default NULL
     ,`template_text`                                                                                      text
     ,`template_text_preprocessed`                                                                         text
     ,`template_type`                                                                                      int(3)            unsigned                                                default NULL
     ,`template_subject`                                                                                   varchar(200)                                                              default NULL
     ,`template_sender_name`                                                                               varchar(200)                                                              default NULL
     ,`template_sender_email`                                                                              varchar(200)                                                              default NULL
     ,`template_actual`                                                                                    tinyint(1)        unsigned                                                default "1                                                                  "
     ,`added_at`                                                                                           datetime                                                                  default NULL
     ,`modified_at`                                                                                        datetime                                                                  default NULL
  ,PRIMARY KEY (template_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Newsletter templates'                                     ;

CREATE TABLE paygate_authorizenet_debug (
      `debug_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`request_body`                                                                                       text
     ,`response_body`                                                                                      text
     ,`request_serialized`                                                                                 text
     ,`result_serialized`                                                                                  text
     ,`request_dump`                                                                                       text
     ,`result_dump`                                                                                        text
  ,PRIMARY KEY (debug_id)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE paypal_api_debug (
      `debug_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`debug_at`                                                                                           timestamp                                                 NOT NULL        default CURRENT_TIMESTAMP                        on update                                     CURRENT_TIMESTAMP
     ,`request_body`                                                                                       text
     ,`response_body`                                                                                      text
  ,PRIMARY KEY (debug_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE paypaluk_api_debug (
      `debug_id`                                                                                           int(10)           unsigned                                NOT NULL        auto_increment
     ,`debug_at`                                                                                           timestamp                                                 NOT NULL        default CURRENT_TIMESTAMP                        on update                                     CURRENT_TIMESTAMP
     ,`request_body`                                                                                       text
     ,`response_body`                                                                                      text
  ,PRIMARY KEY (debug_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE poll (
      `poll_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`poll_title`                                                                                         varchar(255)                                              NOT NULL        default ""
     ,`votes_count`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                                default "0"
     ,`date_posted`                                                                                        datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`date_closed`                                                                                        datetime                                                                  default NULL
     ,`active`                                                                                             smallint(6)                                               NOT NULL        default "1"
     ,`closed`                                                                                             tinyint(1)                                                NOT NULL        default "0"
     ,`answers_display`                                                                                    smallint(6)                                                               default NULL
  ,PRIMARY KEY (poll_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE poll_answer (
      `answer_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`poll_id`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`answer_title`                                                                                       varchar(255)                                              NOT NULL        default ""
     ,`votes_count`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`answer_order`                                                                                       smallint(6)                                               NOT NULL        default "0"
  ,PRIMARY KEY (answer_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE poll_store (
      `poll_id`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (poll_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE poll_vote (
      `vote_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`poll_id`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`poll_answer_id`                                                                                     int(10)           unsigned                                NOT NULL        default "0"
     ,`ip_address`                                                                                         bigint(20)                                                                default NULL
     ,`customer_id`                                                                                        int(11)                                                                   default NULL
     ,`vote_time`                                                                                          timestamp                                                 NOT NULL        default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP
  ,PRIMARY KEY (vote_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE product_alert_price (
      `alert_price_id`                                                                                     int(10)           unsigned                                NOT NULL        auto_increment
     ,`customer_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`price`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`add_date`                                                                                           datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`last_send_date`                                                                                     datetime                                                                  default NULL
     ,`send_count`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`status`                                                                                             tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (alert_price_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE product_alert_stock (
      `alert_stock_id`                                                                                     int(10)           unsigned                                NOT NULL        auto_increment
     ,`customer_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`website_id`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`add_date`                                                                                           datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`send_date`                                                                                          datetime                                                                  default NULL
     ,`send_count`                                                                                         smallint(5)       unsigned                                NOT NULL        default "0"
     ,`status`                                                                                             tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (alert_stock_id)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8;

CREATE TABLE rating (
      `rating_id`                                                                                          smallint(6)       unsigned                                NOT NULL        auto_increment
     ,`entity_id`                                                                                          smallint(6)       unsigned                                NOT NULL        default "0"
     ,`rating_code`                                                                                        varchar(64)                                               NOT NULL        default ""
     ,`position`                                                                                           tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (rating_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='ratings';

CREATE TABLE rating_entity (
      `entity_id`                                                                                          smallint(6)       unsigned                                NOT NULL        auto_increment
     ,`entity_code`                                                                                        varchar(64)                                               NOT NULL        default ""
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating entities';

CREATE TABLE rating_option (
      `option_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`rating_id`                                                                                          smallint(6)       unsigned                                NOT NULL        default "0"
     ,`code`                                                                                               varchar(32)                                               NOT NULL        default ""
     ,`value`                                                                                              tinyint(3)        unsigned                                NOT NULL        default "0"
     ,`position`                                                                                           tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (option_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating options';

CREATE TABLE rating_option_vote (
      `vote_id`                                                                                            bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`option_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`remote_ip`                                                                                          varchar(16)                                               NOT NULL        default ""
     ,`remote_ip_long`                                                                                     int(11)                                                   NOT NULL        default "0"
     ,`customer_id`                                                                                        int(11)           unsigned                                                default "0"
     ,`entity_pk_value`                                                                                    bigint(20)        unsigned                                NOT NULL        default "0"
     ,`rating_id`                                                                                          smallint(6)       unsigned                                NOT NULL        default "0"
     ,`review_id`                                                                                          bigint(20)        unsigned                                                default NULL
     ,`percent`                                                                                            tinyint(3)                                                NOT NULL        default "0"
     ,`value`                                                                                              tinyint(3)                                                NOT NULL        default "0"
  ,PRIMARY KEY (vote_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Rating option values'                                     ;

CREATE TABLE rating_option_vote_aggregated (
      `primary_id`                                                                                         int(11)                                                   NOT NULL        auto_increment
     ,`rating_id`                                                                                          smallint(6)       unsigned                                NOT NULL        default "0"
     ,`entity_pk_value`                                                                                    bigint(20)        unsigned                                NOT NULL        default "0"
     ,`vote_count`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`vote_value_sum`                                                                                     int(10)           unsigned                                NOT NULL        default "0"
     ,`percent`                                                                                            tinyint(3)                                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (primary_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE rating_store (
      `rating_id`                                                                                          smallint(6)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (rating_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE rating_title (
      `rating_id`                                                                                          smallint(6)       unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (rating_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE report_event (
      `event_id`                                                                                           bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`logged_at`                                                                                          datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`event_type_id`                                                                                      smallint(6)       unsigned                                NOT NULL        default "0"
     ,`object_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`subject_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`subtype`                                                                                            tinyint(3)        unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (event_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE report_event_types (
      `event_type_id`                                                                                      smallint(6)       unsigned                                NOT NULL        auto_increment
     ,`event_name`                                                                                         varchar(64)                                               NOT NULL        default ""
     ,`customer_login`                                                                                     tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (event_type_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE review (
      `review_id`                                                                                          bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`entity_id`                                                                                          smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_pk_value`                                                                                    int(10)           unsigned                                NOT NULL        default "0"
     ,`status_id`                                                                                          tinyint(3)        unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (review_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review base information';

CREATE TABLE review_detail (
      `detail_id`                                                                                          bigint(20)        unsigned                                NOT NULL        auto_increment
     ,`review_id`                                                                                          bigint(20)        unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                                default "0"
     ,`title`                                                                                              varchar(255)                                              NOT NULL        default ""
     ,`detail`                                                                                             text                                                      NOT NULL
     ,`nickname`                                                                                           varchar(128)                                              NOT NULL        default ""
     ,`customer_id`                                                                                        int(10)           unsigned                                                default NULL
  ,PRIMARY KEY (detail_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review detail information';

CREATE TABLE review_entity (
      `entity_id`                                                                                          smallint(5)       unsigned                                NOT NULL        auto_increment
     ,`entity_code`                                                                                        varchar(32)                                               NOT NULL        default ""
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review entities';

CREATE TABLE review_entity_summary (
      `primary_id`                                                                                         bigint(20)                                                NOT NULL        auto_increment
     ,`entity_pk_value`                                                                                    bigint(20)                                                NOT NULL        default "0"
     ,`entity_type`                                                                                        tinyint(4)                                                NOT NULL        default "0"
     ,`reviews_count`                                                                                      smallint(6)                                               NOT NULL        default "0"
     ,`rating_summary`                                                                                     tinyint(4)                                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (primary_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE review_status (
      `status_id`                                                                                          tinyint(3)        unsigned                                NOT NULL        auto_increment
     ,`status_code`                                                                                        varchar(32)                                               NOT NULL        default ""
  ,PRIMARY KEY (status_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Review statuses';

CREATE TABLE review_store (
      `review_id`                                                                                          bigint(20)        unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (review_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_counter (
      `counter_id`                                                                                         int(10)           unsigned                                NOT NULL        auto_increment
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`counter_type`                                                                                       varchar(50)                                               NOT NULL        default ""
     ,`counter_value`                                                                                      varchar(50)                                               NOT NULL        default ""
  ,PRIMARY KEY (counter_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_discount_coupon (
      `coupon_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`coupon_code`                                                                                        varchar(50)                                               NOT NULL        default ""
     ,`discount_percent`                                                                                   decimal(10,4)                                             NOT NULL        default "0.0000"
     ,`discount_fixed`                                                                                     decimal(10,4)                                             NOT NULL        default "0.0000"
     ,`is_active`                                                                                          tinyint(1)                                                NOT NULL        default "1"
     ,`from_date`                                                                                          datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`to_date`                                                                                            datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`min_subtotal`                                                                                       decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`limit_products`                                                                                     text                                                      NOT NULL
     ,`limit_categories`                                                                                   text                                                      NOT NULL
     ,`limit_attributes`                                                                                   text                                                      NOT NULL
  ,PRIMARY KEY (coupon_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_giftcert (
      `giftcert_id`                                                                                        int(10)           unsigned                                NOT NULL        auto_increment
     ,`giftcert_code`                                                                                      varchar(50)                                               NOT NULL        default ""
     ,`balance_amount`                                                                                     decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (giftcert_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`increment_id`                                                                                       varchar(50)                                               NOT NULL        default ""
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                                default NULL
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`customer_id`                                                                                        int(11)                                                                   default NULL
     ,`tax_amount`                                                                                         decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`shipping_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`discount_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`subtotal`                                                                                           decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`grand_total`                                                                                        decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`total_paid`                                                                                         decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`total_refunded`                                                                                     decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`total_qty_ordered`                                                                                  decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`total_canceled`                                                                                     decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`total_invoiced`                                                                                     decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`total_online_refunded`                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`total_offline_refunded`                                                                             decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_tax_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_shipping_amount`                                                                               decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_discount_amount`                                                                               decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_subtotal`                                                                                      decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_grand_total`                                                                                   decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_total_paid`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_total_refunded`                                                                                decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_total_qty_ordered`                                                                             decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_total_canceled`                                                                                decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_total_invoiced`                                                                                decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_total_online_refunded`                                                                         decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_total_offline_refunded`                                                                        decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`subtotal_refunded`                                                                                  decimal(12,4)                                                             default NULL
     ,`subtotal_canceled`                                                                                  decimal(12,4)                                                             default NULL
     ,`tax_refunded`                                                                                       decimal(12,4)                                                             default NULL
     ,`tax_canceled`                                                                                       decimal(12,4)                                                             default NULL
     ,`shipping_refunded`                                                                                  decimal(12,4)                                                             default NULL
     ,`shipping_canceled`                                                                                  decimal(12,4)                                                             default NULL
     ,`base_subtotal_refunded`                                                                             decimal(12,4)                                                             default NULL
     ,`base_subtotal_canceled`                                                                             decimal(12,4)                                                             default NULL
     ,`base_tax_refunded`                                                                                  decimal(12,4)                                                             default NULL
     ,`base_tax_canceled`                                                                                  decimal(12,4)                                                             default NULL
     ,`base_shipping_refunded`                                                                             decimal(12,4)                                                             default NULL
     ,`base_shipping_canceled`                                                                             decimal(12,4)                                                             default NULL
     ,`subtotal_invoiced`                                                                                  decimal(12,4)                                                             default NULL
     ,`tax_invoiced`                                                                                       decimal(12,4)                                                             default NULL
     ,`shipping_invoiced`                                                                                  decimal(12,4)                                                             default NULL
     ,`base_subtotal_invoiced`                                                                             decimal(12,4)                                                             default NULL
     ,`base_tax_invoiced`                                                                                  decimal(12,4)                                                             default NULL
     ,`base_shipping_invoiced`                                                                             decimal(12,4)                                                             default NULL
     ,`shipping_tax_amount`                                                                                decimal(12,4)                                                             default NULL
     ,`base_shipping_tax_amount`                                                                           decimal(12,4)                                                             default NULL
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;

CREATE TABLE sales_order_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_entity (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`increment_id`                                                                                       varchar(50)                                               NOT NULL        default ""
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                                default NULL
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_entity_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_entity_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_entity_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_entity_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_entity_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_order_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(5)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`converted_at`                                                                                       datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                                default "1                                                                  "
     ,`is_virtual`                                                                                         tinyint(1)        unsigned                                                default "0                                                                  "
     ,`is_multi_shipping`                                                                                  tinyint(1)        unsigned                                                default "0                                                                  "
     ,`is_multi_payment`                                                                                   tinyint(1)        unsigned                                                default "0                                                                  "
     ,`customer_note_notify`                                                                               tinyint(1)        unsigned                                                default "1                                                                  "
     ,`customer_is_guest`                                                                                  tinyint(1)        unsigned                                                default "0                                                                  "
     ,`quote_status_id`                                                                                    int(10)           unsigned                                                default "0"
     ,`billing_address_id`                                                                                 int(10)           unsigned                                                default "0"
     ,`orig_order_id`                                                                                      int(10)           unsigned                                                default "0"
     ,`customer_id`                                                                                        int(10)           unsigned                                                default "0"
     ,`customer_tax_class_id`                                                                              int(10)           unsigned                                                default "0"
     ,`customer_group_id`                                                                                  int(10)           unsigned                                                default "0"
     ,`items_count`                                                                                        int(10)           unsigned                                                default "0"
     ,`items_qty`                                                                                          decimal(12,4)                                                             default "0.0000"
     ,`store_to_base_rate`                                                                                 decimal(12,4)                                                             default "0.0000"
     ,`store_to_quote_rate`                                                                                decimal(12,4)                                                             default "0.0000"
     ,`grand_total`                                                                                        decimal(12,4)                                                             default "0.0000"
     ,`base_grand_total`                                                                                   decimal(12,4)                                                             default "0.0000"
     ,`custbalance_amount`                                                                                 decimal(12,4)                                                             default "0.0000"
     ,`checkout_method`                                                                                    varchar(255)                                                              default NULL
     ,`password_hash`                                                                                      varchar(255)                                                              default NULL
     ,`coupon_code`                                                                                        varchar(255)                                                              default NULL
     ,`giftcert_code`                                                                                      varchar(255)                                                              default NULL
     ,`base_currency_code`                                                                                 varchar(255)                                                              default NULL
     ,`store_currency_code`                                                                                varchar(255)                                                              default NULL
     ,`quote_currency_code`                                                                                varchar(255)                                                              default NULL
     ,`customer_email`                                                                                     varchar(255)                                                              default NULL
     ,`customer_firstname`                                                                                 varchar(255)                                                              default NULL
     ,`customer_lastname`                                                                                  varchar(255)                                                              default NULL
     ,`customer_note`                                                                                      varchar(255)                                                              default NULL
     ,`remote_ip`                                                                                          varchar(255)                                                              default NULL
     ,`applied_rule_ids`                                                                                   varchar(255)                                                              default NULL
     ,`reserved_order_id`                                                                                  varchar(64)                                                               default ""
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_address (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`customer_id`                                                                                        int(10)           unsigned                                                default NULL
     ,`save_in_address_book`                                                                               tinyint(1)                                                                default "0"
     ,`customer_address_id`                                                                                int(10)           unsigned                                                default NULL
     ,`address_type`                                                                                       varchar(255)                                                              default NULL
     ,`email`                                                                                              varchar(255)                                                              default NULL
     ,`firstname`                                                                                          varchar(255)                                                              default NULL
     ,`lastname`                                                                                           varchar(255)                                                              default NULL
     ,`company`                                                                                            varchar(255)                                                              default NULL
     ,`street`                                                                                             varchar(255)                                                              default NULL
     ,`city`                                                                                               varchar(255)                                                              default NULL
     ,`region`                                                                                             varchar(255)                                                              default NULL
     ,`region_id`                                                                                          int(10)           unsigned                                                default NULL
     ,`postcode`                                                                                           varchar(255)                                                              default NULL
     ,`country_id`                                                                                         varchar(255)                                                              default NULL
     ,`telephone`                                                                                          varchar(255)                                                              default NULL
     ,`fax`                                                                                                varchar(255)                                                              default NULL
     ,`same_as_billing`                                                                                    tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`free_shipping`                                                                                      tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`collect_shipping_rates`                                                                             tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`shipping_method`                                                                                    varchar(255)                                              NOT NULL        default ""
     ,`shipping_description`                                                                               varchar(255)                                              NOT NULL        default ""
     ,`weight`                                                                                             decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`subtotal`                                                                                           decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`subtotal_with_discount`                                                                             decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`tax_amount`                                                                                         decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`shipping_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`discount_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`custbalance_amount`                                                                                 decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`grand_total`                                                                                        decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_subtotal`                                                                                      decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_subtotal_with_discount`                                                                        decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_tax_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_shipping_amount`                                                                               decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_discount_amount`                                                                               decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_custbalance_amount`                                                                            decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_grand_total`                                                                                   decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`customer_notes`                                                                                     text
     ,`shipping_tax_amount`                                                                                decimal(12,4)                                                             default NULL
     ,`base_shipping_tax_amount`                                                                           decimal(12,4)                                                             default NULL
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_address_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_address_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_address_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_address_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_entity (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`increment_id`                                                                                       varchar(50)                                               NOT NULL        default ""
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`is_active`                                                                                          tinyint(1)        unsigned                                NOT NULL        default "1"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_entity_datetime (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_entity_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_entity_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_entity_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_entity_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_item (
      `entity_id`                                                                                          int(10)           unsigned                                NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_set_id`                                                                                   smallint(5)       unsigned                                NOT NULL        default "0"
     ,`parent_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`created_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`updated_at`                                                                                         datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`product_id`                                                                                         int(10)           unsigned                                                default NULL
     ,`super_product_id`                                                                                   int(10)           unsigned                                                default NULL
     ,`parent_product_id`                                                                                  int(10)           unsigned                                                default NULL
     ,`sku`                                                                                                varchar(255)                                              NOT NULL        default ""
     ,`name`                                                                                               varchar(255)                                                              default NULL
     ,`description`                                                                                        text
     ,`applied_rule_ids`                                                                                   text
     ,`additional_data`                                                                                    text
     ,`free_shipping`                                                                                      tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`is_qty_decimal`                                                                                     tinyint(1)        unsigned                                                default NULL
     ,`no_discount`                                                                                        tinyint(1)        unsigned                                                default "0                                                                  "
     ,`weight`                                                                                             decimal(12,4)                                                             default "0.0000"
     ,`qty`                                                                                                decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`price`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`custom_price`                                                                                       decimal(12,4)                                                             default NULL
     ,`discount_percent`                                                                                   decimal(12,4)                                                             default "0.0000"
     ,`discount_amount`                                                                                    decimal(12,4)                                                             default "0.0000"
     ,`tax_percent`                                                                                        decimal(12,4)                                                             default "0.0000"
     ,`tax_amount`                                                                                         decimal(12,4)                                                             default "0.0000"
     ,`row_total`                                                                                          decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`row_total_with_discount`                                                                            decimal(12,4)                                                             default "0.0000"
     ,`base_price`                                                                                         decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`base_discount_amount`                                                                               decimal(12,4)                                                             default "0.0000"
     ,`base_tax_amount`                                                                                    decimal(12,4)                                                             default "0.0000"
     ,`base_row_total`                                                                                     decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`row_weight`                                                                                         decimal(12,4)                                                             default "0.0000"
  ,PRIMARY KEY (entity_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_item_decimal (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_item_int (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_item_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_item_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_rule (
      `quote_rule_id`                                                                                      int(10)           unsigned                                NOT NULL        auto_increment
     ,`name`                                                                                               varchar(255)                                              NOT NULL        default ""
     ,`description`                                                                                        text                                                      NOT NULL
     ,`is_active`                                                                                          tinyint(4)                                                NOT NULL        default "0"
     ,`start_at`                                                                                           datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`expire_at`                                                                                          datetime                                                  NOT NULL        default "0000-00-00 00:00:00"
     ,`coupon_code`                                                                                        varchar(50)                                               NOT NULL        default ""
     ,`customer_registered`                                                                                tinyint(1)                                                NOT NULL        default "2"
     ,`customer_new_buyer`                                                                                 tinyint(1)                                                NOT NULL        default "2"
     ,`show_in_catalog`                                                                                    tinyint(1)                                                NOT NULL        default "0"
     ,`sort_order`                                                                                         smallint(6)                                               NOT NULL        default "0"
     ,`conditions_serialized`                                                                              text                                                      NOT NULL
     ,`actions_serialized`                                                                                 text                                                      NOT NULL
  ,PRIMARY KEY (quote_rule_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_text (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              text                                                      NOT NULL
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sales_quote_varchar (
      `value_id`                                                                                           int(11)                                                   NOT NULL        auto_increment
     ,`entity_type_id`                                                                                     smallint(8)       unsigned                                NOT NULL        default "0"
     ,`attribute_id`                                                                                       smallint(5)       unsigned                                NOT NULL        default "0"
     ,`entity_id`                                                                                          int(10)           unsigned                                NOT NULL        default "0"
     ,`value`                                                                                              varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (value_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE salesrule (
      `rule_id`                                                                                            int(10)           unsigned                                NOT NULL        auto_increment
     ,`name`                                                                                               varchar(255)                                              NOT NULL        default ""
     ,`description`                                                                                        text                                                      NOT NULL
     ,`from_date`                                                                                          date                                                                      default "0000-00-00"
     ,`to_date`                                                                                            date                                                                      default "0000-00-00"
     ,`coupon_code`                                                                                        varchar(255)                                                              default NULL
     ,`uses_per_coupon`                                                                                    int(11)                                                   NOT NULL        default "0"
     ,`uses_per_customer`                                                                                  int(11)                                                   NOT NULL        default "0"
     ,`customer_group_ids`                                                                                 varchar(255)                                              NOT NULL        default ""
     ,`is_active`                                                                                          tinyint(1)                                                NOT NULL        default "0"
     ,`conditions_serialized`                                                                              text                                                      NOT NULL
     ,`actions_serialized`                                                                                 text                                                      NOT NULL
     ,`stop_rules_processing`                                                                              tinyint(1)                                                NOT NULL        default "1"
     ,`is_advanced`                                                                                        tinyint(3)        unsigned                                NOT NULL        default "1"
     ,`product_ids`                                                                                        text
     ,`sort_order`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`simple_action`                                                                                      varchar(32)                                               NOT NULL        default ""
     ,`discount_amount`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`discount_qty`                                                                                       decimal(12,4)     unsigned                                                default NULL
     ,`discount_step`                                                                                      int(10)           unsigned                                NOT NULL        default "0"
     ,`simple_free_shipping`                                                                               tinyint(1)        unsigned                                NOT NULL        default "0"
     ,`times_used`                                                                                         int(11)           unsigned                                NOT NULL        default "0"
     ,`is_rss`                                                                                             tinyint(4)                                                NOT NULL        default "0"
     ,`website_ids`                                                                                        text
  ,PRIMARY KEY (rule_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE salesrule_customer (
      `rule_customer_id`                                                                                   int(10)           unsigned                                NOT NULL        auto_increment
     ,`rule_id`                                                                                            int(10)           unsigned                                NOT NULL        default "0"
     ,`customer_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`times_used`                                                                                         smallint(11)      unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (rule_customer_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sendfriend_log (
      `log_id`                                                                                             int(11)                                                   NOT NULL        auto_increment
     ,`ip`                                                                                                 int(11)                                                   NOT NULL        default "0"
     ,`time`                                                                                               int(11)                                                   NOT NULL        default "0"
  ,PRIMARY KEY (log_id)
)  ENGINE=MyISAM DEFAULT CHARSET=utf8 COMMENT='Send to friend function log storage table';

CREATE TABLE shipping_tablerate (
      `pk`                                                                                                 int(10)           unsigned                                NOT NULL        auto_increment
     ,`website_id`                                                                                         int(11)                                                   NOT NULL        default "0"
     ,`dest_country_id`                                                                                    varchar(4)                                                NOT NULL        default "0"
     ,`dest_region_id`                                                                                     int(10)                                                   NOT NULL        default "0"
     ,`dest_zip`                                                                                           varchar(10)                                               NOT NULL        default ""
     ,`condition_name`                                                                                     varchar(20)                                               NOT NULL        default ""
     ,`condition_value`                                                                                    decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`price`                                                                                              decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`cost`                                                                                               decimal(12,4)                                             NOT NULL        default "0.0000"
  ,PRIMARY KEY (pk)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE sitemap (
      `sitemap_id`                                                                                         int(11)                                                   NOT NULL        auto_increment
     ,`sitemap_type`                                                                                       varchar(32)                                                               default NULL
     ,`sitemap_filename`                                                                                   varchar(32)                                                               default NULL
     ,`sitemap_path`                                                                                       tinytext
     ,`sitemap_time`                                                                                       timestamp                                                 NULL            default NULL
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (sitemap_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tag (
      `tag_id`                                                                                             int(11)           unsigned                                NOT NULL        auto_increment
     ,`name`                                                                                               varchar(255)                                              NOT NULL        default ""
     ,`status`                                                                                             smallint(6)                                               NOT NULL        default "0"
  ,PRIMARY KEY (tag_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tag_relation (
      `tag_relation_id`                                                                                    int(11)           unsigned                                NOT NULL        auto_increment
     ,`tag_id`                                                                                             int(11)           unsigned                                NOT NULL        default "0"
     ,`customer_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(11)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(6)       unsigned                                NOT NULL        default "1"
     ,`active`                                                                                             tinyint(1)        unsigned                                NOT NULL        default "1"
     ,`created_at`                                                                                         datetime                                                                  default NULL
  ,PRIMARY KEY (tag_relation_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tag_summary (
      `tag_id`                                                                                             int(11)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`customers`                                                                                          int(11)           unsigned                                NOT NULL        default "0"
     ,`products`                                                                                           int(11)           unsigned                                NOT NULL        default "0"
     ,`uses`                                                                                               int(11)           unsigned                                NOT NULL        default "0"
     ,`historical_uses`                                                                                    int(11)           unsigned                                NOT NULL        default "0"
     ,`popularity`                                                                                         int(11)           unsigned                                NOT NULL        default "0"
  ,PRIMARY KEY (tag_id,store_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tax_class (
      `class_id`                                                                                           smallint(6)                                               NOT NULL        auto_increment
     ,`class_name`                                                                                         varchar(255)                                              NOT NULL        default ""
     ,`class_type`                                                                                         enum("CUSTOMER","PRODUCT")                                NOT NULL        default "CUSTOMER"
  ,PRIMARY KEY (class_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tax_rate (
      `tax_rate_id`                                                                                        int(10)           unsigned                                NOT NULL        auto_increment
     ,`tax_country_id`                                                                                     char(2)                                                   NOT NULL        default "US"
     ,`tax_region_id`                                                                                      mediumint(9)      unsigned                                                default NULL
     ,`tax_postcode`                                                                                       varchar(12)                                                               default NULL
  ,PRIMARY KEY (tax_rate_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Base tax rates';

CREATE TABLE tax_rate_data (
      `tax_rate_data_id`                                                                                   int(10)           unsigned                                NOT NULL        auto_increment
     ,`tax_rate_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`rate_value`                                                                                         decimal(12,4)                                             NOT NULL        default "0.0000"
     ,`rate_type_id`                                                                                       tinyint(4)                                                NOT NULL        default "0"
  ,PRIMARY KEY (tax_rate_data_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tax_rate_type (
      `type_id`                                                                                            tinyint(4)                                                NOT NULL        auto_increment
     ,`type_name`                                                                                          varchar(255)                                              NOT NULL        default ""
  ,PRIMARY KEY (type_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE tax_rule (
      `tax_rule_id`                                                                                        tinyint(4)                                                NOT NULL        auto_increment
     ,`tax_customer_class_id`                                                                              smallint(6)                                               NOT NULL        default "0"
     ,`tax_product_class_id`                                                                               smallint(6)                                               NOT NULL        default "0"
     ,`tax_rate_type_id`                                                                                   tinyint(4)                                                NOT NULL        default "0"
     ,`tax_shipping`                                                                                       tinyint(1)                                                NOT NULL        default "0"
  ,PRIMARY KEY (tax_rule_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE wishlist (
      `wishlist_id`                                                                                        int(10)           unsigned                                NOT NULL        auto_increment
     ,`customer_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`shared`                                                                                             tinyint(1)        unsigned                                                default "0"
     ,`sharing_code`                                                                                       varchar(32)                                               NOT NULL        default ""
  ,PRIMARY KEY (wishlist_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Wishlist main';

CREATE TABLE wishlist_item (
      `wishlist_item_id`                                                                                   int(10)           unsigned                                NOT NULL        auto_increment
     ,`wishlist_id`                                                                                        int(10)           unsigned                                NOT NULL        default "0"
     ,`product_id`                                                                                         int(10)           unsigned                                NOT NULL        default "0"
     ,`store_id`                                                                                           smallint(5)       unsigned                                NOT NULL        default "0"
     ,`added_at`                                                                                           datetime                                                                  default NULL
     ,`description`                                                                                        text
  ,PRIMARY KEY (wishlist_item_id)
)  ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='Wishlist items';


-- -------------------
--  Indexes
-- -------------------
CREATE         INDEX parent_id                                                ON admin_role                                      (`parent_id`,`sort_order`);
CREATE         INDEX tree_level                                               ON admin_role                                      (`tree_level`);
CREATE         INDEX resource                                                 ON admin_rule                                      (`resource_id`,`role_id`);
CREATE         INDEX role_id                                                  ON admin_rule                                      (`role_id`,`resource_id`);
CREATE         INDEX fk_catalog_category_entity_datetime_attribute            ON catalog_category_entity_datetime                (`attribute_id`);
CREATE         INDEX fk_attribute_datetime_entity                             ON catalog_category_entity_datetime                (`entity_id`);
CREATE UNIQUE  INDEX idx_base                                                 ON catalog_category_entity_datetime                (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`);
CREATE         INDEX fk_catalog_category_entity_datetime_store                ON catalog_category_entity_datetime                (`store_id`);
CREATE         INDEX fk_catalog_category_entity_decimal_attribute             ON catalog_category_entity_decimal                 (`attribute_id`);
CREATE         INDEX fk_attribute_decimal_entity                              ON catalog_category_entity_decimal                 (`entity_id`);
CREATE UNIQUE  INDEX idx_base                                                 ON catalog_category_entity_decimal                 (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`);
CREATE         INDEX fk_catalog_category_entity_decimal_store                 ON catalog_category_entity_decimal                 (`store_id`);
CREATE         INDEX fk_catalog_category_emtity_int_attribute                 ON catalog_category_entity_int                     (`attribute_id`);
CREATE         INDEX fk_attribute_int_entity                                  ON catalog_category_entity_int                     (`entity_id`);
CREATE UNIQUE  INDEX idx_base                                                 ON catalog_category_entity_int                     (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`);
CREATE         INDEX fk_catalog_category_emtity_int_store                     ON catalog_category_entity_int                     (`store_id`);
CREATE         INDEX fk_catalog_category_entity_text_attribute                ON catalog_category_entity_text                    (`attribute_id`);
CREATE         INDEX fk_attribute_text_entity                                 ON catalog_category_entity_text                    (`entity_id`);
CREATE UNIQUE  INDEX idx_base                                                 ON catalog_category_entity_text                    (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`);
CREATE         INDEX fk_catalog_category_entity_text_store                    ON catalog_category_entity_text                    (`store_id`);
CREATE         INDEX fk_catalog_category_entity_varchar_attribute             ON catalog_category_entity_varchar                 (`attribute_id`);
CREATE         INDEX fk_attribute_varchar_entity                              ON catalog_category_entity_varchar                 (`entity_id`);
CREATE UNIQUE  INDEX idx_base                                                 ON catalog_category_entity_varchar                 (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`);
CREATE         INDEX fk_catalog_category_entity_varchar_store                 ON catalog_category_entity_varchar                 (`store_id`);
CREATE UNIQUE  INDEX unq_category_product                                     ON catalog_category_product                        (`category_id`,`product_id`);
CREATE         INDEX catalog_category_product_category                        ON catalog_category_product                        (`category_id`);
CREATE         INDEX catalog_category_product_product                         ON catalog_category_product                        (`product_id`);
CREATE         INDEX fk_catalog_compare_item_customer                         ON catalog_compare_item                            (`customer_id`);
CREATE         INDEX fk_catalog_compare_item_product                          ON catalog_compare_item                            (`product_id`);
CREATE         INDEX fk_catalog_product_bundle_option                         ON catalog_product_bundle_option                   (`product_id`);
CREATE         INDEX fk_catalog_product_bundle_option_link                    ON catalog_product_bundle_option_link              (`option_id`);
CREATE         INDEX fk_catalog_product_bundle_option_link_entity             ON catalog_product_bundle_option_link              (`product_id`);
CREATE         INDEX fk_catalog_product_bundle_option_label                   ON catalog_product_bundle_option_value             (`option_id`);
CREATE         INDEX fk_catalog_product_entity_attribute_set_id               ON catalog_product_entity                          (`attribute_set_id`);
CREATE         INDEX fk_catalog_product_entity_entity_type                    ON catalog_product_entity                          (`entity_type_id`);
CREATE         INDEX sku                                                      ON catalog_product_entity                          (`sku`);
CREATE         INDEX fk_catalog_product_entity_datetime_attribute             ON catalog_product_entity_datetime                 (`attribute_id`);
CREATE         INDEX fk_catalog_product_entity_datetime_product_entity        ON catalog_product_entity_datetime                 (`entity_id`);
CREATE         INDEX fk_catalog_product_entity_datetime_store                 ON catalog_product_entity_datetime                 (`store_id`);
CREATE         INDEX fk_catalog_product_entity_decimal_attribute              ON catalog_product_entity_decimal                  (`attribute_id`);
CREATE         INDEX fk_catalog_product_entity_decimal_product_entity         ON catalog_product_entity_decimal                  (`entity_id`);
CREATE         INDEX fk_catalog_product_entity_decimal_store                  ON catalog_product_entity_decimal                  (`store_id`);
CREATE         INDEX fk_catalog_category_entity_gallery_attribute             ON catalog_product_entity_gallery                  (`attribute_id`);
CREATE         INDEX fk_attribute_gallery_entity                              ON catalog_product_entity_gallery                  (`entity_id`);
CREATE         INDEX idx_base                                                 ON catalog_product_entity_gallery                  (`entity_type_id`,`entity_id`,`attribute_id`,`store_id`);
CREATE         INDEX fk_catalog_category_entity_gallery_store                 ON catalog_product_entity_gallery                  (`store_id`);
CREATE         INDEX fk_catalog_product_entity_int_attribute                  ON catalog_product_entity_int                      (`attribute_id`);
CREATE         INDEX fk_catalog_product_entity_int_product_entity             ON catalog_product_entity_int                      (`entity_id`);
CREATE         INDEX fk_catalog_product_entity_int_store                      ON catalog_product_entity_int                      (`store_id`);
CREATE         INDEX fk_catalog_product_media_gallery_attribute               ON catalog_product_entity_media_gallery            (`attribute_id`);
CREATE         INDEX fk_catalog_product_media_gallery_entity                  ON catalog_product_entity_media_gallery            (`entity_id`);
CREATE         INDEX fk_catalog_product_media_gallery_value_store             ON catalog_product_entity_media_gallery_value      (`store_id`);
CREATE         INDEX fk_catalog_product_entity_text_attribute                 ON catalog_product_entity_text                     (`attribute_id`);
CREATE         INDEX fk_catalog_product_entity_text_product_entity            ON catalog_product_entity_text                     (`entity_id`);
CREATE         INDEX fk_catalog_product_entity_text_store                     ON catalog_product_entity_text                     (`store_id`);
CREATE         INDEX fk_catalog_product_entity_tier_price_group               ON catalog_product_entity_tier_price               (`customer_group_id`);
CREATE         INDEX fk_catalog_product_entity_tier_price_product_entity      ON catalog_product_entity_tier_price               (`entity_id`);
CREATE         INDEX fk_catalog_product_tier_website                          ON catalog_product_entity_tier_price               (`website_id`);
CREATE         INDEX fk_catalog_product_entity_varchar_attribute              ON catalog_product_entity_varchar                  (`attribute_id`);
CREATE         INDEX fk_catalog_product_entity_varchar_product_entity         ON catalog_product_entity_varchar                  (`entity_id`);
CREATE         INDEX fk_catalog_product_entity_varchar_store                  ON catalog_product_entity_varchar                  (`store_id`);
CREATE         INDEX fk_product_link_type                                     ON catalog_product_link                            (`link_type_id`);
CREATE         INDEX fk_linked_product                                        ON catalog_product_link                            (`linked_product_id`);
CREATE         INDEX fk_link_product                                          ON catalog_product_link                            (`product_id`);
CREATE         INDEX fk_attribute_product_link_type                           ON catalog_product_link_attribute                  (`link_type_id`);
CREATE         INDEX fk_decimal_link                                          ON catalog_product_link_attribute_decimal          (`link_id`);
CREATE         INDEX fk_decimal_product_link_attribute                        ON catalog_product_link_attribute_decimal          (`product_link_attribute_id`);
CREATE         INDEX fk_int_product_link                                      ON catalog_product_link_attribute_int              (`link_id`);
CREATE         INDEX fk_int_product_link_attribute                            ON catalog_product_link_attribute_int              (`product_link_attribute_id`);
CREATE         INDEX fk_varchar_link                                          ON catalog_product_link_attribute_varchar          (`link_id`);
CREATE         INDEX fk_varchar_product_link_attribute                        ON catalog_product_link_attribute_varchar          (`product_link_attribute_id`);
CREATE         INDEX fk_super_product_attribute_product                       ON catalog_product_super_attribute                 (`product_id`);
CREATE         INDEX fk_super_product_attribute_label                         ON catalog_product_super_attribute_label           (`product_super_attribute_id`);
CREATE         INDEX fk_super_product_attribute_pricing                       ON catalog_product_super_attribute_pricing         (`product_super_attribute_id`);
CREATE         INDEX fk_super_product_link_parent                             ON catalog_product_super_link                      (`parent_id`);
CREATE         INDEX fk_catalog_product_super_link                            ON catalog_product_super_link                      (`product_id`);
CREATE         INDEX fk_catalog_product_website_website                       ON catalog_product_website                         (`website_id`);
CREATE         INDEX fk_catalogindex_eav_attribute                            ON catalogindex_eav                                (`attribute_id`);
CREATE         INDEX fk_catalogindex_eav_entity                               ON catalogindex_eav                                (`entity_id`);
CREATE         INDEX fk_catalogindex_eav_store                                ON catalogindex_eav                                (`store_id`);
CREATE         INDEX idx_value                                                ON catalogindex_eav                                (`value`);
CREATE         INDEX fk_catalogindex_minimal_price_customer_group             ON catalogindex_minimal_price                      (`customer_group_id`);
CREATE         INDEX fk_catalogindex_minimal_price_entity                     ON catalogindex_minimal_price                      (`entity_id`);
CREATE         INDEX idx_qty                                                  ON catalogindex_minimal_price                      (`qty`);
CREATE         INDEX fk_catalogindex_minimal_price_store                      ON catalogindex_minimal_price                      (`store_id`);
CREATE         INDEX idx_value                                                ON catalogindex_minimal_price                      (`value`);
CREATE         INDEX fk_catalogindex_price_attribute                          ON catalogindex_price                              (`attribute_id`);
CREATE         INDEX fk_catalogindex_price_customer_group                     ON catalogindex_price                              (`customer_group_id`);
CREATE         INDEX fk_catalogindex_price_entity                             ON catalogindex_price                              (`entity_id`);
CREATE         INDEX idx_qty                                                  ON catalogindex_price                              (`qty`);
CREATE         INDEX fk_catalogindex_price_store                              ON catalogindex_price                              (`store_id`);
CREATE         INDEX idx_value                                                ON catalogindex_price                              (`value`);
CREATE         INDEX fk_cataloginventory_stock_item_product                   ON cataloginventory_stock_item                     (`product_id`);
CREATE UNIQUE  INDEX idx_stock_product                                        ON cataloginventory_stock_item                     (`product_id`,`stock_id`);
CREATE         INDEX fk_cataloginventory_stock_item_stock                     ON cataloginventory_stock_item                     (`stock_id`);
CREATE         INDEX sort_order                                               ON catalogrule                                     (`is_active`,`sort_order`,`to_date`,`from_date`);
CREATE         INDEX fk_catalogrule_product_customergroup                     ON catalogrule_product                             (`customer_group_id`);
CREATE UNIQUE  INDEX sort_order                                               ON catalogrule_product                             (`from_time`,`to_time`,`website_id`,`customer_group_id`,`product_id`,`sort_order`);
CREATE         INDEX fk_catalogrule_product_rule                              ON catalogrule_product                             (`rule_id`);
CREATE         INDEX fk_catalogrule_product_website                           ON catalogrule_product                             (`website_id`);
CREATE         INDEX fk_catalogrule_product_price_customergroup               ON catalogrule_product_price                       (`customer_group_id`);
CREATE UNIQUE  INDEX rule_date                                                ON catalogrule_product_price                       (`rule_date`,`website_id`,`customer_group_id`,`product_id`);
CREATE         INDEX fk_catalogrule_product_price_website                     ON catalogrule_product_price                       (`website_id`);
CREATE         INDEX search_query                                             ON catalogsearch_query                             (`query_text`,`popularity`);
CREATE         INDEX fk_catalogsearch_query                                   ON catalogsearch_query                             (`store_id`);
CREATE         INDEX fk_cms_block_store_store                                 ON cms_block_store                                 (`store_id`);
CREATE         INDEX identifier                                               ON cms_page                                        (`identifier`);
CREATE         INDEX fk_cms_page_store_store                                  ON cms_page_store                                  (`store_id`);
CREATE UNIQUE  INDEX config_scope                                             ON core_config_data                                (`scope`,`scope_id`,`path`);
CREATE         INDEX added_at                                                 ON core_email_template                             (`added_at`);
CREATE         INDEX modified_at                                              ON core_email_template                             (`modified_at`);
CREATE UNIQUE  INDEX template_code                                            ON core_email_template                             (`template_code`);
CREATE         INDEX fk_core_layout_link_update                               ON core_layout_link                                (`layout_update_id`);
CREATE UNIQUE  INDEX store_id                                                 ON core_layout_link                                (`store_id`,`package`,`theme`,`layout_update_id`);
CREATE         INDEX handle                                                   ON core_layout_update                              (`handle`);
CREATE         INDEX fk_session_website                                       ON core_session                                    (`website_id`);
CREATE UNIQUE  INDEX code                                                     ON core_store                                      (`code`);
CREATE         INDEX fk_store_group                                           ON core_store                                      (`group_id`);
CREATE         INDEX is_active                                                ON core_store                                      (`is_active`,`sort_order`);
CREATE         INDEX fk_store_website                                         ON core_store                                      (`website_id`);
CREATE         INDEX default_store_id                                         ON core_store_group                                (`default_store_id`);
CREATE         INDEX fk_store_group_website                                   ON core_store_group                                (`website_id`);
CREATE         INDEX fk_core_translate_store                                  ON core_translate                                  (`store_id`);
CREATE UNIQUE  INDEX idx_code                                                 ON core_translate                                  (`store_id`,`locale`,`string`);
CREATE         INDEX fk_core_url_rewrite_category                             ON core_url_rewrite                                (`category_id`);
CREATE         INDEX fk_core_url_rewrite_product                              ON core_url_rewrite                                (`product_id`);
CREATE         INDEX fk_core_url_rewrite_store                                ON core_url_rewrite                                (`store_id`);
CREATE UNIQUE  INDEX unq_path                                                 ON core_url_rewrite                                (`store_id`,`id_path`,`is_system`);
CREATE UNIQUE  INDEX unq_request_path                                         ON core_url_rewrite                                (`store_id`,`request_path`);
CREATE         INDEX idx_target_path                                          ON core_url_rewrite                                (`store_id`,`target_path`);
CREATE UNIQUE  INDEX code                                                     ON core_website                                    (`code`);
CREATE         INDEX default_group_id                                         ON core_website                                    (`default_group_id`);
CREATE         INDEX sort_order                                               ON core_website                                    (`sort_order`);
CREATE         INDEX task_name                                                ON cron_schedule                                   (`job_code`);
CREATE         INDEX scheduled_at                                             ON cron_schedule                                   (`scheduled_at`,`status`);
CREATE         INDEX fk_customer_address_customer_id                          ON customer_address_entity                         (`parent_id`);
CREATE         INDEX fk_customer_address_datetime_attribute                   ON customer_address_entity_datetime                (`attribute_id`);
CREATE         INDEX fk_customer_address_datetime_entity                      ON customer_address_entity_datetime                (`entity_id`);
CREATE         INDEX fk_customer_address_datetime_entity_type                 ON customer_address_entity_datetime                (`entity_type_id`);
CREATE         INDEX fk_customer_address_decimal_attribute                    ON customer_address_entity_decimal                 (`attribute_id`);
CREATE         INDEX fk_customer_address_decimal_entity                       ON customer_address_entity_decimal                 (`entity_id`);
CREATE         INDEX fk_customer_address_decimal_entity_type                  ON customer_address_entity_decimal                 (`entity_type_id`);
CREATE         INDEX fk_customer_address_int_attribute                        ON customer_address_entity_int                     (`attribute_id`);
CREATE         INDEX fk_customer_address_int_entity                           ON customer_address_entity_int                     (`entity_id`);
CREATE         INDEX fk_customer_address_int_entity_type                      ON customer_address_entity_int                     (`entity_type_id`);
CREATE         INDEX fk_customer_address_text_attribute                       ON customer_address_entity_text                    (`attribute_id`);
CREATE         INDEX fk_customer_address_text_entity                          ON customer_address_entity_text                    (`entity_id`);
CREATE         INDEX fk_customer_address_text_entity_type                     ON customer_address_entity_text                    (`entity_type_id`);
CREATE         INDEX fk_customer_address_varchar_attribute                    ON customer_address_entity_varchar                 (`attribute_id`);
CREATE         INDEX fk_customer_address_varchar_entity                       ON customer_address_entity_varchar                 (`entity_id`);
CREATE         INDEX fk_customer_address_varchar_entity_type                  ON customer_address_entity_varchar                 (`entity_type_id`);
CREATE         INDEX idx_auth                                                 ON customer_entity                                 (`email`,`website_id`);
CREATE         INDEX idx_entity_type                                          ON customer_entity                                 (`entity_type_id`);
CREATE         INDEX fk_customer_entity_store                                 ON customer_entity                                 (`store_id`);
CREATE         INDEX fk_customer_website                                      ON customer_entity                                 (`website_id`);
CREATE         INDEX fk_customer_datetime_attribute                           ON customer_entity_datetime                        (`attribute_id`);
CREATE         INDEX fk_customer_datetime_entity                              ON customer_entity_datetime                        (`entity_id`);
CREATE         INDEX fk_customer_datetime_entity_type                         ON customer_entity_datetime                        (`entity_type_id`);
CREATE         INDEX fk_customer_decimal_attribute                            ON customer_entity_decimal                         (`attribute_id`);
CREATE         INDEX fk_customer_decimal_entity                               ON customer_entity_decimal                         (`entity_id`);
CREATE         INDEX fk_customer_decimal_entity_type                          ON customer_entity_decimal                         (`entity_type_id`);
CREATE         INDEX fk_customer_int_attribute                                ON customer_entity_int                             (`attribute_id`);
CREATE         INDEX fk_customer_int_entity                                   ON customer_entity_int                             (`entity_id`);
CREATE         INDEX fk_customer_int_entity_type                              ON customer_entity_int                             (`entity_type_id`);
CREATE         INDEX fk_customer_text_attribute                               ON customer_entity_text                            (`attribute_id`);
CREATE         INDEX fk_customer_text_entity                                  ON customer_entity_text                            (`entity_id`);
CREATE         INDEX fk_customer_text_entity_type                             ON customer_entity_text                            (`entity_type_id`);
CREATE         INDEX fk_customer_varchar_attribute                            ON customer_entity_varchar                         (`attribute_id`);
CREATE         INDEX fk_customer_varchar_entity                               ON customer_entity_varchar                         (`entity_id`);
CREATE         INDEX fk_customer_varchar_entity_type                          ON customer_entity_varchar                         (`entity_type_id`);
CREATE         INDEX idx_created_at                                           ON dataflow_batch                                  (`created_at`);
CREATE         INDEX fk_dataflow_batch_profile                                ON dataflow_batch                                  (`profile_id`);
CREATE         INDEX fk_dataflow_batch_store                                  ON dataflow_batch                                  (`store_id`);
CREATE         INDEX fk_dataflow_batch_export_batch                           ON dataflow_batch_export                           (`batch_id`);
CREATE         INDEX fk_dataflow_batch_import_batch                           ON dataflow_batch_import                           (`batch_id`);
CREATE         INDEX fk_dataflow_import_data                                  ON dataflow_import_data                            (`session_id`);
CREATE         INDEX fk_dataflow_profile_history                              ON dataflow_profile_history                        (`profile_id`);
CREATE         INDEX fk_design_change_store                                   ON design_change                                   (`store_id`);
CREATE UNIQUE  INDEX country_type                                             ON directory_country_format                        (`country_id`,`type`);
CREATE         INDEX fk_region_country                                        ON directory_country_region                        (`country_id`);
CREATE         INDEX fk_directory_region_name_region                          ON directory_country_region_name                   (`region_id`);
CREATE         INDEX fk_currency_rate_to                                      ON directory_currency_rate                         (`currency_to`);
CREATE UNIQUE  INDEX entity_type_id                                           ON eav_attribute                                   (`entity_type_id`,`attribute_code`);
CREATE UNIQUE  INDEX attribute_set_id                                         ON eav_attribute_group                             (`attribute_set_id`,`attribute_group_name`);
CREATE         INDEX attribute_set_id_2                                       ON eav_attribute_group                             (`attribute_set_id`,`sort_order`);
CREATE         INDEX fk_attribute_option_attribute                            ON eav_attribute_option                            (`attribute_id`);
CREATE         INDEX fk_attribute_option_value_option                         ON eav_attribute_option_value                      (`option_id`);
CREATE         INDEX fk_attribute_option_value_store                          ON eav_attribute_option_value                      (`store_id`);
CREATE UNIQUE  INDEX entity_type_id                                           ON eav_attribute_set                               (`entity_type_id`,`attribute_set_name`);
CREATE         INDEX entity_type_id_2                                         ON eav_attribute_set                               (`entity_type_id`,`sort_order`);
CREATE         INDEX fk_entity_entity_type                                    ON eav_entity                                      (`entity_type_id`);
CREATE         INDEX fk_entity_store                                          ON eav_entity                                      (`store_id`);
CREATE UNIQUE  INDEX attribute_group_id                                       ON eav_entity_attribute                            (`attribute_group_id`,`attribute_id`);
CREATE         INDEX fk_eav_entity_attrivute_attribute                        ON eav_entity_attribute                            (`attribute_id`);
CREATE UNIQUE  INDEX attribute_set_id_2                                       ON eav_entity_attribute                            (`attribute_set_id`,`attribute_id`);
CREATE         INDEX attribute_set_id_3                                       ON eav_entity_attribute                            (`attribute_set_id`,`sort_order`);
CREATE         INDEX fk_attribute_datetime_attribute                          ON eav_entity_datetime                             (`attribute_id`);
CREATE         INDEX value_by_attribute                                       ON eav_entity_datetime                             (`attribute_id`,`value`);
CREATE         INDEX fk_attribute_datetime_entity                             ON eav_entity_datetime                             (`entity_id`);
CREATE         INDEX fk_attribute_datetime_entity_type                        ON eav_entity_datetime                             (`entity_type_id`);
CREATE         INDEX value_by_entity_type                                     ON eav_entity_datetime                             (`entity_type_id`,`value`);
CREATE         INDEX fk_attribute_datetime_store                              ON eav_entity_datetime                             (`store_id`);
CREATE         INDEX fk_attribute_decimal_attribute                           ON eav_entity_decimal                              (`attribute_id`);
CREATE         INDEX value_by_attribute                                       ON eav_entity_decimal                              (`attribute_id`,`value`);
CREATE         INDEX fk_attribute_decimal_entity                              ON eav_entity_decimal                              (`entity_id`);
CREATE         INDEX fk_attribute_decimal_entity_type                         ON eav_entity_decimal                              (`entity_type_id`);
CREATE         INDEX value_by_entity_type                                     ON eav_entity_decimal                              (`entity_type_id`,`value`);
CREATE         INDEX fk_attribute_decimal_store                               ON eav_entity_decimal                              (`store_id`);
CREATE         INDEX fk_attribute_int_attribute                               ON eav_entity_int                                  (`attribute_id`);
CREATE         INDEX value_by_attribute                                       ON eav_entity_int                                  (`attribute_id`,`value`);
CREATE         INDEX fk_attribute_int_entity                                  ON eav_entity_int                                  (`entity_id`);
CREATE         INDEX fk_attribute_int_entity_type                             ON eav_entity_int                                  (`entity_type_id`);
CREATE         INDEX value_by_entity_type                                     ON eav_entity_int                                  (`entity_type_id`,`value`);
CREATE         INDEX fk_attribute_int_store                                   ON eav_entity_int                                  (`store_id`);
CREATE         INDEX fk_eav_entity_store_entity_type                          ON eav_entity_store                                (`entity_type_id`);
CREATE         INDEX fk_eav_entity_store_store                                ON eav_entity_store                                (`store_id`);
CREATE         INDEX fk_attribute_text_attribute                              ON eav_entity_text                                 (`attribute_id`);
CREATE         INDEX fk_attribute_text_entity                                 ON eav_entity_text                                 (`entity_id`);
CREATE         INDEX fk_attribute_text_entity_type                            ON eav_entity_text                                 (`entity_type_id`);
CREATE         INDEX fk_attribute_text_store                                  ON eav_entity_text                                 (`store_id`);
CREATE         INDEX entity_name                                              ON eav_entity_type                                 (`entity_type_code`);
CREATE         INDEX fk_attribute_varchar_attribute                           ON eav_entity_varchar                              (`attribute_id`);
CREATE         INDEX value_by_attribute                                       ON eav_entity_varchar                              (`attribute_id`,`value`);
CREATE         INDEX fk_attribute_varchar_entity                              ON eav_entity_varchar                              (`entity_id`);
CREATE         INDEX fk_attribute_varchar_entity_type                         ON eav_entity_varchar                              (`entity_type_id`);
CREATE         INDEX value_by_entity_type                                     ON eav_entity_varchar                              (`entity_type_id`,`value`);
CREATE         INDEX fk_attribute_varchar_store                               ON eav_entity_varchar                              (`store_id`);
CREATE UNIQUE  INDEX gift_code                                                ON giftcert_code                                   (`giftcert_code`);
CREATE         INDEX fk_problem_queue                                         ON newsletter_problem                              (`queue_id`);
CREATE         INDEX fk_problem_subscriber                                    ON newsletter_problem                              (`subscriber_id`);
CREATE         INDEX fk_queue_template                                        ON newsletter_queue                                (`template_id`);
CREATE         INDEX fk_queue_link_queue                                      ON newsletter_queue_link                           (`queue_id`);
CREATE         INDEX fk_queue_link_subscriber                                 ON newsletter_queue_link                           (`subscriber_id`);
CREATE         INDEX fk_newsletter_queue_store_link_store                     ON newsletter_queue_store_link                     (`store_id`);
CREATE         INDEX fk_subscriber_customer                                   ON newsletter_subscriber                           (`customer_id`);
CREATE         INDEX fk_newsletter_subscriber_store                           ON newsletter_subscriber                           (`store_id`);
CREATE         INDEX added_at                                                 ON newsletter_template                             (`added_at`);
CREATE         INDEX modified_at                                              ON newsletter_template                             (`modified_at`);
CREATE         INDEX template_actual                                          ON newsletter_template                             (`template_actual`);
CREATE         INDEX debug_at                                                 ON paypal_api_debug                                (`debug_at`);
CREATE         INDEX debug_at                                                 ON paypaluk_api_debug                              (`debug_at`);
CREATE         INDEX fk_poll_store                                            ON poll                                            (`store_id`);
CREATE         INDEX fk_poll_parent                                           ON poll_answer                                     (`poll_id`);
CREATE         INDEX fk_poll_store_store                                      ON poll_store                                      (`store_id`);
CREATE         INDEX fk_poll_answer                                           ON poll_vote                                       (`poll_answer_id`);
CREATE         INDEX fk_product_alert_price_customer                          ON product_alert_price                             (`customer_id`);
CREATE         INDEX fk_product_alert_price_product                           ON product_alert_price                             (`product_id`);
CREATE         INDEX fk_product_alert_price_website                           ON product_alert_price                             (`website_id`);
CREATE         INDEX fk_product_alert_price_customer                          ON product_alert_stock                             (`customer_id`);
CREATE         INDEX fk_product_alert_price_product                           ON product_alert_stock                             (`product_id`);
CREATE         INDEX fk_product_alert_price_website                           ON product_alert_stock                             (`website_id`);
CREATE         INDEX fk_rating_entity                                         ON rating                                          (`entity_id`);
CREATE UNIQUE  INDEX idx_code                                                 ON rating                                          (`rating_code`);
CREATE UNIQUE  INDEX idx_code                                                 ON rating_entity                                   (`entity_code`);
CREATE         INDEX fk_rating_option_rating                                  ON rating_option                                   (`rating_id`);
CREATE         INDEX fk_rating_option_value_option                            ON rating_option_vote                              (`option_id`);
CREATE         INDEX fk_rating_option_value_aggregate                         ON rating_option_vote_aggregated                   (`rating_id`);
CREATE         INDEX fk_rating_option_vote_aggregated_store                   ON rating_option_vote_aggregated                   (`store_id`);
CREATE         INDEX fk_rating_store_store                                    ON rating_store                                    (`store_id`);
CREATE         INDEX fk_rating_title_store                                    ON rating_title                                    (`store_id`);
CREATE         INDEX idx_event_type                                           ON report_event                                    (`event_type_id`);
CREATE         INDEX idx_object                                               ON report_event                                    (`object_id`);
CREATE         INDEX fk_report_event_store                                    ON report_event                                    (`store_id`);
CREATE         INDEX idx_subject                                              ON report_event                                    (`subject_id`);
CREATE         INDEX idx_subtype                                              ON report_event                                    (`subtype`);
CREATE         INDEX fk_review_entity                                         ON review                                          (`entity_id`);
CREATE         INDEX fk_review_parent_product                                 ON review                                          (`entity_pk_value`);
CREATE         INDEX fk_review_status                                         ON review                                          (`status_id`);
CREATE         INDEX fk_review_detail_review                                  ON review_detail                                   (`review_id`);
CREATE         INDEX fk_review_detail_store                                   ON review_detail                                   (`store_id`);
CREATE         INDEX fk_review_entity_summary_store                           ON review_entity_summary                           (`store_id`);
CREATE         INDEX fk_review_store_store                                    ON review_store                                    (`store_id`);
CREATE UNIQUE  INDEX store_id                                                 ON sales_counter                                   (`store_id`,`counter_type`);
CREATE UNIQUE  INDEX gift_code                                                ON sales_giftcert                                  (`giftcert_code`);
CREATE         INDEX fk_sales_order_type                                      ON sales_order                                     (`entity_type_id`);
CREATE         INDEX fk_sales_order_store                                     ON sales_order                                     (`store_id`);
CREATE         INDEX fk_sales_order_datetime_attribute                        ON sales_order_datetime                            (`attribute_id`);
CREATE         INDEX fk_sales_order_datetime                                  ON sales_order_datetime                            (`entity_id`);
CREATE         INDEX fk_sales_order_datetime_entity_type                      ON sales_order_datetime                            (`entity_type_id`);
CREATE         INDEX fk_sales_order_decimal_attribute                         ON sales_order_decimal                             (`attribute_id`);
CREATE         INDEX fk_sales_order_decimal                                   ON sales_order_decimal                             (`entity_id`);
CREATE         INDEX fk_sales_order_decimal_entity_type                       ON sales_order_decimal                             (`entity_type_id`);
CREATE         INDEX fk_sales_order_entity_type                               ON sales_order_entity                              (`entity_type_id`);
CREATE         INDEX fk_sales_order_entity_store                              ON sales_order_entity                              (`store_id`);
CREATE         INDEX fk_sales_order_entity_datetime_attribute                 ON sales_order_entity_datetime                     (`attribute_id`);
CREATE         INDEX fk_sales_order_entity_datetime                           ON sales_order_entity_datetime                     (`entity_id`);
CREATE         INDEX fk_sales_order_entity_datetime_entity_type               ON sales_order_entity_datetime                     (`entity_type_id`);
CREATE         INDEX fk_sales_order_entity_decimal_attribute                  ON sales_order_entity_decimal                      (`attribute_id`);
CREATE         INDEX fk_sales_order_entity_decimal                            ON sales_order_entity_decimal                      (`entity_id`);
CREATE         INDEX fk_sales_order_entity_decimal_entity_type                ON sales_order_entity_decimal                      (`entity_type_id`);
CREATE         INDEX fk_sales_order_entity_int_attribute                      ON sales_order_entity_int                          (`attribute_id`);
CREATE         INDEX fk_sales_order_entity_int                                ON sales_order_entity_int                          (`entity_id`);
CREATE         INDEX fk_sales_order_entity_int_entity_type                    ON sales_order_entity_int                          (`entity_type_id`);
CREATE         INDEX fk_sales_order_entity_text_attribute                     ON sales_order_entity_text                         (`attribute_id`);
CREATE         INDEX fk_sales_order_entity_text                               ON sales_order_entity_text                         (`entity_id`);
CREATE         INDEX fk_sales_order_entity_text_entity_type                   ON sales_order_entity_text                         (`entity_type_id`);
CREATE         INDEX fk_sales_order_entity_varchar_attribute                  ON sales_order_entity_varchar                      (`attribute_id`);
CREATE         INDEX fk_sales_order_entity_varchar                            ON sales_order_entity_varchar                      (`entity_id`);
CREATE         INDEX fk_sales_order_entity_varchar_entity_type                ON sales_order_entity_varchar                      (`entity_type_id`);
CREATE         INDEX fk_sales_order_int_attribute                             ON sales_order_int                                 (`attribute_id`);
CREATE         INDEX fk_sales_order_int                                       ON sales_order_int                                 (`entity_id`);
CREATE         INDEX fk_sales_order_int_entity_type                           ON sales_order_int                                 (`entity_type_id`);
CREATE         INDEX fk_sales_order_text_attribute                            ON sales_order_text                                (`attribute_id`);
CREATE         INDEX fk_sales_order_text                                      ON sales_order_text                                (`entity_id`);
CREATE         INDEX fk_sales_order_text_entity_type                          ON sales_order_text                                (`entity_type_id`);
CREATE         INDEX fk_sales_order_varchar_attribute                         ON sales_order_varchar                             (`attribute_id`);
CREATE         INDEX fk_sales_order_varchar                                   ON sales_order_varchar                             (`entity_id`);
CREATE         INDEX fk_sales_order_varchar_entity_type                       ON sales_order_varchar                             (`entity_type_id`);
CREATE         INDEX fk_sales_quote_store                                     ON sales_quote                                     (`store_id`);
CREATE         INDEX fk_sales_quote_address_quote                             ON sales_quote_address                             (`parent_id`);
CREATE         INDEX fk_sales_quote_address_decimal_attribute                 ON sales_quote_address_decimal                     (`attribute_id`);
CREATE         INDEX fk_sales_quote_address_decimal                           ON sales_quote_address_decimal                     (`entity_id`);
CREATE         INDEX fk_sales_quote_address_decimal_entity_type               ON sales_quote_address_decimal                     (`entity_type_id`);
CREATE         INDEX fk_sales_quote_address_int_attribute                     ON sales_quote_address_int                         (`attribute_id`);
CREATE         INDEX fk_sales_quote_address_int                               ON sales_quote_address_int                         (`entity_id`);
CREATE         INDEX fk_sales_quote_address_int_entity_type                   ON sales_quote_address_int                         (`entity_type_id`);
CREATE         INDEX fk_sales_quote_address_text_attribute                    ON sales_quote_address_text                        (`attribute_id`);
CREATE         INDEX fk_sales_quote_address_text                              ON sales_quote_address_text                        (`entity_id`);
CREATE         INDEX fk_sales_quote_address_text_entity_type                  ON sales_quote_address_text                        (`entity_type_id`);
CREATE         INDEX fk_sales_quote_address_varchar_attribute                 ON sales_quote_address_varchar                     (`attribute_id`);
CREATE         INDEX fk_sales_quote_address_varchar                           ON sales_quote_address_varchar                     (`entity_id`);
CREATE         INDEX fk_sales_quote_address_varchar_entity_type               ON sales_quote_address_varchar                     (`entity_type_id`);
CREATE         INDEX fk_sales_quote_decimal_attribute                         ON sales_quote_decimal                             (`attribute_id`);
CREATE         INDEX fk_sales_quote_decimal                                   ON sales_quote_decimal                             (`entity_id`);
CREATE         INDEX fk_sales_quote_decimal_entity_type                       ON sales_quote_decimal                             (`entity_type_id`);
CREATE         INDEX fk_sales_quote_entity_type                               ON sales_quote_entity                              (`entity_type_id`);
CREATE         INDEX fk_sales_quote_entity_store                              ON sales_quote_entity                              (`store_id`);
CREATE         INDEX fk_sales_quote_entity_datetime_attribute                 ON sales_quote_entity_datetime                     (`attribute_id`);
CREATE         INDEX fk_sales_quote_entity_datetime                           ON sales_quote_entity_datetime                     (`entity_id`);
CREATE         INDEX fk_sales_quote_entity_datetime_entity_type               ON sales_quote_entity_datetime                     (`entity_type_id`);
CREATE         INDEX fk_sales_quote_entity_decimal_attribute                  ON sales_quote_entity_decimal                      (`attribute_id`);
CREATE         INDEX fk_sales_quote_entity_decimal                            ON sales_quote_entity_decimal                      (`entity_id`);
CREATE         INDEX fk_sales_quote_entity_decimal_entity_type                ON sales_quote_entity_decimal                      (`entity_type_id`);
CREATE         INDEX fk_sales_quote_entity_int_attribute                      ON sales_quote_entity_int                          (`attribute_id`);
CREATE         INDEX fk_sales_quote_entity_int                                ON sales_quote_entity_int                          (`entity_id`);
CREATE         INDEX fk_sales_quote_entity_int_entity_type                    ON sales_quote_entity_int                          (`entity_type_id`);
CREATE         INDEX fk_sales_quote_entity_text_attribute                     ON sales_quote_entity_text                         (`attribute_id`);
CREATE         INDEX fk_sales_quote_entity_text                               ON sales_quote_entity_text                         (`entity_id`);
CREATE         INDEX fk_sales_quote_entity_text_entity_type                   ON sales_quote_entity_text                         (`entity_type_id`);
CREATE         INDEX fk_sales_quote_entity_varchar_attribute                  ON sales_quote_entity_varchar                      (`attribute_id`);
CREATE         INDEX fk_sales_quote_entity_varchar                            ON sales_quote_entity_varchar                      (`entity_id`);
CREATE         INDEX fk_sales_quote_entity_varchar_entity_type                ON sales_quote_entity_varchar                      (`entity_type_id`);
CREATE         INDEX fk_sales_quote_int_attribute                             ON sales_quote_int                                 (`attribute_id`);
CREATE         INDEX fk_sales_quote_int                                       ON sales_quote_int                                 (`entity_id`);
CREATE         INDEX fk_sales_quote_int_entity_type                           ON sales_quote_int                                 (`entity_type_id`);
CREATE         INDEX fk_sales_quote_item_quote                                ON sales_quote_item                                (`parent_id`);
CREATE         INDEX fk_sales_quote_item_decimal_attribute                    ON sales_quote_item_decimal                        (`attribute_id`);
CREATE         INDEX fk_sales_quote_item_decimal                              ON sales_quote_item_decimal                        (`entity_id`);
CREATE         INDEX fk_sales_quote_item_decimal_entity_type                  ON sales_quote_item_decimal                        (`entity_type_id`);
CREATE         INDEX fk_sales_quote_item_int_attribute                        ON sales_quote_item_int                            (`attribute_id`);
CREATE         INDEX fk_sales_quote_item_int                                  ON sales_quote_item_int                            (`entity_id`);
CREATE         INDEX fk_sales_quote_item_int_entity_type                      ON sales_quote_item_int                            (`entity_type_id`);
CREATE         INDEX fk_sales_quote_item_text_attribute                       ON sales_quote_item_text                           (`attribute_id`);
CREATE         INDEX fk_sales_quote_item_text                                 ON sales_quote_item_text                           (`entity_id`);
CREATE         INDEX fk_sales_quote_item_text_entity_type                     ON sales_quote_item_text                           (`entity_type_id`);
CREATE         INDEX fk_sales_quote_item_varchar_attribute                    ON sales_quote_item_varchar                        (`attribute_id`);
CREATE         INDEX fk_sales_quote_item_varchar                              ON sales_quote_item_varchar                        (`entity_id`);
CREATE         INDEX fk_sales_quote_item_varchar_entity_type                  ON sales_quote_item_varchar                        (`entity_type_id`);
CREATE         INDEX is_active                                                ON sales_quote_rule                                (`is_active`,`start_at`,`expire_at`,`coupon_code`,`customer_registered`,`customer_new_buyer`,`show_in_catalog`,`sort_order`);
CREATE         INDEX rule_name                                                ON sales_quote_rule                                (`name`);
CREATE         INDEX fk_sales_quote_text_attribute                            ON sales_quote_text                                (`attribute_id`);
CREATE         INDEX fk_sales_quote_text                                      ON sales_quote_text                                (`entity_id`);
CREATE         INDEX fk_sales_quote_text_entity_type                          ON sales_quote_text                                (`entity_type_id`);
CREATE         INDEX fk_sales_quote_varchar_attribute                         ON sales_quote_varchar                             (`attribute_id`);
CREATE         INDEX fk_sales_quote_varchar                                   ON sales_quote_varchar                             (`entity_id`);
CREATE         INDEX fk_sales_quote_varchar_entity_type                       ON sales_quote_varchar                             (`entity_type_id`);
CREATE         INDEX sort_order                                               ON salesrule                                       (`is_active`,`sort_order`,`to_date`,`from_date`);
CREATE         INDEX customer_id                                              ON salesrule_customer                              (`customer_id`,`rule_id`);
CREATE         INDEX rule_id                                                  ON salesrule_customer                              (`rule_id`,`customer_id`);
CREATE         INDEX ip                                                       ON sendfriend_log                                  (`ip`);
CREATE         INDEX `time`                                                   ON sendfriend_log                                  (`time`);
CREATE UNIQUE  INDEX dest_country                                             ON shipping_tablerate                              (`website_id`,`dest_country_id`,`dest_region_id`,`dest_zip`,`condition_name`,`condition_value`);
CREATE         INDEX fk_sitemap_store                                         ON sitemap                                         (`store_id`);
CREATE         INDEX fk_tag_relation_customer                                 ON tag_relation                                    (`customer_id`);
CREATE         INDEX fk_tag_relation_product                                  ON tag_relation                                    (`product_id`);
CREATE         INDEX fk_tag_relation_store                                    ON tag_relation                                    (`store_id`);
CREATE         INDEX fk_tag_relation_tag                                      ON tag_relation                                    (`tag_id`);
CREATE         INDEX fk_tag_summary_store                                     ON tag_summary                                     (`store_id`);
CREATE UNIQUE  INDEX idx_rate_rate_type                                       ON shipping_tablerate                              (`tax_rate_id`,`rate_type_id`);
CREATE         INDEX rate_type_id                                             ON tax_rate_data                                   (`rate_type_id`);
CREATE         INDEX rate_id                                                  ON tax_rate_data                                   (`tax_rate_id`);
CREATE         INDEX tax_customer_class_id_2                                  ON tax_rule                                        (`tax_customer_class_id`);
CREATE         INDEX tax_customer_class_id                                    ON tax_rule                                        (`tax_customer_class_id`,`tax_product_class_id`);
CREATE         INDEX tax_product_class_id                                     ON tax_rule                                        (`tax_product_class_id`);
CREATE         INDEX tax_rate_id                                              ON tax_rule                                        (`tax_rate_type_id`);
CREATE         INDEX country_id                                               ON usa_postcode                                    (`country_id`);
CREATE         INDEX country_id_3                                             ON usa_postcode                                    (`country_id`,`city`);
CREATE         INDEX country_id_2                                             ON usa_postcode                                    (`country_id`,`region_id`);
CREATE         INDEX postcode                                                 ON usa_postcode                                    (`postcode`);
CREATE UNIQUE  INDEX fk_customer                                              ON wishlist                                        (`customer_id`);
CREATE         INDEX fk_wishlist_product                                      ON wishlist_item                                   (`product_id`);
CREATE         INDEX fk_wishlist_store                                        ON wishlist_item                                   (`store_id`);
CREATE         INDEX fk_item_wishlist                                         ON wishlist_item                                   (`wishlist_id`);

-- -------------------
--  Foreign Keys
-- -------------------
ALTER TABLE admin_rule                                    ADD CONSTRAINT fk_admin_rule                                        FOREIGN KEY (`role_id`)                      REFERENCES admin_role                           (`role_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_datetime              ADD CONSTRAINT fk_catalog_category_entity_datetime_attribute        FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_datetime              ADD CONSTRAINT fk_catalog_category_entity_datetime_entity           FOREIGN KEY (`entity_id`)                    REFERENCES catalog_category_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_datetime              ADD CONSTRAINT fk_catalog_category_entity_datetime_store            FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_decimal               ADD CONSTRAINT fk_catalog_category_entity_decimal_attribute         FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_decimal               ADD CONSTRAINT fk_catalog_category_entity_decimal_entity            FOREIGN KEY (`entity_id`)                    REFERENCES catalog_category_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_decimal               ADD CONSTRAINT fk_catalog_category_entity_decimal_store             FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_int                   ADD CONSTRAINT fk_catalog_category_emtity_int_attribute             FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_int                   ADD CONSTRAINT fk_catalog_category_emtity_int_entity                FOREIGN KEY (`entity_id`)                    REFERENCES catalog_category_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_int                   ADD CONSTRAINT fk_catalog_category_emtity_int_store                 FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_text                  ADD CONSTRAINT fk_catalog_category_entity_text_attribute            FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_text                  ADD CONSTRAINT fk_catalog_category_entity_text_entity               FOREIGN KEY (`entity_id`)                    REFERENCES catalog_category_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_text                  ADD CONSTRAINT fk_catalog_category_entity_text_store                FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_varchar               ADD CONSTRAINT fk_catalog_category_entity_varchar_attribute         FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_varchar               ADD CONSTRAINT fk_catalog_category_entity_varchar_entity            FOREIGN KEY (`entity_id`)                    REFERENCES catalog_category_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_entity_varchar               ADD CONSTRAINT fk_catalog_category_entity_varchar_store             FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_product                      ADD CONSTRAINT catalog_category_product_category                    FOREIGN KEY (`category_id`)                  REFERENCES catalog_category_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_category_product                      ADD CONSTRAINT catalog_category_product_product                     FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_compare_item                          ADD CONSTRAINT fk_catalog_compare_item_customer                     FOREIGN KEY (`customer_id`)                  REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_compare_item                          ADD CONSTRAINT fk_catalog_compare_item_product                      FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_bundle_option                 ADD CONSTRAINT fk_catalog_product_bundle_option                     FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_bundle_option_link            ADD CONSTRAINT fk_catalog_product_bundle_option_link                FOREIGN KEY (`option_id`)                    REFERENCES catalog_product_bundle_option        (`option_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_bundle_option_link            ADD CONSTRAINT fk_catalog_product_bundle_option_link_entity         FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_bundle_option_value           ADD CONSTRAINT fk_catalog_product_bundle_option_label               FOREIGN KEY (`option_id`)                    REFERENCES catalog_product_bundle_option        (`option_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_entity                        ADD CONSTRAINT fk_catalog_product_entity_attribute_set_id           FOREIGN KEY (`attribute_set_id`)             REFERENCES eav_attribute_set                    (`attribute_set_id`)             ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity                        ADD CONSTRAINT fk_catalog_product_entity_entity_type                FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_datetime               ADD CONSTRAINT fk_catalog_product_entity_datetime_attribute         FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_datetime               ADD CONSTRAINT fk_catalog_product_entity_datetime_product_entity    FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_datetime               ADD CONSTRAINT fk_catalog_product_entity_datetime_store             FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_decimal                ADD CONSTRAINT fk_catalog_product_entity_decimal_attribute          FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_decimal                ADD CONSTRAINT fk_catalog_product_entity_decimal_product_entity     FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_decimal                ADD CONSTRAINT fk_catalog_product_entity_decimal_store              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_gallery                ADD CONSTRAINT fk_catalog_product_entity_gallery_attribute          FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_gallery                ADD CONSTRAINT fk_catalog_product_entity_gallery_entity             FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_gallery                ADD CONSTRAINT fk_catalog_product_entity_gallery_store              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_int                    ADD CONSTRAINT fk_catalog_product_entity_int_attribute              FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_int                    ADD CONSTRAINT fk_catalog_product_entity_int_product_entity         FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_int                    ADD CONSTRAINT fk_catalog_product_entity_int_store                  FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_media_gallery          ADD CONSTRAINT fk_catalog_product_media_gallery_attribute           FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_entity_media_gallery          ADD CONSTRAINT fk_catalog_product_media_gallery_entity              FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_entity_media_gallery_value    ADD CONSTRAINT fk_catalog_product_media_gallery_value_gallery       FOREIGN KEY (`value_id`)                     REFERENCES catalog_product_entity_media_gallery (`value_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_entity_media_gallery_value    ADD CONSTRAINT fk_catalog_product_media_gallery_value_store         FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_entity_text                   ADD CONSTRAINT fk_catalog_product_entity_text_attribute             FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_text                   ADD CONSTRAINT fk_catalog_product_entity_text_product_entity        FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_text                   ADD CONSTRAINT fk_catalog_product_entity_text_store                 FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_tier_price             ADD CONSTRAINT fk_catalog_product_entity_tier_price_group           FOREIGN KEY (`customer_group_id`)            REFERENCES customer_group                       (`customer_group_id`)            ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_tier_price             ADD CONSTRAINT fk_catalog_product_entity_tier_price_product_entity  FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_tier_price             ADD CONSTRAINT fk_catalog_product_tier_website                      FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_varchar                ADD CONSTRAINT fk_catalog_product_entity_varchar_attribute          FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_varchar                ADD CONSTRAINT fk_catalog_product_entity_varchar_product_entity     FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_entity_varchar                ADD CONSTRAINT fk_catalog_product_entity_varchar_store              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link                          ADD CONSTRAINT fk_product_link_linked_product                       FOREIGN KEY (`linked_product_id`)            REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link                          ADD CONSTRAINT fk_product_link_product                              FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link                          ADD CONSTRAINT fk_product_link_type                                 FOREIGN KEY (`link_type_id`)                 REFERENCES catalog_product_link_type            (`link_type_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link_attribute                ADD CONSTRAINT fk_attribute_product_link_type                       FOREIGN KEY (`link_type_id`)                 REFERENCES catalog_product_link_type            (`link_type_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link_attribute_decimal        ADD CONSTRAINT fk_decimal_link                                      FOREIGN KEY (`link_id`)                      REFERENCES catalog_product_link                 (`link_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link_attribute_decimal        ADD CONSTRAINT fk_decimal_product_link_attribute                    FOREIGN KEY (`product_link_attribute_id`)    REFERENCES catalog_product_link_attribute       (`product_link_attribute_id`)    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link_attribute_int            ADD CONSTRAINT fk_int_product_link                                  FOREIGN KEY (`link_id`)                      REFERENCES catalog_product_link                 (`link_id`)                      ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_link_attribute_int            ADD CONSTRAINT fk_int_product_link_attribute                        FOREIGN KEY (`product_link_attribute_id`)    REFERENCES catalog_product_link_attribute       (`product_link_attribute_id`)    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_link_attribute_varchar        ADD CONSTRAINT fk_varchar_link                                      FOREIGN KEY (`link_id`)                      REFERENCES catalog_product_link                 (`link_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_link_attribute_varchar        ADD CONSTRAINT fk_varchar_product_link_attribute                    FOREIGN KEY (`product_link_attribute_id`)    REFERENCES catalog_product_link_attribute       (`product_link_attribute_id`)    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalog_product_super_attribute               ADD CONSTRAINT fk_super_product_attribute_product                   FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_super_attribute_label         ADD CONSTRAINT fk_super_product_attribute_label                     FOREIGN KEY (`product_super_attribute_id`)   REFERENCES catalog_product_super_attribute      (`product_super_attribute_id`)   ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_super_attribute_pricing       ADD CONSTRAINT fk_super_product_attribute_pricing                   FOREIGN KEY (`product_super_attribute_id`)   REFERENCES catalog_product_super_attribute      (`product_super_attribute_id`)   ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_super_link                    ADD CONSTRAINT fk_super_product_link_entity                         FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalog_product_super_link                    ADD CONSTRAINT fk_super_product_link_parent                         FOREIGN KEY (`parent_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE catalogindex_eav                              ADD CONSTRAINT fk_catalogindex_eav_attribute                        FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_eav                              ADD CONSTRAINT fk_catalogindex_eav_entity                           FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_eav                              ADD CONSTRAINT fk_catalogindex_eav_store                            FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_minimal_price                    ADD CONSTRAINT fk_catalogindex_minimal_price_customer_group         FOREIGN KEY (`customer_group_id`)            REFERENCES customer_group                       (`customer_group_id`)            ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_minimal_price                    ADD CONSTRAINT fk_catalogindex_minimal_price_entity                 FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_minimal_price                    ADD CONSTRAINT fk_catalogindex_minimal_price_store                  FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_price                            ADD CONSTRAINT fk_catalogindex_price_attribute                      FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_price                            ADD CONSTRAINT fk_catalogindex_price_entity                         FOREIGN KEY (`entity_id`)                    REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogindex_price                            ADD CONSTRAINT fk_catalogindex_price_store                          FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE cataloginventory_stock_item                   ADD CONSTRAINT fk_cataloginventory_stock_item_product               FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE cataloginventory_stock_item                   ADD CONSTRAINT fk_cataloginventory_stock_item_stock                 FOREIGN KEY (`stock_id`)                     REFERENCES cataloginventory_stock               (`stock_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogrule_product                           ADD CONSTRAINT fk_catalogrule_product_customergroup                 FOREIGN KEY (`customer_group_id`)            REFERENCES customer_group                       (`customer_group_id`)            ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogrule_product                           ADD CONSTRAINT fk_catalogrule_product_rule                          FOREIGN KEY (`rule_id`)                      REFERENCES catalogrule                          (`rule_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogrule_product                           ADD CONSTRAINT fk_catalogrule_product_website                       FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogrule_product_price                     ADD CONSTRAINT fk_catalogrule_product_price_customergroup           FOREIGN KEY (`customer_group_id`)            REFERENCES customer_group                       (`customer_group_id`)            ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogrule_product_price                     ADD CONSTRAINT fk_catalogrule_product_price_website                 FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE catalogsearch_query                           ADD CONSTRAINT fk_catalogsearch_query                               FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE cms_block_store                               ADD CONSTRAINT fk_cms_block_store_block                             FOREIGN KEY (`block_id`)                     REFERENCES cms_block                            (`block_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE cms_block_store                               ADD CONSTRAINT fk_cms_block_store_store                             FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE cms_page_store                                ADD CONSTRAINT fk_cms_page_store_page                               FOREIGN KEY (`page_id`)                      REFERENCES cms_page                             (`page_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE cms_page_store                                ADD CONSTRAINT fk_cms_page_store_store                              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_layout_link                              ADD CONSTRAINT fk_core_layout_link_store                            FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_layout_link                              ADD CONSTRAINT fk_core_layout_link_update                           FOREIGN KEY (`layout_update_id`)             REFERENCES core_layout_update                   (`layout_update_id`)             ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_session                                  ADD CONSTRAINT fk_session_website                                   FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_store                                    ADD CONSTRAINT fk_store_group_store                                 FOREIGN KEY (`group_id`)                     REFERENCES core_store_group                     (`group_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_store                                    ADD CONSTRAINT fk_store_website                                     FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_store_group                              ADD CONSTRAINT fk_store_group_website                               FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_translate                                ADD CONSTRAINT fk_core_translate_store                              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_url_rewrite                              ADD CONSTRAINT core_url_rewrite_ibfk_1                              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_url_rewrite                              ADD CONSTRAINT fk_core_url_rewrite_category                         FOREIGN KEY (`category_id`)                  REFERENCES catalog_category_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE core_url_rewrite                              ADD CONSTRAINT fk_core_url_rewrite_product                          FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity                       ADD CONSTRAINT fk_customer_address_customer_id                      FOREIGN KEY (`parent_id`)                    REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_datetime              ADD CONSTRAINT fk_customer_address_datetime_attribute               FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_datetime              ADD CONSTRAINT fk_customer_address_datetime_entity                  FOREIGN KEY (`entity_id`)                    REFERENCES customer_address_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_datetime              ADD CONSTRAINT fk_customer_address_datetime_entity_type             FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_decimal               ADD CONSTRAINT fk_customer_address_decimal_attribute                FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_decimal               ADD CONSTRAINT fk_customer_address_decimal_entity                   FOREIGN KEY (`entity_id`)                    REFERENCES customer_address_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_decimal               ADD CONSTRAINT fk_customer_address_decimal_entity_type              FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_int                   ADD CONSTRAINT fk_customer_address_int_attribute                    FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_int                   ADD CONSTRAINT fk_customer_address_int_entity                       FOREIGN KEY (`entity_id`)                    REFERENCES customer_address_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_int                   ADD CONSTRAINT fk_customer_address_int_entity_type                  FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_text                  ADD CONSTRAINT fk_customer_address_text_attribute                   FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_text                  ADD CONSTRAINT fk_customer_address_text_entity                      FOREIGN KEY (`entity_id`)                    REFERENCES customer_address_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_text                  ADD CONSTRAINT fk_customer_address_text_entity_type                 FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_varchar               ADD CONSTRAINT fk_customer_address_varchar_attribute                FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_varchar               ADD CONSTRAINT fk_customer_address_varchar_entity                   FOREIGN KEY (`entity_id`)                    REFERENCES customer_address_entity              (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_address_entity_varchar               ADD CONSTRAINT fk_customer_address_varchar_entity_type              FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity                               ADD CONSTRAINT fk_customer_entity_store                             FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  SET NULL  ON UPDATE   CASCADE ;
ALTER TABLE customer_entity                               ADD CONSTRAINT fk_customer_website                                  FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  SET NULL  ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_datetime                      ADD CONSTRAINT fk_customer_datetime_attribute                       FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_datetime                      ADD CONSTRAINT fk_customer_datetime_entity                          FOREIGN KEY (`entity_id`)                    REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_datetime                      ADD CONSTRAINT fk_customer_datetime_entity_type                     FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_decimal                       ADD CONSTRAINT fk_customer_decimal_attribute                        FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_decimal                       ADD CONSTRAINT fk_customer_decimal_entity                           FOREIGN KEY (`entity_id`)                    REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_decimal                       ADD CONSTRAINT fk_customer_decimal_entity_type                      FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_int                           ADD CONSTRAINT fk_customer_int_attribute                            FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_int                           ADD CONSTRAINT fk_customer_int_entity                               FOREIGN KEY (`entity_id`)                    REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_int                           ADD CONSTRAINT fk_customer_int_entity_type                          FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_text                          ADD CONSTRAINT fk_customer_text_attribute                           FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_text                          ADD CONSTRAINT fk_customer_text_entity                              FOREIGN KEY (`entity_id`)                    REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_text                          ADD CONSTRAINT fk_customer_text_entity_type                         FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_varchar                       ADD CONSTRAINT fk_customer_varchar_attribute                        FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_varchar                       ADD CONSTRAINT fk_customer_varchar_entity                           FOREIGN KEY (`entity_id`)                    REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE customer_entity_varchar                       ADD CONSTRAINT fk_customer_varchar_entity_type                      FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE dataflow_batch                                ADD CONSTRAINT fk_dataflow_batch_profile                            FOREIGN KEY (`profile_id`)                   REFERENCES dataflow_profile                     (`profile_id`)                   ON DELETE  CASCADE                       ;
ALTER TABLE dataflow_batch                                ADD CONSTRAINT fk_dataflow_batch_store                              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE dataflow_batch_export                         ADD CONSTRAINT fk_dataflow_batch_export_batch                       FOREIGN KEY (`batch_id`)                     REFERENCES dataflow_batch                       (`batch_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE dataflow_batch_import                         ADD CONSTRAINT fk_dataflow_batch_import_batch                       FOREIGN KEY (`batch_id`)                     REFERENCES dataflow_batch                       (`batch_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE dataflow_import_data                          ADD CONSTRAINT fk_dataflow_import_data                              FOREIGN KEY (`session_id`)                   REFERENCES dataflow_session                     (`session_id`)                                                            ;
ALTER TABLE dataflow_profile_history                      ADD CONSTRAINT fk_dataflow_profile_history                          FOREIGN KEY (`profile_id`)                   REFERENCES dataflow_profile                     (`profile_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE design_change                                 ADD CONSTRAINT fk_design_change_store                               FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                                                              ;
ALTER TABLE directory_country_region_name                 ADD CONSTRAINT fk_directory_region_name_region                      FOREIGN KEY (`region_id`)                    REFERENCES directory_country_region             (`region_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_attribute                                 ADD CONSTRAINT fk_eav_attribute                                     FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_attribute_group                           ADD CONSTRAINT fk_eav_attribute_group                               FOREIGN KEY (`attribute_set_id`)             REFERENCES eav_attribute_set                    (`attribute_set_id`)             ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_attribute_option                          ADD CONSTRAINT fk_attribute_option_attribute                        FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_attribute_option_value                    ADD CONSTRAINT fk_attribute_option_value_option                     FOREIGN KEY (`option_id`)                    REFERENCES eav_attribute_option                 (`option_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_attribute_option_value                    ADD CONSTRAINT fk_attribute_option_value_store                      FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_attribute_set                             ADD CONSTRAINT fk_eav_attribute_set                                 FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity                                    ADD CONSTRAINT fk_eav_entity                                        FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity                                    ADD CONSTRAINT fk_eav_entity_store                                  FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_attribute                          ADD CONSTRAINT fk_eav_entity_attribute                              FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_attribute                          ADD CONSTRAINT fk_eav_entity_attribute_group                        FOREIGN KEY (`attribute_group_id`)           REFERENCES eav_attribute_group                  (`attribute_group_id`)           ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_attribute                          ADD CONSTRAINT fk_eav_entity_attrivute_attribute                    FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_attribute                          ADD CONSTRAINT fk_eav_entity_attrivute_group                        FOREIGN KEY (`attribute_group_id`)           REFERENCES eav_attribute_group                  (`attribute_group_id`)           ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_datetime                           ADD CONSTRAINT fk_eav_entity_datetime_entity                        FOREIGN KEY (`entity_id`)                    REFERENCES eav_entity                           (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_datetime                           ADD CONSTRAINT fk_eav_entity_datetime_entity_type                   FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_datetime                           ADD CONSTRAINT fk_eav_entity_datetime_store                         FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_decimal                            ADD CONSTRAINT fk_eav_entity_decimal_entity                         FOREIGN KEY (`entity_id`)                    REFERENCES eav_entity                           (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_decimal                            ADD CONSTRAINT fk_eav_entity_decimal_entity_type                    FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_decimal                            ADD CONSTRAINT fk_eav_entity_decimal_store                          FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_int                                ADD CONSTRAINT fk_eav_entity_int_entity                             FOREIGN KEY (`entity_id`)                    REFERENCES eav_entity                           (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_int                                ADD CONSTRAINT fk_eav_entity_int_entity_type                        FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_int                                ADD CONSTRAINT fk_eav_entity_int_store                              FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_store                              ADD CONSTRAINT fk_eav_entity_store_entity_type                      FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_store                              ADD CONSTRAINT fk_eav_entity_store_store                            FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_text                               ADD CONSTRAINT fk_eav_entity_text_entity                            FOREIGN KEY (`entity_id`)                    REFERENCES eav_entity                           (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_text                               ADD CONSTRAINT fk_eav_entity_text_entity_type                       FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_text                               ADD CONSTRAINT fk_eav_entity_text_store                             FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_varchar                            ADD CONSTRAINT fk_eav_entity_varchar_entity                         FOREIGN KEY (`entity_id`)                    REFERENCES eav_entity                           (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_varchar                            ADD CONSTRAINT fk_eav_entity_varchar_entity_type                    FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE eav_entity_varchar                            ADD CONSTRAINT fk_eav_entity_varchar_store                          FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE newsletter_problem                            ADD CONSTRAINT fk_problem_queue                                     FOREIGN KEY (`queue_id`)                     REFERENCES newsletter_queue                     (`queue_id`)                                                              ;
ALTER TABLE newsletter_problem                            ADD CONSTRAINT fk_problem_subscriber                                FOREIGN KEY (`subscriber_id`)                REFERENCES newsletter_subscriber                (`subscriber_id`)                                                         ;
ALTER TABLE newsletter_queue                              ADD CONSTRAINT fk_queue_template                                    FOREIGN KEY (`template_id`)                  REFERENCES newsletter_template                  (`template_id`)                  ON DELETE  CASCADE                       ;
ALTER TABLE newsletter_queue_link                         ADD CONSTRAINT fk_queue_link_queue                                  FOREIGN KEY (`queue_id`)                     REFERENCES newsletter_queue                     (`queue_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE newsletter_queue_link                         ADD CONSTRAINT fk_queue_link_subscriber                             FOREIGN KEY (`subscriber_id`)                REFERENCES newsletter_subscriber                (`subscriber_id`)                ON DELETE  CASCADE                       ;
ALTER TABLE newsletter_queue_store_link                   ADD CONSTRAINT fk_link_queue                                        FOREIGN KEY (`queue_id`)                     REFERENCES newsletter_queue                     (`queue_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE newsletter_queue_store_link                   ADD CONSTRAINT fk_newsletter_queue_store_link_store                 FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE newsletter_subscriber                         ADD CONSTRAINT fk_newsletter_subscriber_store                       FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  SET NULL  ON UPDATE   CASCADE ;
ALTER TABLE poll                                          ADD CONSTRAINT fk_poll_store                                        FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  SET NULL  ON UPDATE   CASCADE ;
ALTER TABLE poll_answer                                   ADD CONSTRAINT fk_poll_parent                                       FOREIGN KEY (`poll_id`)                      REFERENCES poll                                 (`poll_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE poll_store                                    ADD CONSTRAINT fk_poll_store_poll                                   FOREIGN KEY (`poll_id`)                      REFERENCES poll                                 (`poll_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE poll_store                                    ADD CONSTRAINT fk_poll_store_store                                  FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE poll_vote                                     ADD CONSTRAINT fk_poll_answer                                       FOREIGN KEY (`poll_answer_id`)               REFERENCES poll_answer                          (`answer_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE product_alert_price                           ADD CONSTRAINT fk_product_alert_price_customer                      FOREIGN KEY (`customer_id`)                  REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE product_alert_price                           ADD CONSTRAINT fk_product_alert_price_product                       FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE product_alert_price                           ADD CONSTRAINT fk_product_alert_price_website                       FOREIGN KEY (`website_id`)                   REFERENCES core_website                         (`website_id`)                   ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating                                        ADD CONSTRAINT fk_rating_entity_key                                 FOREIGN KEY (`entity_id`)                    REFERENCES rating_entity                        (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating_option                                 ADD CONSTRAINT fk_rating_option_rating                              FOREIGN KEY (`rating_id`)                    REFERENCES rating                               (`rating_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating_option_vote                            ADD CONSTRAINT fk_rating_option_value_option                        FOREIGN KEY (`option_id`)                    REFERENCES rating_option                        (`option_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating_option_vote_aggregated                 ADD CONSTRAINT fk_rating_option_value_aggregate                     FOREIGN KEY (`rating_id`)                    REFERENCES rating                               (`rating_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating_option_vote_aggregated                 ADD CONSTRAINT fk_rating_option_vote_aggregated_store               FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating_store                                  ADD CONSTRAINT fk_rating_store_rating                               FOREIGN KEY (`rating_id`)                    REFERENCES rating                               (`rating_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE rating_store                                  ADD CONSTRAINT fk_rating_store_store                                FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating_title                                  ADD CONSTRAINT fk_rating_title                                      FOREIGN KEY (`rating_id`)                    REFERENCES rating                               (`rating_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE rating_title                                  ADD CONSTRAINT fk_rating_title_store                                FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE report_event                                  ADD CONSTRAINT fk_report_event_store                                FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE report_event                                  ADD CONSTRAINT fk_report_event_type                                 FOREIGN KEY (`event_type_id`)                REFERENCES report_event_types                   (`event_type_id`)                ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE review                                        ADD CONSTRAINT fk_review_entity                                     FOREIGN KEY (`entity_id`)                    REFERENCES review_entity                        (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE review                                        ADD CONSTRAINT fk_review_parent_product                             FOREIGN KEY (`entity_pk_value`)              REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE review                                        ADD CONSTRAINT fk_review_status                                     FOREIGN KEY (`status_id`)                    REFERENCES review_status                        (`status_id`)                                                             ;
ALTER TABLE review_detail                                 ADD CONSTRAINT fk_review_detail_review                              FOREIGN KEY (`review_id`)                    REFERENCES review                               (`review_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE review_detail                                 ADD CONSTRAINT fk_review_detail_store                               FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  SET NULL  ON UPDATE   CASCADE ;
ALTER TABLE review_entity_summary                         ADD CONSTRAINT fk_review_entity_summary_store                       FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE review_store                                  ADD CONSTRAINT fk_review_store_review                               FOREIGN KEY (`review_id`)                    REFERENCES review                               (`review_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE review_store                                  ADD CONSTRAINT fk_review_store_store                                FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_counter                                 ADD CONSTRAINT fk_sales_counter_store                               FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order                                   ADD CONSTRAINT fk_sale_order_store                                  FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  SET NULL  ON UPDATE   CASCADE ;
ALTER TABLE sales_order                                   ADD CONSTRAINT fk_sale_order_type                                   FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_datetime                          ADD CONSTRAINT fk_sales_order_datetime                              FOREIGN KEY (`entity_id`)                    REFERENCES sales_order                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_datetime                          ADD CONSTRAINT fk_sales_order_datetime_attribute                    FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_datetime                          ADD CONSTRAINT fk_sales_order_datetime_entity_type                  FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_decimal                           ADD CONSTRAINT fk_sales_order_decimal                               FOREIGN KEY (`entity_id`)                    REFERENCES sales_order                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_decimal                           ADD CONSTRAINT fk_sales_order_decimal_attribute                     FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_decimal                           ADD CONSTRAINT fk_sales_order_decimal_entity_type                   FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity                            ADD CONSTRAINT fk_sale_order_entity_store                           FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  SET NULL  ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity                            ADD CONSTRAINT fk_sales_order_entity_type                           FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_datetime                   ADD CONSTRAINT fk_sales_order_entity_datetime                       FOREIGN KEY (`entity_id`)                    REFERENCES sales_order_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_datetime                   ADD CONSTRAINT fk_sales_order_entity_datetime_attribute             FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_datetime                   ADD CONSTRAINT fk_sales_order_entity_datetime_entity_type           FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_decimal                    ADD CONSTRAINT fk_sales_order_entity_decimal                        FOREIGN KEY (`entity_id`)                    REFERENCES sales_order_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_decimal                    ADD CONSTRAINT fk_sales_order_entity_decimal_attribute              FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_decimal                    ADD CONSTRAINT fk_sales_order_entity_decimal_entity_type            FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_int                        ADD CONSTRAINT fk_sales_order_entity_int                            FOREIGN KEY (`entity_id`)                    REFERENCES sales_order_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_int                        ADD CONSTRAINT fk_sales_order_entity_int_attribute                  FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_int                        ADD CONSTRAINT fk_sales_order_entity_int_entity_type                FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_text                       ADD CONSTRAINT fk_sales_order_entity_text                           FOREIGN KEY (`entity_id`)                    REFERENCES sales_order_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_text                       ADD CONSTRAINT fk_sales_order_entity_text_attribute                 FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_text                       ADD CONSTRAINT fk_sales_order_entity_text_entity_type               FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_varchar                    ADD CONSTRAINT fk_sales_order_entity_varchar                        FOREIGN KEY (`entity_id`)                    REFERENCES sales_order_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_varchar                    ADD CONSTRAINT fk_sales_order_entity_varchar_attribute              FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_entity_varchar                    ADD CONSTRAINT fk_sales_order_entity_varchar_entity_type            FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_int                               ADD CONSTRAINT fk_sales_order_int                                   FOREIGN KEY (`entity_id`)                    REFERENCES sales_order                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_int                               ADD CONSTRAINT fk_sales_order_int_attribute                         FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_int                               ADD CONSTRAINT fk_sales_order_int_entity_type                       FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_text                              ADD CONSTRAINT fk_sales_order_text                                  FOREIGN KEY (`entity_id`)                    REFERENCES sales_order                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_text                              ADD CONSTRAINT fk_sales_order_text_attribute                        FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_text                              ADD CONSTRAINT fk_sales_order_text_entity_type                      FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_varchar                           ADD CONSTRAINT fk_sales_order_varchar                               FOREIGN KEY (`entity_id`)                    REFERENCES sales_order                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_varchar                           ADD CONSTRAINT fk_sales_order_varchar_attribute                     FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_order_varchar                           ADD CONSTRAINT fk_sales_order_varchar_entity_type                   FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote                                   ADD CONSTRAINT fk_sales_quote_store                                 FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address                           ADD CONSTRAINT fk_sales_quote_address_quote                         FOREIGN KEY (`parent_id`)                    REFERENCES sales_quote                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_decimal                   ADD CONSTRAINT fk_sales_quote_address_decimal                       FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_address                  (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_decimal                   ADD CONSTRAINT fk_sales_quote_address_decimal_attribute             FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_decimal                   ADD CONSTRAINT fk_sales_quote_address_decimal_entity_type           FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_int                       ADD CONSTRAINT fk_sales_quote_address_int                           FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_address                  (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_int                       ADD CONSTRAINT fk_sales_quote_address_int_attribute                 FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_int                       ADD CONSTRAINT fk_sales_quote_address_int_entity_type               FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_text                      ADD CONSTRAINT fk_sales_quote_address_text                          FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_address                  (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_text                      ADD CONSTRAINT fk_sales_quote_address_text_attribute                FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_text                      ADD CONSTRAINT fk_sales_quote_address_text_entity_type              FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_varchar                   ADD CONSTRAINT fk_sales_quote_address_varchar                       FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_address                  (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_varchar                   ADD CONSTRAINT fk_sales_quote_address_varchar_attribute             FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_address_varchar                   ADD CONSTRAINT fk_sales_quote_address_varchar_entity_type           FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_decimal                           ADD CONSTRAINT fk_sales_quote_decimal                               FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_decimal                           ADD CONSTRAINT fk_sales_quote_decimal_attribute                     FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_decimal                           ADD CONSTRAINT fk_sales_quote_decimal_entity_type                   FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity                            ADD CONSTRAINT fk_sales_quote_entity_store                          FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity                            ADD CONSTRAINT fk_sales_quote_entity_type                           FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_datetime                   ADD CONSTRAINT fk_sales_quote_entity_datetime                       FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_datetime                   ADD CONSTRAINT fk_sales_quote_entity_datetime_attribute             FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_datetime                   ADD CONSTRAINT fk_sales_quote_entity_datetime_entity_type           FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_decimal                    ADD CONSTRAINT fk_sales_quote_entity_decimal                        FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_decimal                    ADD CONSTRAINT fk_sales_quote_entity_decimal_attribute              FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_decimal                    ADD CONSTRAINT fk_sales_quote_entity_decimal_entity_type            FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_int                        ADD CONSTRAINT fk_sales_quote_entity_int                            FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_int                        ADD CONSTRAINT fk_sales_quote_entity_int_attribute                  FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_int                        ADD CONSTRAINT fk_sales_quote_entity_int_entity_type                FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_text                       ADD CONSTRAINT fk_sales_quote_entity_text                           FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_text                       ADD CONSTRAINT fk_sales_quote_entity_text_attribute                 FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_text                       ADD CONSTRAINT fk_sales_quote_entity_text_entity_type               FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_varchar                    ADD CONSTRAINT fk_sales_quote_entity_varchar                        FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_entity                   (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_varchar                    ADD CONSTRAINT fk_sales_quote_entity_varchar_attribute              FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_entity_varchar                    ADD CONSTRAINT fk_sales_quote_entity_varchar_entity_type            FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_int                               ADD CONSTRAINT fk_sales_quote_int                                   FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_int                               ADD CONSTRAINT fk_sales_quote_int_attribute                         FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_int                               ADD CONSTRAINT fk_sales_quote_int_entity_type                       FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item                              ADD CONSTRAINT fk_sales_quote_item_quote                            FOREIGN KEY (`parent_id`)                    REFERENCES sales_quote                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_decimal                      ADD CONSTRAINT fk_sales_quote_item_decimal                          FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_item                     (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_decimal                      ADD CONSTRAINT fk_sales_quote_item_decimal_attribute                FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_decimal                      ADD CONSTRAINT fk_sales_quote_item_decimal_entity_type              FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_int                          ADD CONSTRAINT fk_sales_quote_item_int                              FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_item                     (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_int                          ADD CONSTRAINT fk_sales_quote_item_int_attribute                    FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_int                          ADD CONSTRAINT fk_sales_quote_item_int_entity_type                  FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_text                         ADD CONSTRAINT fk_sales_quote_item_text                             FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_item                     (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_text                         ADD CONSTRAINT fk_sales_quote_item_text_attribute                   FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_text                         ADD CONSTRAINT fk_sales_quote_item_text_entity_type                 FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_varchar                      ADD CONSTRAINT fk_sales_quote_item_varchar                          FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote_item                     (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_varchar                      ADD CONSTRAINT fk_sales_quote_item_varchar_attribute                FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_item_varchar                      ADD CONSTRAINT fk_sales_quote_item_varchar_entity_type              FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_text                              ADD CONSTRAINT fk_sales_quote_text                                  FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_text                              ADD CONSTRAINT fk_sales_quote_text_attribute                        FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_text                              ADD CONSTRAINT fk_sales_quote_text_entity_type                      FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_varchar                           ADD CONSTRAINT fk_sales_quote_varchar                               FOREIGN KEY (`entity_id`)                    REFERENCES sales_quote                          (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_varchar                           ADD CONSTRAINT fk_sales_quote_varchar_attribute                     FOREIGN KEY (`attribute_id`)                 REFERENCES eav_attribute                        (`attribute_id`)                 ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sales_quote_varchar                           ADD CONSTRAINT fk_sales_quote_varchar_entity_type                   FOREIGN KEY (`entity_type_id`)               REFERENCES eav_entity_type                      (`entity_type_id`)               ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE salesrule_customer                            ADD CONSTRAINT fk_salesrule_customer_id                             FOREIGN KEY (`customer_id`)                  REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE salesrule_customer                            ADD CONSTRAINT fk_salesrule_customer_rule                           FOREIGN KEY (`rule_id`)                      REFERENCES salesrule                            (`rule_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE sitemap                                       ADD CONSTRAINT fk_sitemap_store                                     FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE tag_relation                                  ADD CONSTRAINT fk_tag_relation_product                              FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE tag_relation                                  ADD CONSTRAINT tag_relation_ibfk_1                                  FOREIGN KEY (`tag_id`)                       REFERENCES tag                                  (`tag_id`)                       ON DELETE  CASCADE                       ;
ALTER TABLE tag_relation                                  ADD CONSTRAINT tag_relation_ibfk_2                                  FOREIGN KEY (`customer_id`)                  REFERENCES customer_entity                      (`entity_id`)                    ON DELETE  CASCADE                       ;
ALTER TABLE tag_relation                                  ADD CONSTRAINT tag_relation_ibfk_4                                  FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE                       ;
ALTER TABLE tag_summary                                   ADD CONSTRAINT fk_tag_summary_store                                 FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE tag_summary                                   ADD CONSTRAINT tag_summary_tag                                      FOREIGN KEY (`tag_id`)                       REFERENCES tag                                  (`tag_id`)                       ON DELETE  CASCADE                       ;
ALTER TABLE tax_rate_data                                 ADD CONSTRAINT fk_tax_rate_data_tax_rate                            FOREIGN KEY (`tax_rate_id`)                  REFERENCES tax_rate                             (`tax_rate_id`)                  ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE tax_rate_data                                 ADD CONSTRAINT fk_tax_rate_date_tax_rate_type                       FOREIGN KEY (`rate_type_id`)                 REFERENCES tax_rate_type                        (`type_id`)                      ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE tax_rule                                      ADD CONSTRAINT fk_tax_rule_tax_class_customer                       FOREIGN KEY (`tax_customer_class_id`)        REFERENCES tax_class                            (`class_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE tax_rule                                      ADD CONSTRAINT fk_tax_rule_tax_class_product                        FOREIGN KEY (`tax_product_class_id`)         REFERENCES tax_class                            (`class_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE wishlist_item                                 ADD CONSTRAINT fk_item_wishlist                                     FOREIGN KEY (`wishlist_id`)                  REFERENCES wishlist                             (`wishlist_id`)                  ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE wishlist_item                                 ADD CONSTRAINT fk_wishlist_item_store                               FOREIGN KEY (`store_id`)                     REFERENCES core_store                           (`store_id`)                     ON DELETE  CASCADE   ON UPDATE   CASCADE ;
ALTER TABLE wishlist_item                                 ADD CONSTRAINT fk_wishlist_product                                  FOREIGN KEY (`product_id`)                   REFERENCES catalog_product_entity               (`entity_id`)                    ON DELETE  CASCADE   ON UPDATE   CASCADE ;
