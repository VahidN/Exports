﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Test
{
    public partial class Product : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Label1.Text =
                GetProducts.Get()
                    .Where(x => x.Id == int.Parse(Request.QueryString["PID"].ToString()))
                    .Select(x => x.Name)
                    .FirstOrDefault();
        }
    }
}