﻿using System;
using System.Collections.Generic;
using iTextSharp.text;
using iTextSharp.text.pdf;
using PdfReportSamples.Models;
using PdfRpt.Core.Contracts;
using PdfRpt.Core.Helper;

namespace PdfReportSamples.QuestionsForm
{
    public class EntryTemplate : IColumnItemsTemplate
    {
        /// <summary>
        /// This method is called at the end of the cell's rendering.
        /// </summary>
        /// <param name="cell">The current cell</param>
        /// <param name="position">The coordinates of the cell</param>
        /// <param name="attributes">Current cell's custom attributes</param>
        public void CellRendered(PdfPCell cell, Rectangle position, PdfContentByte[] canvases, CellAttributes attributes)
        {
        }

        /// <summary>
        /// 
        /// </summary>
        public CellBasicProperties BasicProperties { set; get; }

        /// <summary>
        /// Defines the current cell's properties, based on the other cells values. 
        /// Here IList contains actual row's cells values.
        /// It can be null.
        /// </summary>
        public Func<IList<CellData>, CellBasicProperties> ConditionalFormatFormula { set; get; }

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        public PdfPCell RenderingCell(CellAttributes attributes)
        {
            var data = attributes.RowData.TableRowData;
            var id = data.GetSafeStringValueOf<Question>(x => x.Id);
            var questionText = data.GetSafeStringValueOf<Question>(x => x.QuestionText);
            var answer1 = data.GetSafeStringValueOf<Question>(x => x.Answer1);
            var answer2 = data.GetSafeStringValueOf<Question>(x => x.Answer2);
            var answer3 = data.GetSafeStringValueOf<Question>(x => x.Answer3);
            var answer4 = data.GetSafeStringValueOf<Question>(x => x.Answer4);
            var picturePath = data.GetSafeStringValueOf<Question>(x => x.PicturePath);

            var font = attributes.BasicProperties.PdfFont;
            var table = new PdfPTable(numColumns: 3)
            {
                RunDirection = PdfWriter.RUN_DIRECTION_LTR,
                WidthPercentage = 100,
                SpacingBefore = 5,
                SpacingAfter = 5
            };

            //---------------- row - 1
            var textCell = new PdfPCell(font.FontSelector.Process(id + ") " + questionText))
            {
                Border = 0,
                PaddingLeft = 5
            };
            textCell.Colspan = 3;
            table.AddCell(textCell);

            //---------------- row - 2
            table.AddCell(new PdfPCell(font.FontSelector.Process("a) " + answer1))
            {
                Border = 0,
                PaddingLeft = 5
            });
            table.AddCell(new PdfPCell(font.FontSelector.Process("b) " + answer2))
            {
                Border = 0,
                PaddingLeft = 5
            });
            var imageCell = new PdfPCell(PdfImageHelper.GetITextSharpImageFromImageFile(picturePath))
            {
                Border = 0,
                HorizontalAlignment = Element.ALIGN_CENTER,
                VerticalAlignment = Element.ALIGN_MIDDLE
            };
            imageCell.Rowspan = 2;
            table.AddCell(imageCell);

            //---------------- row - 3
            table.AddCell(new PdfPCell(font.FontSelector.Process("c) " + answer3))
            {
                Border = 0,
                PaddingLeft = 5
            });
            table.AddCell(new PdfPCell(font.FontSelector.Process("d) " + answer4))
            {
                Border = 0,
                PaddingLeft = 5
            });

            return new PdfPCell(table);
        }
    }
}
