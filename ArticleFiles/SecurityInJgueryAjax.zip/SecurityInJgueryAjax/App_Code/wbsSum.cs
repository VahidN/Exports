﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;

/// <summary>
/// Summary description for wbsSum
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
 [System.Web.Script.Services.ScriptService]
public class wbsSum : System.Web.Services.WebService {

    public wbsSum () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }

    [WebMethod(EnableSession=true)]
    public  string SumTwoNumber(int num1,int num2) {
        Validate();
        var sum = num1 + num2;
        return "Sum = "+sum;  
    }
    private static void Validate()
    {
        HttpContext context = HttpContext.Current;
        if (context != null)
        {
            string headerTicket = context.Request.Headers["SKey"];
            if (string.IsNullOrEmpty(headerTicket))
                throw new System.Security.SecurityException("Security Key must be present.");

            string ServerKey = Convert.ToString(context.Session["SecurityKey"]);

            if (string.Compare(headerTicket, ServerKey, false) != 0)
                throw new System.Security.SecurityException("Security ticket  mismatched.");
        }
        else
            throw new System.Security.SecurityException("Not authorized.");
    }
    
}
