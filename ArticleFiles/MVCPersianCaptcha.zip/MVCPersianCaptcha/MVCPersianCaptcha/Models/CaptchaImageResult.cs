﻿using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Web;
using System.Web.Mvc;

namespace MVCPersianCaptcha.Models
{
    public class CaptchaImageResult : ActionResult
    {
        private int height = 60;
        private int width = 230;
        private Random random = new Random();

        public override void ExecuteResult(ControllerContext context)
        {
            // Create a new 32-bit bitmap image.
            Bitmap bitmap = new Bitmap(width, height, PixelFormat.Format32bppArgb);

            // Create a graphics object for drawing.
            Graphics gfxCaptchaImage = Graphics.FromImage(bitmap);

            gfxCaptchaImage.PageUnit = GraphicsUnit.Pixel;
            gfxCaptchaImage.SmoothingMode = SmoothingMode.HighQuality;
            gfxCaptchaImage.Clear(Color.White);
            
            // Create a Random Number from 1000 to 99999
            int salt = CaptchaHelpers.CreateSalt();
            
            HttpContext.Current.Session["captchastring"] = salt;
            
            string randomString = (salt).NumberToText(Language.Persian);

            // Set up the text format.
            var format = new StringFormat();
            int faLCID = new System.Globalization.CultureInfo("fa-IR").LCID;
            format.SetDigitSubstitution(faLCID, StringDigitSubstitute.National);
            format.Alignment = StringAlignment.Near;
            format.LineAlignment = StringAlignment.Near;
            format.FormatFlags = StringFormatFlags.DirectionRightToLeft;

            // Font of Captcha and its size
            Font font = new Font("Tahoma", 10);

            // Create a path using the text and warp it randomly.
            GraphicsPath path = new GraphicsPath();

            path.AddString(randomString,
                font.FontFamily,
                (int)font.Style,
                (gfxCaptchaImage.DpiY * font.SizeInPoints / 72),
                new Rectangle(0, 0, width, height),
                format);

            gfxCaptchaImage.DrawPath(Pens.Navy, path);

            //-- using a sin ware distort the image
            int distortion = random.Next(-10, 10);
            using (Bitmap copy = (Bitmap)bitmap.Clone())
            {
                for (int y = 0; y < height; y++)
                {
                    for (int x = 0; x < width; x++)
                    {
                        int newX = (int)(x + (distortion * Math.Sin(Math.PI * y / 64.0)));
                        int newY = (int)(y + (distortion * Math.Cos(Math.PI * x / 64.0)));
                        if (newX < 0 || newX >= width) newX = 0;
                        if (newY < 0 || newY >= height) newY = 0;
                        bitmap.SetPixel(x, y, copy.GetPixel(newX, newY));
                    }
                }
            }

            //-- Draw the graphic to the bitmap
            gfxCaptchaImage.DrawImage(bitmap, new Point(0, 0));
            gfxCaptchaImage.Flush();

            HttpResponseBase response = context.HttpContext.Response;
            response.ContentType = "image/jpeg";
            bitmap.Save(response.OutputStream, ImageFormat.Jpeg);

            // Clean up.
            font.Dispose();
            gfxCaptchaImage.Dispose();
            bitmap.Dispose();
        }
    }
}