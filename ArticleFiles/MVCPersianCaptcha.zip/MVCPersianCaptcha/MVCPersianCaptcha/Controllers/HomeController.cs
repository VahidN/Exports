﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVCPersianCaptcha.Models;

namespace MVCPersianCaptcha.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(LogOnModel model)
        {
            if (!ModelState.IsValid) return View(model);

            if (model.CaptchaInputText == Session["captchastring"].ToString()) TempData["message"] = "تصویر امنتی را صحیح وارد کرده اید";
            else TempData["message"] = "تصویر امنیتی را اشتباه وارد کرده اید";

            return View();
        }

        public CaptchaImageResult CaptchaImage()
        {
            return new CaptchaImageResult();
        }
    }

    
}
