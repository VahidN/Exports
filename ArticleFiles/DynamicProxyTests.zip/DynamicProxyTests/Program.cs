﻿using System;
using System.Reflection;
using EntityFramework.Reflection;

namespace DynamicProxyTests
{
    public class NestedClass
    {
        private int _field2;
        public NestedClass()
        {
            _field2 = 12;
        }
    }

    public class MyClass
    {
        private int _field1;
        private NestedClass _nestedClass;

        public MyClass()
        {
            _field1 = 1;
            _nestedClass = new NestedClass();
        }

        private string GetData()
        {
            return "Test";
        }
    }

    class Program
    {
        static void Main(string[] args)
        {

            var myClass = new MyClass();

            var field1Obj = myClass.GetType().GetField("_field1", BindingFlags.NonPublic | BindingFlags.Instance);
            if (field1Obj != null)
            {
                Console.WriteLine(Convert.ToInt32(field1Obj.GetValue(myClass)));
            }

            var getDataMethod = myClass.GetType().GetMethod("GetData", BindingFlags.NonPublic | BindingFlags.Instance);
            if (getDataMethod != null)
            {
                Console.WriteLine(getDataMethod.Invoke(myClass, null));
            }

            var nestedClassObj = myClass.GetType().GetField("_nestedClass", BindingFlags.NonPublic | BindingFlags.Instance);
            if (nestedClassObj != null)
            {
                var nestedClassFieldValue = nestedClassObj.GetValue(myClass);
                var field2Obj = nestedClassFieldValue.GetType()
                    .GetField("_field2", BindingFlags.NonPublic | BindingFlags.Instance);
                if (field2Obj != null)
                {
                    Console.WriteLine(Convert.ToInt32(field2Obj.GetValue(nestedClassFieldValue)));
                }
            }


            // Accessing a private field
            dynamic myClassProxy = new DynamicProxy(myClass);
            dynamic field1 = myClassProxy._field1;
            Console.WriteLine((int)field1);

            // Accessing a nested private field
            dynamic field2 = myClassProxy._nestedClass._field2;
            Console.WriteLine((int)field2);

            // Accessing a private method
            dynamic data = myClassProxy.GetData();
            Console.WriteLine((string)data);

        }
    }
}