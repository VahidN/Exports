﻿namespace jqGrid12.Models
{
    public class OrderDetail
    {
        public int Id { set; get; }
        public string Product { set; get; }
        public int Unit { set; get; }
        public int Price { set; get; }
    }
}