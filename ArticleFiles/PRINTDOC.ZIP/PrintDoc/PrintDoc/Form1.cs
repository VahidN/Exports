﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace PrintDoc
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            try
            {
                object varFileName = @"d:\test.doc";
                object varFalseValue = false;
                object varTrueValue = true;
                object varMissing = Type.Missing;
                Microsoft.Office.Interop.Word.Application varWord = new
                Microsoft.Office.Interop.Word.Application();

                varWord.ActivePrinter = "Microsoft Office Document Image Writer";
                //                varWord.ActivePrinter = "Snagit 11";
                //                varWord.ActivePrinter = "priPrinter";
                //                varWord.ActivePrinter = "doPDF v7";

                Microsoft.Office.Interop.Word.Document varDoc =
                varWord.Documents.Open(ref varFileName, ref varMissing, ref varFalseValue,ref varMissing,
                                       ref varMissing, ref varMissing, ref varMissing, ref varMissing, 
                                       ref varMissing, ref varMissing, ref varMissing, ref varMissing,
                                       ref varMissing, ref varMissing, ref varMissing, ref varMissing);
                varDoc.Activate();

                object PrintToFile = true;
                object OutputFileName = @"d:\test.tif";
                varDoc.PrintOut(ref varMissing, ref varFalseValue, ref varMissing,
                                ref OutputFileName, ref varMissing, ref varMissing, ref varMissing,
                                ref varMissing, ref varMissing, ref varMissing, ref PrintToFile,
                                ref varMissing, ref varMissing, ref varMissing, ref varMissing, 
                                ref varMissing, ref varMissing, ref varMissing);

                varDoc.Close(ref varMissing, ref varMissing, ref varMissing);
                varWord.Quit(ref varMissing, ref varMissing, ref varMissing);
            }
            catch (Exception varE)
            {
                MessageBox.Show("Error:\n" + varE.Message, "Error message");
            }
        }
    }
}
