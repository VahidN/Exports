using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace BackloadProject.Controllers
{
    public class BackloadDemoController : Controller
    {
        //
        // GET: /BackupDemo/
        public ActionResult Index()
        {
            return View();
        }
    }
}
