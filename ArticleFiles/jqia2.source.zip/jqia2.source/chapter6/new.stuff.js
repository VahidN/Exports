alert("I'm inline!");

var someVariable = 'Value of someVariable';

function someFunction(value) {
  alert(value);
};
