﻿using System.Web.Mvc;
using MVCPersianCaptcha.Models;

namespace MVCPersianCaptcha.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost, ValidateCaptchaAttribute, ValidateAntiForgeryToken]
        public ActionResult Index(LogOnModel model)
        {
            if (!ModelState.IsValid) return View(model);

            TempData["message"] = "کد امنیتی را به درستی وارد کرده اید";

            return View(new LogOnModel{UserName = "", CaptchaInputText = ""});
        }

        public CaptchaImageResult CaptchaImage()
        {
            return new CaptchaImageResult();
        }
    }
}
