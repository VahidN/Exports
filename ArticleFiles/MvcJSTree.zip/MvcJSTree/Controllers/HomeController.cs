﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Web.Mvc;
using MvcJSTree.Models;

namespace MvcJSTree.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }


        [HttpPost]
        public ActionResult DoJsTreeOperation(JsTreeOperationData data)
        {
            switch (data.Operation)
            {
                case JsTreeOperation.CopyNode:
                case JsTreeOperation.CreateNode:
                    //todo: save data
                    var rnd = new Random(); // آي دي ركورد پس از ثبت در بانك اطلاعاتي دريافت و بازگشت داده شود
                    return Json(new { id = rnd.Next() }, JsonRequestBehavior.AllowGet);

                case JsTreeOperation.DeleteNode:
                    //todo: save data
                    return Json(new { result = "ok" }, JsonRequestBehavior.AllowGet);

                case JsTreeOperation.MoveNode:
                    //todo: save data
                    return Json(new { result = "ok" }, JsonRequestBehavior.AllowGet);

                case JsTreeOperation.RenameNode:
                    //todo: save data
                    return Json(new { result = "ok" }, JsonRequestBehavior.AllowGet);

                default:
                    throw new InvalidOperationException(string.Format("{0} is not supported.", data.Operation));
            }
        }

        [HttpPost]
        public ActionResult GetTreeJson()
        {
            var dir = Server.MapPath("~/");

            var nodesList = new List<JsTreeNode>();

            var rootNode = new JsTreeNode
            {
                id = dir,
                text = "Root 1",
                icon = Url.Content("~/Content/images/tree_icon.png"),
                a_attr = { href = "http://www.bing.com" }
            };
            PopulateTree(dir, rootNode);
            nodesList.Add(rootNode);

            nodesList.Add(new JsTreeNode
            {
                id = "test1",
                text = "Root 2",
                icon = Url.Content("~/Content/images/tree_icon.png"),
                a_attr = { href = "http://www.bing.com" }
            });

            return Json(nodesList, JsonRequestBehavior.AllowGet);
        }

        public void PopulateTree(string dir, JsTreeNode node)
        {
            var directory = new DirectoryInfo(dir);
            foreach (var directoryInfo in directory.GetDirectories())
            {
                var treeNode = new JsTreeNode
                {
                    id = directoryInfo.FullName,
                    text = directoryInfo.Name,
                    icon = Url.Content("~/Content/images/nuclear.png"),
                    a_attr = { href = "http://www.bing.com" }
                };
                PopulateTree(directoryInfo.FullName, treeNode);
                node.children.Add(treeNode);
            }

            foreach (var fileInfo in directory.GetFiles("*.*"))
            {
                node.children.Add(new JsTreeNode
                {
                    id = fileInfo.FullName,
                    text = fileInfo.Name,
                    icon = Url.Content("~/Content/images/bookmark_book_open.png"),
                    a_attr = { href = "http://www.bing.com" }
                });
            }
        }
    }
}