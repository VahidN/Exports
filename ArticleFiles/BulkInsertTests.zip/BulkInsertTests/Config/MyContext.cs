using System;
using System.Data.Entity;
using BulkInsertTests.Models;

namespace BulkInsertTests.Config
{
    public class MyContext : DbContext
    {
        public DbSet<Category> Categories { get; set; }


        public MyContext()
            : base("Connection1")
        {
            this.Database.Log = sql => Console.Write(sql);
        }
    }
}