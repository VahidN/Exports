﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using BulkInsertTests.Config;
using BulkInsertTests.Models;
using EntityFramework.BulkInsert.Extensions;

namespace BulkInsertTests
{
    class Program
    {
        static void Main(string[] args)
        {
            startDb();

            using (var context = new MyContext())
            {
                var catlist = new List<Category>();
                for (var i = 0; i < 1000; i++)
                {
                    var cat = new Category { CategoryName = "cat" + i };
                    catlist.Add(cat);
                }
                context.BulkInsert(catlist);
                context.SaveChanges();
            }

            Console.WriteLine("Press a key ...");
            Console.Read();
        }

        private static void startDb()
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<MyContext, Configuration>());
            using (var context = new MyContext())
            {
                context.Database.Initialize(force: true);
            }
        }
    }
}
