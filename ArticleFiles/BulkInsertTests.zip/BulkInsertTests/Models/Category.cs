﻿namespace BulkInsertTests.Models
{
    public class Category
    {
        public int CategoryID { set; get; }
        public string CategoryName { set; get; }
    }
}