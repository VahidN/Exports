﻿using System.Collections.Generic;

namespace EmberJS02.Models
{
    /// <summary>
    /// منبع داده فرضی جهت سهولت دموی برنامه
    /// </summary>
    public static class UsersDataSource
    {
        private static readonly IList<User> _cachedItems;
        static UsersDataSource()
        {
            _cachedItems = createRegistrationsDataSource();
        }

        public static IList<User> UsersList
        {
            get { return _cachedItems; }
        }

        /// <summary>
        /// هدف صرفا تهیه یک منبع داده آزمایشی ساده تشکیل شده در حافظه است
        /// </summary>
        private static IList<User> createRegistrationsDataSource()
        {
            return new List<User>
            {
                new User
                {
                    Id = 1,
                    Email = "tst1@site.com",
                    UserName = "UserX"
                },
                new User
                {
                    Id = 2,
                    Email = "tst2@site.com",
                    UserName = "UserY"
                },
                new User
                {
                    Id = 3,
                    Email = "tst3@site.com",
                    UserName = "UserZ"
                },
            };
        }
    }
}