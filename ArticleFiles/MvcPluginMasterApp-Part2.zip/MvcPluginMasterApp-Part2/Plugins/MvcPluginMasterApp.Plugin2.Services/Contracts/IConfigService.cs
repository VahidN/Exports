﻿namespace MvcPluginMasterApp.Plugin2.Services.Contracts
{
    public interface IConfigService
    {
        string Key2 { get; }
    }
}