﻿namespace MvcPluginMasterApp.Plugin1.Services.Contracts
{
    public interface IConfigService
    {
        string Key1 { get; }
    }
}