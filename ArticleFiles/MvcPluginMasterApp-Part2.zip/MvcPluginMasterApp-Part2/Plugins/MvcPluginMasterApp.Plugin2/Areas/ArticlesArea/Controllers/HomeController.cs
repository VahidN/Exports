﻿using System.Web.Mvc;
using MvcPluginMasterApp.Plugin2.Services.Contracts;

namespace MvcPluginMasterApp.Plugin2.Areas.ArticlesArea.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfigService _configService;

        public HomeController(IConfigService configService)
        {
            _configService = configService;
        }

        public ActionResult Index()
        {
            ViewBag.Message = string.Format("From Plugin2: {0}", _configService.Key2);
            return View();
        }
    }
}