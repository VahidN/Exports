﻿using System.Web.Mvc;
using MvcPluginMasterApp.Plugin1.Services.Contracts;

namespace MvcPluginMasterApp.Plugin1.Areas.NewsArea.Controllers
{
    public class HomeController : Controller
    {
        private readonly IConfigService _configService;

        public HomeController(IConfigService configService)
        {
            _configService = configService;
        }

        public ActionResult Index()
        {
            ViewBag.Message = "From Plugin1: " + _configService.Key1;
            return View();
        }
    }
}