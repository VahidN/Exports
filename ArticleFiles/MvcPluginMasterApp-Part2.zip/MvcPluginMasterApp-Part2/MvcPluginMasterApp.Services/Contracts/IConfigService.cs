﻿namespace MvcPluginMasterApp.Services.Contracts
{
    public interface IConfigService
    {
        string MasterKey { get; }
    }
}