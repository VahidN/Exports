MvcPlugin
=======
* How to create plugins for ASP.NET MVC 4.x/5.x applications.
* How to move areas to another assemblies.
* How to use embedded views.
* How to read CSS and JS files from embedded resources.
* How to read images from embedded resources.
* How to apply dependency injection in different modules.
* How to use Entity framework and discover entities and their configurations dynamically.