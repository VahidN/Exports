﻿
namespace CrMap
{
    public partial class App
    {
    }
}