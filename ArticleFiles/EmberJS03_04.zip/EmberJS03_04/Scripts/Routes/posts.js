﻿Blogger.PostsRoute = Ember.Route.extend({
    //controllerName: 'posts', // مقدار پيش فرض است و نيازي به ذكر آن نيست
    //renderTemplare: function () {
    //    this.render('posts'); // مقدار پيش فرض است و نيازي به ذكر آن نيست
    //},
    model: function () {
        return this.store.find('post');
    }
});