﻿Blogger.PostsController = Ember.ArrayController.extend({
    sortProperties: ['id'],// مقادير پيش فرض مرتب سازي
    sortAscending: false,
    actions: {
        sortByTitle: function () {
            this.set('sortProperties', ['title']);
            this.set('sortAscending', !this.get('sortAscending'));
        }
    }
});
