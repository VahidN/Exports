Blogger.AboutController = Ember.Controller.extend({
    isAuthorShowing: false,
    actions: {
        showRealName: function () {
            alert("You clicked at showRealName of AboutController.");
        },
        showAuthor: function () {
            this.set('isAuthorShowing', true);
        },
        hideAuthor: function () {
            this.set('isAuthorShowing', false);
        }
    }
});
