Blogger.CommentController = Ember.ObjectController.extend({
    needs: ['post'],
    actions: {
        delete: function () {
            if (confirm('Do you want to delete this comment?')) {
                var comment = this.get('model');
                comment.deleteRecord();
                comment.save();

                var post = this.get('controllers.post.model');
                post.get('comments').removeObject(comment);
                post.save();
            }
        }
    }
});
