﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.ServiceModel;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ScannerServiceHost
{
    public partial class MainForm : Form
    {
        private readonly Uri _baseAddress = new Uri("http://localhost:13748");
        private ServiceHost _host;
        public MainForm()
        {
            InitializeComponent();
        }

        private void MainForm_Load(object sender, EventArgs e)
        {
            _host = new ServiceHost(typeof(WcfServiceScanner.ScannerService), _baseAddress);
            _host.Open();
        }

        private void MainForm_FormClosing(object sender, FormClosingEventArgs e)
        {
            _host.Close();
        }
    }
}
