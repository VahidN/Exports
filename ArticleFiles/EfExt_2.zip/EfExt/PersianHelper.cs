﻿
namespace EfExt
{
    public static class PersianHelper
    {
        public static string ApplyUnifiedYeKe(this string data)
        {
            if (string.IsNullOrEmpty(data)) return data;
            return data.Replace("ی", "ي").Replace("ک", "ك");
        }
    }
}
