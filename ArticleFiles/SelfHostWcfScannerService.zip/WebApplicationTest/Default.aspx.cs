﻿using System;
using System.Web.UI;

namespace WebApplicationTest
{
    public partial class Default : Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }
    }
}