﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Web;

namespace MiniDumpTest.Core
{
    public static class DebugInfo
    {
        public static void CreateMiniDump(
            string dumpFileName, MiniDumpType dumpType = MiniDumpType.MiniDumpNormal)
        {
            using (var stream = File.Create(dumpFileName))
            {
                var process = Process.GetCurrentProcess();
                // It is safe to call DangerousGetHandle() here because the process is already crashing.
                NativeMethods.MiniDumpWriteDump(
                                process.Handle,
                                process.Id,
                                stream.SafeFileHandle.DangerousGetHandle(),
                                dumpType,
                                IntPtr.Zero,
                                IntPtr.Zero,
                                IntPtr.Zero);
            }
        }

        public static void CreateMiniDump(MiniDumpType dumpType = MiniDumpType.MiniDumpNormal)
        {
            const string dateFormat = "yyyy-MM-dd-HH-mm-ss-fffZ"; // Example: 2010-09-02-09-50-43-341Z
            var thisAssembly = Assembly.GetEntryAssembly() ?? Assembly.GetCallingAssembly();
            var dumpFileName = string.Format(@"{0}-MiniDump-{1}.dmp",
                        thisAssembly.GetName().Name,
                        DateTime.UtcNow.ToString(dateFormat, CultureInfo.InvariantCulture));

            var path = Path.Combine(getApplicationPath(), dumpFileName);
            CreateMiniDump(path, dumpType);
        }

        private static string getApplicationPath()
        {
            return HttpContext.Current != null ?
                HttpRuntime.AppDomainAppPath :
                Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
        }
    }
}