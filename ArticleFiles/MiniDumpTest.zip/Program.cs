﻿using System;
using MiniDumpTest.Core;

namespace MiniDumpTest
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                var zero = 0;
                Console.WriteLine(1 / zero);
            }
            catch (Exception ex)
            {
                Console.Write(ex);
                DebugInfo.CreateMiniDump(dumpType:
                                    MiniDumpType.MiniDumpNormal |
                                    MiniDumpType.MiniDumpWithPrivateReadWriteMemory |
                                    MiniDumpType.MiniDumpWithDataSegs |
                                    MiniDumpType.MiniDumpWithHandleData |
                                    MiniDumpType.MiniDumpWithFullMemoryInfo |
                                    MiniDumpType.MiniDumpWithThreadInfo |
                                    MiniDumpType.MiniDumpWithUnloadedModules);

                throw;
            }
        }
    }
}