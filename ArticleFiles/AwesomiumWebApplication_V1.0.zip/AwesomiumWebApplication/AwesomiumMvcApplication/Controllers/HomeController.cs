using System;
using System.IO;
using System.Web;
using System.Web.Mvc;
using AwesomiumWebModule;

namespace AwesomiumMvcApplication.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public ActionResult Index(string url)
        {
            if (string.IsNullOrWhiteSpace(url))
                return RedirectToAction("Index");

            var host = new Uri(url).Host;
            this.HttpContext.Items.Add(Constants.AwesomiumRequest, new AwesomiumRequest
            {
                Url = url,
                SavePath = Path.Combine(HttpRuntime.AppDomainAppPath, "App_Data\\Thumbnails\\" + host + ".jpg"),
                TempDir = Path.Combine(HttpRuntime.AppDomainAppPath, "App_Data\\Temp")
            });

            ViewBag.Info = "Please wait. Your request will be served shortly.";
            return View();
        }
    }
}