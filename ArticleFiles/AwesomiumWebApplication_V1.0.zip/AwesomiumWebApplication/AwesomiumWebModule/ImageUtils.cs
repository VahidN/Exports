﻿using System.Drawing;
using System.Drawing.Drawing2D;
using System.Drawing.Imaging;
using System.IO;
using System.Linq;

namespace AwesomiumWebModule
{
    internal static class ImageUtils
    {
        public static byte[] GetWhiteBitmap()
        {
            var bitmap = new Bitmap(1, 1);
            bitmap.SetPixel(0, 0, Color.White);
            return Resize(bitmap);
        }

        private static ImageCodecInfo getEncoderInfo(string mimeType)
        {
            // Get image codecs for all image formats
            var codecs = ImageCodecInfo.GetImageEncoders();

            // Find the correct image codec
            return codecs.FirstOrDefault(t => t.MimeType == mimeType);
        }

        public static byte[] Resize(Image img, int thumbWidth = 400, int thumbHeight = 250, int quality = 90)
        {
            int srcWidth = img.Width;
            int srcHeight = img.Height;
            using (var bmp = new Bitmap(thumbWidth, thumbHeight))
            {
                using (var gr = Graphics.FromImage(bmp))
                {
                    gr.SmoothingMode = SmoothingMode.HighQuality;
                    gr.CompositingQuality = CompositingQuality.HighQuality;
                    gr.InterpolationMode = InterpolationMode.High;

                    var rectDestination = new Rectangle(0, 0, thumbWidth, thumbHeight);
                    gr.DrawImage(img, rectDestination, 0, 0, srcWidth, srcHeight, GraphicsUnit.Pixel);

                    using (var qualityParam = new EncoderParameter(Encoder.Quality, quality))
                    {
                        using (var encoderParams = new EncoderParameters(1))
                        {
                            encoderParams.Param[0] = qualityParam;

                            var jpegCodec = getEncoderInfo("image/jpeg");
                            if (jpegCodec == null) return null;

                            using (var memStream = new MemoryStream())
                            {
                                bmp.Save(memStream, jpegCodec, encoderParams);
                                return memStream.ToArray();
                            }
                        }
                    }
                }
            }
        }
    }
}