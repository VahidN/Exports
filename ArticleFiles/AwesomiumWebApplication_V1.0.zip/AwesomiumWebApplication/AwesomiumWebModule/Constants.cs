﻿
namespace AwesomiumWebModule
{
    public class Constants
    {
        public const string AwesomiumRequest = "AwesomiumRequest";
    }
}