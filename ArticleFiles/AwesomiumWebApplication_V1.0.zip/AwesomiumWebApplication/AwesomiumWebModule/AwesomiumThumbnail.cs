﻿using System;
using System.Drawing;
using System.Drawing.Imaging;
using System.Runtime.ExceptionServices;
using System.Threading;
using Awesomium.Core;

namespace AwesomiumWebModule
{
    internal static class AwesomiumThumbnail
    {
        const string ScrollbarCss = "::-webkit-scrollbar { visibility: hidden; }";

        static AwesomiumThumbnail()
        {
            var webConfig = WebConfig.Default;
            webConfig.UserAgent = "Awesomium 1.7.x";
            WebCore.Initialize(webConfig);
            WebCore.ShuttingDown += webCoreShuttingDown;
        }

        private static void webCoreShuttingDown(object sender, CoreShutdownEventArgs e)
        {
            e.Cancel = true;
            //todo: log e.Exception ...
        }

        [HandleProcessCorruptedStateExceptions]
        public static byte[] FetchWebPageThumbnail(AwesomiumRequest awesomiumRequest)
        {
            try
            {
                var webPreferences = WebPreferences.Default;
                webPreferences.CustomCSS = ScrollbarCss;
                using (var session = WebCore.CreateWebSession(awesomiumRequest.TempDir, webPreferences))
                {
                    using (var view = WebCore.CreateWebView(awesomiumRequest.ScreenWidth, awesomiumRequest.ScreenHeight, session))
                    {
                        view.CertificateError += viewCertificateError;
                        view.Source = new Uri(awesomiumRequest.Url);

                        bool finishedLoading = false;
                        view.LoadingFrameComplete += (s, e) =>
                        {
                            if (e.IsMainFrame)
                                finishedLoading = true;
                        };

                        int timeSpent = 0;
                        while (!finishedLoading)
                        {
                            Thread.Sleep(50);
                            WebCore.Update();

                            timeSpent += 50;
                            if (timeSpent > awesomiumRequest.MillisecondsTimeout)
                            {
                                //todo: log ...
                                return ImageUtils.GetWhiteBitmap();
                            }
                        }

                        using (var surface = (BitmapSurface)view.Surface)
                        {
                            var bitmap = surfaceToBitmap(view, surface);
                            return ImageUtils.Resize(bitmap, awesomiumRequest.ThumbWidth, awesomiumRequest.ThumbHeight, awesomiumRequest.Quality);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //todo: log ...
                return ImageUtils.GetWhiteBitmap();
            }
        }

        private static void viewCertificateError(object sender, CertificateErrorEventArgs e)
        {
            e.Ignore = true;
        }       

        private static Bitmap surfaceToBitmap(WebView view, BitmapSurface surface)
        {
            var bitmap = new Bitmap(view.Width, view.Height, PixelFormat.Format32bppArgb);
            var bitmapData = bitmap.LockBits(
                        new Rectangle(0, 0, view.Width, view.Height),
                        ImageLockMode.ReadWrite,
                        bitmap.PixelFormat);
            surface.CopyTo(bitmapData.Scan0, bitmapData.Stride, 4, false, false);
            bitmap.UnlockBits(bitmapData);
            return bitmap;
        }
    }
}