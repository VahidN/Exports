﻿
namespace AwesomiumWebModule
{
    public class AwesomiumRequest
    {
        /// <summary>
        /// Site's URL
        /// </summary>
        public string Url { set; get; }

        /// <summary>
        /// Full path and name of the final .jpg image file.
        /// </summary>
        public string SavePath { set; get; }

        /// <summary>
        /// Full path of the Awesomium's TempDir.
        /// </summary>
        public string TempDir { set; get; }

        /// <summary>
        /// Its default value is 1240.
        /// </summary>
        public int ScreenWidth { set; get; }

        /// <summary>
        /// Its default value is 1000.
        /// </summary>
        public int ScreenHeight { set; get; }

        /// <summary>
        /// Its default value is 400.
        /// </summary>
        public int ThumbWidth { set; get; }

        /// <summary>
        /// Its default value is 400.
        /// </summary>
        public int ThumbHeight { set; get; }

        /// <summary>
        /// Its default value is 95.
        /// </summary>
        public int Quality { set; get; }

        /// <summary>
        /// Its default value is 50000.
        /// </summary>
        public int MillisecondsTimeout { set; get; }

        public AwesomiumRequest()
        {
            ScreenWidth = 1240;
            ScreenHeight = 1000;
            ThumbWidth = 400;
            ThumbHeight = 400;
            Quality = 95;
            MillisecondsTimeout = 50000;
        }
    }
}