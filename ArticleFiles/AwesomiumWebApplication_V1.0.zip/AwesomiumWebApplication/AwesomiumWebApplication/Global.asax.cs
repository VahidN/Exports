﻿using System.Web;

namespace AwesomiumWebApplication
{
    public class Global : HttpApplication
    {
    }
}