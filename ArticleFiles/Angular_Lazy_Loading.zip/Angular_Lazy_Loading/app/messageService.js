﻿(function () {
    'use strict';

    // Controller name is handy for logging
    var serviceId = 'messageService';

    // Define the controller on the module.
    // Inject the dependencies. 
    // Point to the controller definition function.
    angular.module('app').lazy.service(serviceId,
        ['$http', messageService]);

    function messageService($http) {

        this.getState1Message = function () {
            return 'پیام حالت شماره 1';
        };

        this.getState2Message = function () {
            return 'پیام حالت شماره 2';
        };
    }
})();