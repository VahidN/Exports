﻿/// <reference path="jquery-1.7.1.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="jquery.validate.js" />


////Actual JS method having validation code.
//jQuery.validator.addMethod("agerange",
//    function (value, element, params) {
//    debugger;
//    props = params.split(',');
//    if ($(props[1]).val() == "Male" && (parseInt($(props[0]).val()) > 40 || parseInt($(props[0]).val()) < 18))
//        return false;
//    else
//        return true;
//});
////Validation rule, need to specify parameters, error message to JS method.
//jQuery.validator.unobtrusive.adapters.add("agerange", ["agerangefield"], function (options) {
//    options.rules["agerange"] = options.params.agerangefield;
//    options.messages["agerange"] = options.message;
//});




jQuery.validator.addMethod("checkage",
function (value, element, param) {
    debugger;
    var currDate = param;
    var sdoc = currDate.split('/');
    var dobDate = value;
    var sdob = dobDate.split('/');
    //pass year,month,date in new Date object.
    var vDOB = new Date(sdob[2], sdob[1], sdob[0]);
    var vDOC = new Date(sdoc[2], sdoc[1], sdoc[0]);
    //getAge user define function to calculate age.
    var vYrs = getAge(vDOB, vDOC);
    var result = false;
    if (vYrs >= 18 && vYrs <= 30) { result = true; }
    debugger;
    return result;
});

jQuery.validator.unobtrusive.adapters.add("checkage", ["param"], function (options) {

    options.rules["checkage"] = options.params.param;
    options.messages["checkage"] = options.message;
});

function getAge(oldDate, currDate) {
    return currDate.getFullYear() - oldDate.getFullYear();
}