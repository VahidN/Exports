﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MvcApplication1.Models;

namespace MvcApplication1.Controllers
{
    public class CustomerController : Controller
    {
        //
        // GET: /Customer/
        public ActionResult Index()
        {
            Customer v = new Customer{DateOfBirth = new DateTime(2001,10,10) };
            return View(v);
        }
        [AcceptVerbs(HttpVerbs.Post)]
        public ActionResult Index(Customer newPerson)
        {
            if (ModelState.IsValid)
            {
            }
            return View();
        }
        

    }
}
