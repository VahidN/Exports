﻿using System;
using System.ComponentModel.DataAnnotations;

namespace MvcAppPersianDatePicker.Models
{
    public class Post
    {
        public string Title { set; get; }

        // Location: Views\Shared\EditorTemplates\PersianDatePicker.cshtml
        [UIHint("PersianDatePicker")]
        public DateTime AddDate { set; get; }
    }
}