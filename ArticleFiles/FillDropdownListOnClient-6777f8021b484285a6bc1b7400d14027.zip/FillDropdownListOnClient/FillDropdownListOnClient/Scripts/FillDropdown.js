﻿
var Enum_PersistType = null;

$(document).ready(
 function () {
     SetEnumTypes();
     FillDropdown();
 });


function SetEnumTypes() {
    Enum_PersistType = JSON.parse($('#hfJsonEnum_PersistType').val());
}

function GetPersistTypeTitle_Concept(enumId) {
    return Enum_PersistType[enumId];
}

function FillDropdown() {
    $("#ddlPersistType").html("");
    $.each(Enum_PersistType, function (key, value) {
        $("#ddlPersistType").append($("<option></option>").val(key).html(value));
    });
}
