﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace FillDropdownListOnClient.Classes
{
    public enum PersistType
    {
        Persistable = 1,
        NotPersist = 2,
        AlwaysPersist = 3
    }
}