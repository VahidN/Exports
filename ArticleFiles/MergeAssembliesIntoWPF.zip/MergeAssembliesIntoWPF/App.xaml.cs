﻿
namespace MergeAssembliesIntoWPF
{
    public partial class App
    {
    }
}