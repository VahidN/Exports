﻿
namespace MergeAssembliesIntoWPF.Shell
{
    public partial class View1
    {
        public View1()
        {
            InitializeComponent();
        }
    }
}