﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace WindowsFormsTests
{
    public class Test
    {
        public int Id { get; set; }
        public DateTime? ResponseDate { get; set; }
    }

    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            var list = new List<Test>();
            list.Add(new Test
            {
                Id = 0,
                ResponseDate = new DateTime(2010,1,1)
            });
            for (int i = 1; i <= 100; i++)
            {
                list.Add(new Test
                {
                    Id = i,
                    ResponseDate = DateTime.Now.AddDays(i)
                });
            }

            dataGridView1.DataSource = (list.Select(t => new
            {
                Id = t.Id,
                time = t.ResponseDate==null? "" : new PersianDateTime(t.ResponseDate.Value).ToString(PersianDateTimeFormat.DateShortTime)
            })).ToList(); 
        }
    }
}