﻿using System;
using System.Runtime.InteropServices;
using System.Windows;

namespace WpfApplicationC0000005
{
    public partial class MainWindow
    {
        private unsafe void AccessViolation()
        {
            IntPtr ptr = new IntPtr(123);
            Marshal.StructureToPtr(123, ptr, true);
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            AccessViolation();
        }
    }
}