﻿(function ($) {
    $.widget("bm.searchboxmvc", {
        options: {
            display: null,
            listItemsDisplay: null,
            loadDataOnLeave: false,
            defaultStringFilterMode: "startWith",
            loadUrl: "",
            fields: [],
            ajaxSettings: {
                type: 'POST',
                dataType: 'json'
            },
            displayClass: "",
            displayNoResultClass: ""
        },

        //private fields
        _mainDiv: null,
        _searchInput: null,
        _searchDisplayDiv: null,
        _configDiv: null,
        _configButton: null,
        _configUl: null,
        _stringSearchModeUl: null,

        _dropDownButton: null,
        _dropDownUl: null,
        _dropDownDiv: null,

        _defaultValueField: null,
        _defaultDisplayField: null,
        _defaultStringFilterMode: "startWith",


        //--constructors
        _create: function () {
            this._createMainDiv();
            this._setDefaultValueField();
            this._setDefaultDisplayField();
            this._applyOptions();
        },

        _createMainDiv: function () {
            this._mainDiv = $("<div />")
                .addClass("form-inline")
                .appendTo(this.element);

            this._createSearchInput();
            this._createDropDownDiv();
            this._createSearchDisplay();
            this._createConfigDiv();

            $(this._mainDiv).children().css("margin", "1px");
        },
        _createSearchInput: function () {
            var self = this;
            this._searchInput = $("<input type='text'/>")
                .addClass("span2")
                .appendTo(this._mainDiv);
            if (this.options.loadDataOnLeave) {
                this._searchInput.change(function (e) {
                    self._startLoad();
                });
            }
            else {
                this._searchInput.on("input", function (e) {
                    self._startLoad();
                });
            }
        },
        _createDropDownDiv: function () {
            this._dropDownDiv = $("<div />")
                .addClass("dropdown")
                .css("display", "inline")
                .appendTo(this._mainDiv);

            this._dropDownButton = $("<button />")
                .addClass("btn")
                .addClass("disabled")
                .addClass("dropdown-toggle")
                .attr("data-toggle", "dropdown")
                .append("<i class='icon-search'></i>")
                .appendTo(this._dropDownDiv)
                .click(function (e) {
                    e.preventDefault();

                });

            this._dropDownUl = $("<ul />")
                .addClass("dropdown-menu")
                .attr("role", "menu")
                .attr("aria-labelledby", "dLabel")
                .appendTo(this._dropDownDiv);
        },
        _createSearchDisplay: function () {
            this._searchDisplayDiv = $("<div/>")
                .css({
                    "width": "200px",
                    "min-height": "30px",
                    "display": "inline-block",
                    "vertical-align": "middle",
                    "border": "1px solid silver"
                })
                .appendTo(this._mainDiv);

            if (this.options.displayClass) {
                this._searchDisplayDiv.addClass(this.options.displayClass);
            }
        },
        _createConfigDiv: function () {
            this._configDiv = $("<div />")
                .addClass("btn-group")
                .appendTo(this._mainDiv);
            this._createConfigButton();
            this._createConfigUl();
        },
        _createConfigButton: function () {
            this._configButton = $("<button />")
                .addClass("btn dropdown-toggle")
                .attr("data-toggle", "dropdown")
                .append("<i class='icon-cog'></i>")
                .appendTo(this._configDiv);
        },
        _createConfigUl: function () {
            this._configUl = $("<ul />")
                .addClass("dropdown-menu")
                .appendTo(this._configDiv);
        },
        _createUlItems: function () {
            var self = this;
            for (var i = 0; i < self.options.fields.length; i++) {
                if (self.options.fields[i].filter == undefined || self.options.fields[i].filter == true) {
                    var currentField = self.options.fields[i];
                    $("<li />")
                        .data("field", currentField)
                        .html("<a>" + currentField.fieldTitle + "</a>")
                        .appendTo(self._configUl)
                        .click(function (e) {
                            e.preventDefault();
                            self._defaultValueField = $(this).data("field");
                            self._setPlaceHolder();
                            $(self._searchInput).focus();
                        });
                }
            }
            this._createStringFilterModeOptions();
        },
        _createStringFilterModeOptions: function () {

            var self = this;

            $("<li />").addClass("divider").appendTo(this._configUl);

            var aRoot = $("<a />")
                .html("<i class='icon-filter'></i>   نوع جستجو")
                .attr("tabindex", "-1");

            self._stringSearchModeUl = $("<ul />").addClass("dropdown-menu");

            var liStartWith = $("<li />").data("fiter-mode", "startWith").appendTo(self._stringSearchModeUl).click(function (e) {
                e.preventDefault();
                self._defaultStringFilterMode = $(this).data("fiter-mode");
                $(self._stringSearchModeUl).find("li a").css("color", "black");
                $(this).find("a").css("color", "blue");
                $(self._searchInput).focus();
            });
            var aStartWith = $("<a />").html("آغاز با").appendTo(liStartWith);

            var liContains = $("<li />").data("fiter-mode", "contains").appendTo(self._stringSearchModeUl).click(function (e) {
                e.preventDefault();
                self._defaultStringFilterMode = $(this).data("fiter-mode");
                $(self._stringSearchModeUl).find("li a").css("color", "black");
                $(this).find("a").css("color", "blue");
                $(self._searchInput).focus();
            });
            var aContains = $("<a />").html("شامل").appendTo(liContains);

            var liEqual = $("<li />").data("fiter-mode", "equal").appendTo(self._stringSearchModeUl).click(function (e) {
                e.preventDefault();
                self._defaultStringFilterMode = $(this).data("fiter-mode");
                $(self._stringSearchModeUl).find("li a").css("color", "black");
                $(this).find("a").css("color", "blue");
                $(self._searchInput).focus();
            });
            var aEqual = $("<a />").html("برابر").appendTo(liEqual);

            var li = $("<li />")
                .addClass("dropdown-submenu")
                .append(aRoot)
                .append(self._stringSearchModeUl)
                .appendTo(this._configUl);

            //-- set default string search filter mode
            if (this.options.defaultStringFilterMode) {
                if (this.options.defaultStringFilterMode == "contains") {
                    $(self._stringSearchModeUl).find("li a").css("color", "black");
                    $(self._stringSearchModeUl).find("li a:eq(1)").css("color", "blue");
                }
                else if (this.options.defaultStringFilterMode == "equal") {
                    $(self._stringSearchModeUl).find("li a").css("color", "black");
                    $(self._stringSearchModeUl).find("li a:eq(2)").css("color", "blue");
                }
                else {
                    $(self._stringSearchModeUl).find("li a").css("color", "black");
                    $(self._stringSearchModeUl).find("li a:eq(0)").css("color", "blue");
                }
            }
            else {
                self._defaultStringFilterMode = "startWith";
                $(self._stringSearchModeUl).find("li a").css("color", "black");
                $(self._stringSearchModeUl).find("li a:eq(0)").css("color", "blue");
            }
        },
        _createDropDownListItems: function (records) {
            var self = this;
            if (records && records.length > 0) {
                for (var i = 0; i < records.length; i++) {
                    var a = $("<a />")
                        .attr("role", "menuitem")
                        .attr("tabindex", "-1")
                        .data("record", records[i])
                        .click(function (e) {
                            e.preventDefault();
                            var rec = $(this).data("record");
                            var value = rec[self._defaultValueField.fieldName];
                            $(self._searchInput).val(value);
                            self._setDisplay(rec);
                        });

                    var li = $("<li />").attr("role", "presentation");
                    this._createListItem(li, a, records[i], i);
                }
            }
            this._showDropDown();
        },
        _createListItem: function (li, a, record, index) {
            var innerHtml = null;
            if (this.options.listItemsDisplay) {
                innerHtml = this.options.listItemsDisplay(a, record, index);
            }
            else {
                innerHtml = record[this._defaultDisplayField.fieldName];
            }
            li.append(a.append(innerHtml)).appendTo(this._dropDownUl);
        },
        _createResult: function (records) {

            if (records && records.length > 0) {
                if (records.length == 1) {
                    this._setDisplay(records[0]);
                }
                else {
                    $(this._dropDownButton).removeClass("disabled");
                    this._createDropDownListItems(records);
                }
            }
            else {
                $(this._configButton).removeClass("disabled");
                this._clearDisplay();
            }
        },

        _applyOptions: function () {
            this._defaultStringFilterMode = this.options.defaultStringFilterMode;
            this._setPlaceHolder();
            this._createUlItems();
        },
        _setPlaceHolder: function () {
            $(this._searchInput).attr("placeholder", this._defaultValueField.fieldTitle);
        },

        _showBusy: function () {
            var self = this;

        },
        _hideBusy: function () {
            var self = this;

        },
        _showNotify: function (msg) {

        },
        _getParameters: function () {
            var parameters = {
                fieldName: this._defaultValueField.fieldName,
                value: $(this._searchInput).val()
            };
            if (this._defaultValueField.isStringType) {
                parameters = $.extend({}, { stringFilterMode: this._defaultStringFilterMode }, parameters);
            }
            return parameters;
        },
        _loadData: function () {
            var self = this;
            self._showBusy();

            $(self._dropDownButton).addClass("disabled");
            $(self._configButton).addClass("disabled");

            $.ajax({
                url: this.options.loadUrl,
                data: this._getParameters(),
                dataType: 'json',
                type: 'POST',
                success: function (data) {
                    self._hideBusy();

                    if (data.Status != 'OK') {
                        self._showNotify("error");
                        return;
                    }
                    self._createResult(data.Records);
                },
                error: function (e) {
                    self._hideBusy();
                },
                complete: function (data) {
                    $(self._configButton).removeClass("disabled");
                }
            });
        },
        _startLoad: function () {
            if ($(this._searchInput).val().trim().length > 0) {
                this._loadData();
            }
            else {


                this._clearDisplay();
            }
        },

        _setDisplay: function (record) {

            if (this.options.displayNoResultClass) {
                $(this._searchDisplayDiv).removeClass(this.options.displayNoResultClass);
            }

            if (this.options.display) {
                this.options.display(this._searchDisplayDiv, record);
            }
            else {
                $(this._searchDisplayDiv).html(record[this._defaultDisplayField.fieldName]);
            }
        },
        _clearDisplay: function () {
            $(this._searchDisplayDiv).html("");

            if (this.options.displayNoResultClass) {
                $(this._searchDisplayDiv).addClass(this.options.displayNoResultClass);
            }

            $(this._dropDownUl).empty();
            $(this._dropDownButton).addClass("disabled");
        },

        _showDropDown: function () {
            //$(this._dropDownUl).dropdown();
            $(this._dropDownButton).click();
        },
        _hasStringField: function () {
            if (this.options.fields && this.options.fields.length > 0) {
                for (var i = 0; i < this.options.fields.length; i++) {
                    if (this.options.fields[i].isStringType) {
                        return true;
                    }
                }
            }
        },
        _setDefaultValueField: function () {
            if (this.options.fields && this.options.fields.length > 0) {
                for (var i = 0; i < this.options.fields.length; i++) {
                    if (this.options.fields[i].defaultValueField) {
                        this._defaultValueField = this.options.fields[i];
                        return;
                    }
                }
                this._defaultValueField = this.options.fields[0];
            }
        },
        _setDefaultDisplayField: function () {
            if (this.options.fields && this.options.fields.length > 0) {
                for (var i = 0; i < this.options.fields.length; i++) {
                    if (this.options.fields[i].defaultDisplayField) {
                        this._defaultDisplayField = this.options.fields[i];
                        return;
                    }
                }
                if (this.options.fields.length == 2)
                    this._defaultDisplayField = this.options.fields[1];
                else this._defaultDisplayField = this.options.fields[0];
            }
        }
    });
}(jQuery));