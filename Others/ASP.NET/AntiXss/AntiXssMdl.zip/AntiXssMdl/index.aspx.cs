﻿using System;
using System.Web;

namespace AntiXssMdl
{
    public partial class index : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Request["id"] != null)
            {
                lblData.Text = Request["id"];
            }
            addCookies();
        }

        protected void btnShow_Click(object sender, EventArgs e)
        {
            lblData.Text = txtData.Text;
        }

        void addCookies()
        {
            HttpCookie cookie = new HttpCookie("testCookie");
            cookie.Values.Add("name1", "value1");
            cookie.Values.Add("name2", "value2<script>alert('hi!')</script>");
            Response.Cookies.Add(cookie);
        }
    }
}