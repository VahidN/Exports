﻿using System;
using System.Web.UI;

namespace YeKeJQuery
{
    public partial class Default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Page.SetFocus(txtData);
        }

        protected void btnSubmit_Click(object sender, EventArgs e)
        {

        }
    }
}