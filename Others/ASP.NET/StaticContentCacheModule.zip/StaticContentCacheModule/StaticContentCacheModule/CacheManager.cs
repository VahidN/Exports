﻿using System;

namespace StaticContentCacheModule
{
    class CacheManager
    {
        public static bool ShouldCache(string contentType)
        {
            contentType = contentType.ToLower();
            string[] parts =
                contentType.Split(
                    new[] { ';' },
                    StringSplitOptions.RemoveEmptyEntries
                );

            if (parts.Length > 0)
                contentType = parts[0];

            bool cache = false;

            switch (contentType)
            {
                case "text/css":
                    cache = true; break;
                case "text/javascript":
                case "text/jscript":
                    cache = true; break;
                case "image/jpeg":
                    cache = true; break;
                case "image/gif":
                    cache = true; break;
                case "application/octet-stream":
                    cache = true; break;
                default:
                    {
                        if (contentType.Contains("javascript"))
                            cache = true;
                        if (contentType.Contains("css"))
                            cache = true;
                        if (contentType.Contains("image"))
                            cache = true;
                        if (contentType.Contains("application"))
                            cache = true;
                    }
                    break;
            }

            return cache;
        }
    }
}
