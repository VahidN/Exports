﻿using System;
using System.Web;

namespace StaticContentCacheModule
{
    public class StaticCache : IHttpModule
    {
        //todo: با آي آي اس 6 تست شود
        public void Init(HttpApplication context)
        {
            context.PreSendRequestHeaders += context_PreSendRequestHeaders;
        }

        static void context_PreSendRequestHeaders(object sender, EventArgs e)
        {
            //capture the current Response  
            var currentResponse = ((HttpApplication)sender).Response;

            if (CacheManager.ShouldCache(currentResponse.ContentType))
            {
                currentResponse.AddHeader("cache-control", "public");
                currentResponse.AddHeader("Expires", DateTime.Now.Add(TimeSpan.FromDays(30)).ToString());
            }
        }

        public void Dispose() { }
    }
}
