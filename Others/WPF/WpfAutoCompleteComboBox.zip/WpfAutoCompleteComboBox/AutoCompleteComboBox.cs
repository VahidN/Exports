﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace WpfAutoCompleteComboBox
{
    //ported from: http://www.codeproject.com/KB/silverlight/AutoComplete_ComboBox.aspx
    public class AutoCompleteComboBox : AutoCompleteBox
    {
        #region Fields (2)

        private string _initText = string.Empty;
        bool _isUpdatingDPs;

        #endregion Fields

        #region Constructors (1)

        public AutoCompleteComboBox()
        {            
            DefaultStyleKey = typeof(AutoCompleteComboBox);
        }

        #endregion Constructors

        #region Methods (5)

        // Public Methods (1) 

        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            var toggle = (ToggleButton)GetTemplateChild("DropDownToggle");
            if (toggle == null) return;
            toggle.Click += dropDownToggleClick;
        }
        // Protected Methods (2) 

        protected override void OnDropDownClosed(RoutedPropertyChangedEventArgs<bool> e)
        {
            if (string.IsNullOrEmpty(Text)) // fill the text box again with previous data, is it's empty
            {
                Text = _initText;
            }

            base.OnDropDownClosed(e);
            updateCustomDPs();
        }

        //highlighting logic
        protected override void OnPopulated(PopulatedEventArgs e)
        {
            base.OnPopulated(e);
            var listBox = GetTemplateChild("Selector") as ListBox;
            if (listBox == null) return;

            //highlight the selected item, if any
            if (ItemsSource == null || SelectedItem == null) return;

            listBox.SelectedItem = SelectedItem;
            listBox.Dispatcher.BeginInvoke((Action)delegate
            {
                listBox.UpdateLayout();
                listBox.ScrollIntoView(listBox.SelectedItem);
            });
        }
        // Private Methods (2) 

        private void dropDownToggleClick(object sender, RoutedEventArgs e)
        {
            Focus();

            AutoCompleteBox acb = this;
            if (!string.IsNullOrEmpty(acb.Text))
                _initText = acb.Text;
            acb.Text = string.Empty; // force it to show all items in a natural way

            acb.IsDropDownOpen = !acb.IsDropDownOpen;
        }

        private void updateCustomDPs()
        {
            //flag to ensure that that we don't reselect the selected item
            _isUpdatingDPs = true;

            //if a new item is selected or the user blanked out the selection, update the DP
            if (SelectedItem != null || Text == string.Empty)
            {
                //update the SelectedItemBinding DP
                SetValue(SelectedItemBindingProperty, GetValue(SelectedItemProperty));

                //update the SelectedValue DP 
                var propertyPath = SelectedValuePath;
                if (!string.IsNullOrEmpty(propertyPath))
                {
                    if (SelectedItem != null)
                    {
                        var propertyInfo = SelectedItem.GetType().GetProperty(propertyPath);

                        //get property from selected item
                        if (propertyInfo != null)
                        {
                            var propertyValue = propertyInfo.GetValue(SelectedItem, null);
                            //update the datacontext
                            SelectedValue = propertyValue;
                        }
                    }
                    else //user blanked out the selection, so we need to set the default value
                    {
                        //get the binding for selectedvalue property
                        var bindingExpression = GetBindingExpression(SelectedValueProperty);
                        var dataBinding = bindingExpression.ParentBinding;

                        //get the dataitem (typically the datacontext)
                        var dataItem = bindingExpression.DataItem;

                        //get the property of that dataitem that's bound to selectedValue property
                        var propertyPathForSelectedValue = dataBinding.Path.Path;

                        //get the default value for that property
                        var propertyInfo = dataItem.GetType().GetProperty(propertyPathForSelectedValue);
                        object defaultObj = null;
                        if (propertyInfo != null)
                        {
                            var propertyTypeForSelectedValue = propertyInfo.PropertyType;

                            if (propertyTypeForSelectedValue.IsValueType) //get default for value types only
                                defaultObj = Activator.CreateInstance(propertyTypeForSelectedValue);
                        }
                        //update the Selected Value property
                        SelectedValue = defaultObj;
                    }
                }
            }
            else
            {
                //revert to the originally selected one
                if (GetBindingExpression(SelectedItemBindingProperty) != null)
                {
                    SetSelectemItemUsingSelectedItemBindingDP();
                }

                else if (GetBindingExpression(SelectedValueProperty) != null)
                {
                    SetSelectemItemUsingSelectedValueDP();
                }
            }

            _isUpdatingDPs = false;
        }

        #endregion Methods



        #region SelectedItemBinding

        /// <summary>
        /// SelectedItemBinding Dependency Property
        /// </summary>
        public static readonly DependencyProperty SelectedItemBindingProperty =
            DependencyProperty.Register("SelectedItemBinding",
                    typeof(object),
                    typeof(AutoCompleteComboBox),
                    new PropertyMetadata(new PropertyChangedCallback(onSelectedItemBindingChanged))
                    );

        /// <summary>
        /// Gets or sets the SelectedItemBinding property.
        /// </summary>
        public object SelectedItemBinding
        {
            get { return GetValue(SelectedItemBindingProperty); }
            set { SetValue(SelectedItemBindingProperty, value); }
        }

        /// <summary>
        /// Handles changes to the SelectedItemBinding property.
        /// </summary>
        private static void onSelectedItemBindingChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((AutoCompleteComboBox)d).OnSelectedItemBindingChanged(e);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the SelectedItemBinding property.
        /// </summary>
        protected virtual void OnSelectedItemBindingChanged(DependencyPropertyChangedEventArgs e)
        {
            SetSelectemItemUsingSelectedItemBindingDP();
        }

        public void SetSelectemItemUsingSelectedItemBindingDP()
        {
            if (!_isUpdatingDPs)
                SetValue(SelectedItemProperty, GetValue(SelectedItemBindingProperty));
        }

        #endregion

        #region SelectedValue

        /// <summary>
        /// SelectedValue Dependency Property
        /// </summary>
        public static readonly DependencyProperty SelectedValueProperty =
            DependencyProperty.Register("SelectedValue",
                    typeof(object),
                    typeof(AutoCompleteComboBox),
                    new PropertyMetadata(new PropertyChangedCallback(onSelectedValueChanged))
                    );

        /// <summary>
        /// Gets or sets the SelectedValue property.
        /// </summary>
        public object SelectedValue
        {
            get { return GetValue(SelectedValueProperty); }
            set { SetValue(SelectedValueProperty, value); }
        }

        /// <summary>
        /// Handles changes to the SelectedValue property.
        /// </summary>
        private static void onSelectedValueChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            ((AutoCompleteComboBox)d).OnSelectedValueChanged(e);
        }

        /// <summary>
        /// Provides derived classes an opportunity to handle changes to the SelectedValue property.
        /// </summary>
        protected virtual void OnSelectedValueChanged(DependencyPropertyChangedEventArgs e)
        {
            SetSelectemItemUsingSelectedValueDP();
        }

        //selects the item whose value is given in SelectedValueDP
        public void SetSelectemItemUsingSelectedValueDP()
        {
            if (_isUpdatingDPs) return;
            if (ItemsSource == null) return;

            // if selectedValue is empty, remove the current selection
            if (SelectedValue == null)
            {
                SelectedItem = null;
            }
            // if there is no selected item, 
            // select the one given by SelectedValueProperty
            else
            {
                var selectedValue = GetValue(SelectedValueProperty);
                var propertyPath = SelectedValuePath;
                if (selectedValue != null && !(string.IsNullOrEmpty(propertyPath)))
                {
                    // loop through each item in the item source 
                    // and see if its <SelectedValuePathProperty> == SelectedValue
                    foreach (var item in ItemsSource)
                    {
                        var propertyInfo = item.GetType().GetProperty(propertyPath);
                        if (propertyInfo.GetValue(item, null).Equals(selectedValue))
                            SelectedItem = item;
                    }
                }
            }
        }

        #endregion

        #region SelectedValuePath

        /// <summary>
        /// SelectedValuePath Dependency Property
        /// </summary>
        public static readonly DependencyProperty SelectedValuePathProperty =
            DependencyProperty.Register("SelectedValuePath",
                    typeof(string),
                    typeof(AutoCompleteComboBox),
                    null
                    );

        /// <summary>
        /// Gets or sets the SelectedValuePath property.
        /// </summary>
        public string SelectedValuePath
        {
            get { return GetValue(SelectedValuePathProperty) as string; }
            set { SetValue(SelectedValuePathProperty, value); }
        }

        #endregion
    }
}
