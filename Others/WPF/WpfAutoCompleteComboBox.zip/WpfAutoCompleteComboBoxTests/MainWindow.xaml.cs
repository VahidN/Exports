﻿
namespace WpfAutoCompleteComboBoxTests
{
    public partial class MainWindow
    {
        public MainWindow()
        {
            InitializeComponent();           
        }
    }
}
