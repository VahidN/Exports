﻿
namespace WpfAutoCompleteComboBoxTests.Views
{
    public partial class IntegerForeignKeyDemo
    {
        public IntegerForeignKeyDemo()
        {
            InitializeComponent();
        }
    }
}
