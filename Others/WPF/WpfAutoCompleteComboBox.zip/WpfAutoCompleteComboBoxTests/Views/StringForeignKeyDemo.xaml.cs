﻿namespace WpfAutoCompleteComboBoxTests.Views
{
    public partial class StringForeignKeyDemo
    {
        public StringForeignKeyDemo()
        {
            InitializeComponent();
        }
    }
}
