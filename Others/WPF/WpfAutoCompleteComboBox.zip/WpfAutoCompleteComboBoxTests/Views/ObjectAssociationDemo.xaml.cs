﻿namespace WpfAutoCompleteComboBoxTests.Views
{
    public partial class ObjectAssociationDemo
    {
        public ObjectAssociationDemo()
        {
            InitializeComponent();
        }
    }
}
