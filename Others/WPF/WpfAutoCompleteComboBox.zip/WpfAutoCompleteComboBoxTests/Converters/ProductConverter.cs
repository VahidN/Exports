﻿using System;

namespace WpfAutoCompleteComboBoxTests.Converters
{
    public class ProductConverter : System.Windows.Data.IValueConverter
    {
        #region IValueConverter Members

        public object Convert(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            if (value is int)
            {
                var productID = (int)value;
                var product = Models.DataClassesWithIntegerForeignKeys.Product.GetProduct(productID);
                if (product != null)
                    return product.ToString();
            }
            else if (value is string)
            {
                var productID = value as string;
                var product = Models.DataClassesWithStringForeignKeys.Product.GetProduct(productID);
                if (product != null)
                    return product.ToString();
            }
            return string.Empty;
        }

        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }

        #endregion

    }
}
