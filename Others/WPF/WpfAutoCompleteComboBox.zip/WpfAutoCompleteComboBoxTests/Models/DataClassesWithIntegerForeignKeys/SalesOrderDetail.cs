﻿using System.Collections.Generic;

namespace WpfAutoCompleteComboBoxTests.Models.DataClassesWithIntegerForeignKeys
{
    public class SalesOrderDetail : System.ComponentModel.INotifyPropertyChanged, System.ComponentModel.IEditableObject
    {
        #region Fields (2)

        int _productID;
        int _quantity;

        #endregion Fields

        #region Properties (2)

        public int ProductID
        {
            get { return _productID; }
            set { _productID = value; onPropertyChanged("ProductID"); }
        }

        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; onPropertyChanged("Quantity"); }
        }

        #endregion Properties

        #region Methods (1)

        // Public Methods (1) 

        public static List<SalesOrderDetail> GetProductList()
        {
            var list = new List<SalesOrderDetail>
            {
                new SalesOrderDetail { ProductID=3, Quantity=1  },
                new SalesOrderDetail { ProductID=7, Quantity=2  },
                new SalesOrderDetail { ProductID=4, Quantity=3  },
                new SalesOrderDetail { ProductID=9, Quantity=4  },
                new SalesOrderDetail { ProductID=1, Quantity=5  },
            };
            return list;
        }

        #endregion Methods



        #region INotifyPropertyChanged Members

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;
        private void onPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
        }

        #endregion

        #region IEditableObject Members
        private SalesOrderDetail _original;
        bool _isEditing;
        public void BeginEdit()
        {
            if (_isEditing) return;
            _original = MemberwiseClone() as SalesOrderDetail;
            _isEditing = true;
        }

        public void CancelEdit()
        {
            if (!_isEditing) return;
            ProductID = _original.ProductID;
            Quantity = _original.Quantity;
            _isEditing = false;
        }

        public void EndEdit()
        {
            if (!_isEditing) return;
            _original = null;
            _isEditing = false;
        }

        #endregion
    }
}
