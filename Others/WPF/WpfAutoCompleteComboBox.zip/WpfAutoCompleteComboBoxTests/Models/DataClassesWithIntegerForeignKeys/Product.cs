﻿using System.Collections.Generic;
using System.Linq;

namespace WpfAutoCompleteComboBoxTests.Models.DataClassesWithIntegerForeignKeys
{
    public class Product
    {
        #region Properties

        public string Name { get; set; }

        public int ProductID { get; set; }

        #endregion

        #region Some static helper functions

        public static Product GetProduct(int productID)
        {
            return GetProductList().FirstOrDefault(c => c.ProductID == productID);
        }

        public static List<Product> GetProductList()
        {
            var list = new List<Product>
                {
                    new Product{ ProductID=1, Name="Computer" },
                    new Product{ ProductID=2, Name="Book" },
                    new Product{ ProductID=3, Name="Pencil" },
                    new Product{ ProductID=4, Name="Phone" },
                    new Product{ ProductID=5, Name="Burger" },
                    new Product{ ProductID=6, Name="Shoes" },
                    new Product{ ProductID=7, Name="Bus" },
                    new Product{ ProductID=8, Name="Car" },
                    new Product{ ProductID=9, Name="Battery" },
                    new Product{ ProductID=10, Name="Laptop" },
                    new Product{ ProductID=11, Name="Football" },
                    new Product{ ProductID=12, Name="Button" }
                };
            return list;
        }

        #endregion

        #region Override Object methods

        public override string ToString()
        {
            return Name;
        }

        public override bool Equals(object obj)
        {
            var anotherProduct = obj as Product;
            if (anotherProduct != null)
            {
                return anotherProduct.ProductID == ProductID;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return ProductID.GetHashCode();
        }

        #endregion
    }
}
