﻿using System.Collections.Generic;
using System.Linq;

namespace WpfAutoCompleteComboBoxTests.Models.DataClassesWithStringForeignKeys
{
    public class Product
    {


        #region Properties

        public string Name { get; set; }

        public string ProductID { get; set; }

        #endregion

        #region Some static helper functions

        public static Product GetProduct(string productID)
        {
            return GetProductList().FirstOrDefault(c => c.ProductID == productID);
        }

        public static List<Product> GetProductList()
        {
            var list = new List<Product>
                {
                    new Product{ ProductID="p1", Name="Computer" },
                    new Product{ ProductID="p2", Name="Book" },
                    new Product{ ProductID="p3", Name="Pencil" },
                    new Product{ ProductID="p4", Name="Phone" },
                    new Product{ ProductID="p5", Name="Burger" },
                    new Product{ ProductID="p6", Name="Shoes" },
                    new Product{ ProductID="p7", Name="Bus" },
                    new Product{ ProductID="p8", Name="Car" },
                    new Product{ ProductID="p9", Name="Battery" },
                    new Product{ ProductID="p10", Name="Laptop" },
                    new Product{ ProductID="p11", Name="Football" },
                    new Product{ ProductID="p12", Name="Button" }
                };
            return list;
        }

        #endregion

        #region Override Object methods

        public override string ToString()
        {
            return Name;
        }

        public override bool Equals(object obj)
        {
            var anotherProduct = obj as Product;
            if (anotherProduct != null)
            {
                return anotherProduct.ProductID == ProductID;
            }
            return false;
        }

        public override int GetHashCode()
        {
            return ProductID.GetHashCode();
        }

        #endregion
    }
}
