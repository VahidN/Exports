﻿using System.Collections.Generic;

namespace WpfAutoCompleteComboBoxTests.Models.DataClassesWithObjectAssociations
{
    public class SalesOrderDetail : System.ComponentModel.INotifyPropertyChanged
    {
        #region Fields (2)

        Product _product;
        int _quantity;

        #endregion Fields

        #region Properties (2)

        public Product Product
        {
            get { return _product; }
            set { _product = value; onPropertyChanged("Product"); }
        }

        public int Quantity
        {
            get { return _quantity; }
            set { _quantity = value; onPropertyChanged("Quantity"); }
        }

        #endregion Properties

        #region Methods (1)

        // Public Methods (1) 

        public static List<SalesOrderDetail> GetProductList()
        {
            var products = Product.GetProductList();
            var list = new List<SalesOrderDetail>
            {
                new SalesOrderDetail { Product=products[3], Quantity=1  },
                new SalesOrderDetail { Product=products[7], Quantity=2  },
                new SalesOrderDetail { Product=products[4], Quantity=3  },
                new SalesOrderDetail { Product=products[9], Quantity=4  },
                new SalesOrderDetail { Product=products[1], Quantity=5  },
            };
            return list;
        }

        #endregion Methods



        #region INotifyPropertyChanged Members

        public event System.ComponentModel.PropertyChangedEventHandler PropertyChanged;
        private void onPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
                PropertyChanged(this, new System.ComponentModel.PropertyChangedEventArgs(propertyName));
        }

        #endregion
    }
}
