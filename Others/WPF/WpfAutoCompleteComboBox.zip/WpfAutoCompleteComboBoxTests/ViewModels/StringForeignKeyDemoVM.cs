﻿using System.Collections.Generic;
using WpfAutoCompleteComboBoxTests.Models.DataClassesWithStringForeignKeys;

namespace WpfAutoCompleteComboBoxTests.ViewModels
{
    public class StringForeignKeyDemoVM
    {
        public IEnumerable<SalesOrderDetail> OrderDetails
        {
            get { return SalesOrderDetail.GetProductList(); }
        }

        public IEnumerable<Product> Products
        {
            get { return Product.GetProductList(); }
        }
    }
}
