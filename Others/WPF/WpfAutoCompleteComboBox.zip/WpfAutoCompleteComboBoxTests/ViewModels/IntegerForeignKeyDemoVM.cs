﻿using System.Collections.Generic;
using WpfAutoCompleteComboBoxTests.Models.DataClassesWithIntegerForeignKeys;

namespace WpfAutoCompleteComboBoxTests.ViewModels
{
    public class IntegerForeignKeyDemoVM
    {
        public IEnumerable<SalesOrderDetail> OrderDetails
        {
            get { return SalesOrderDetail.GetProductList(); }
        }

        public IEnumerable<Product> Products
        {
            get { return Product.GetProductList(); }
        }
    }
}
