﻿using System.Collections.Generic;
using WpfAutoCompleteComboBoxTests.Models.DataClassesWithObjectAssociations;

namespace WpfAutoCompleteComboBoxTests.ViewModels
{
    public class ObjectAssocationDemoVM
    {
        public IEnumerable<SalesOrderDetail> OrderDetails
        {
            get { return SalesOrderDetail.GetProductList(); }
        }

        public IEnumerable<Product> Products
        {
            get { return Product.GetProductList(); }
        }
    }
}
