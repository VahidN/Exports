﻿using System;
using Test1.Model;
using Test1.Helper;

namespace Test1
{
    class Program
    {
        static void Main()
        {
            //HibernatingRhinos.Profiler.Appender.NHibernate.NHibernateProfiler.Initialize();
            using (var sessionFactory = ConfigNH.ConfigSessionFactory())
            {
                using (var session = sessionFactory.OpenSession())
                {
                    using (var tx = session.BeginTransaction())
                    {
                        var customer1 = new Customer { Name = "Test1" };
                        var customer2 = new Customer { Name = "Test2" };
                        session.Save(customer1);
                        session.Save(customer2);

                        session.Save(new Order { Customer = customer1, OrderDate = DateTime.Now });
                        session.Save(new Order { Customer = customer2, OrderDate = DateTime.Now });

                        tx.Commit();
                    }
                }

                Console.WriteLine();

                using (var session = sessionFactory.OpenSession())
                {
                    using (var tx = session.BeginTransaction())
                    {
                        Console.ForegroundColor = ConsoleColor.DarkYellow;
                        Console.WriteLine("Lazy loading--------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Cyan;
                        var list1 = session.QueryOver<Customer>().List();
                        foreach (var customer in list1)
                            foreach (var order in customer.Orders)
                                Console.WriteLine("{0}:{1}:{2}:{3}", customer.Id, order.Id, customer.Name,
                                                  order.OrderDate);


                        Console.WriteLine();
                        Console.ForegroundColor = ConsoleColor.DarkGreen;
                        Console.WriteLine("Eager fetching------------------------------------------");
                        Console.ForegroundColor = ConsoleColor.Green;
                        var list2 = session
                              .QueryOver<Customer>()
                              .Fetch(c => c.Orders).Eager
                              .List();

                        foreach (var customer in list2)
                            foreach (var order in customer.Orders)
                                Console.WriteLine("{0}:{1}:{2}:{3}", customer.Id, order.Id, customer.Name,
                                                  order.OrderDate);

                        tx.Commit();
                    }
                }
            }

            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("Press a key...");
            Console.ReadKey();
        }
    }
}
