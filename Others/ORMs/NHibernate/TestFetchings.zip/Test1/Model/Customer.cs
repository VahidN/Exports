using System.Collections.Generic;

namespace Test1.Model
{
    public class Customer
    {
        public virtual int Id { get; set; }
        public virtual IList<Order> Orders { get; set; }
        public virtual string Name { get; set; }
    }
}
