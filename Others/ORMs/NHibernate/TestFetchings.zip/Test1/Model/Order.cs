using System;

namespace Test1.Model
{
    public class Order
    {
        public virtual int Id { get; set; }
        public virtual Customer Customer { get; set; }
        public virtual DateTime? OrderDate { get; set; }
    }
}
