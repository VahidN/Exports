﻿using FluentNHibernate.Automapping;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using FluentNHibernate.Conventions.Helpers;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using Test1.Model;

namespace Test1.Helper
{
    public class ConfigNH
    {
        public static ISessionFactory ConfigSessionFactory()
        {
            //Creating tables, mappings, etc.
            var dbType = MsSqlConfiguration.MsSql2008
                            //جهت نمايش اس كيوال به صورت فرمت شده
                            .ShowSql().FormatSql()
                            .ConnectionString("Data Source=(local);Initial Catalog=testdb;Integrated Security=true");
            var cfg = dbType.ConfigureProperties(new Configuration());
            var autoPM = new AutoPersistenceModel()
                 .Where(x => x.Namespace.EndsWith("Model"))
                 .AddEntityAssembly(typeof(Customer).Assembly)
                 .Conventions.Add().Where(c => c.Namespace.EndsWith("Model"))
                 .Conventions.Add(Table.Is(t => t.EntityType.Name + "s"));
            autoPM.Configure(cfg);
            //جهت ساخت اسكريپت به همراه اجراي آن روي ديتابيس
            new SchemaExport(cfg).SetOutputFile("db.sql").Create(true, true);

            //todo: اين مورد بايد كش شود توسط الگوي سينگلتون و فقط يكبار بايد در طول برنامه فراخواني گردد
            return Fluently.Configure().Database(dbType)
                                     .Mappings(m => m.AutoMappings.Add(autoPM).ExportTo(System.Environment.CurrentDirectory))
                                     .BuildSessionFactory();
        }
    }
}
