﻿using System.IO;
using NH3SQLLogger.Resources.Util;

namespace NH3SQLLogger
{
	public class Syntaxhighlighter
	{
		#region Methods (2)

		// Public Methods (2) 

		public static void End(string fileName)
		{
			if (string.IsNullOrWhiteSpace(fileName)) return;

			File.AppendAllLines(
				fileName,
				new[]
				{
					"</body>",
					"</html>"
				});
		}

		public static void Init(string fileName, string title)
		{
			if (string.IsNullOrWhiteSpace(fileName)) return;

			CopyToOutputDir.Start(Path.GetDirectoryName(fileName));

			File.WriteAllLines(
				fileName,
				new[]
				{
					@"<!DOCTYPE html PUBLIC ""-//W3C//DTD XHTML 1.0 Strict//EN"" ""http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd"">",
					@"<html xmlns=""http://www.w3.org/1999/xhtml"" xml:lang=""en"" lang=""en"">",
					@"<head>",
					@"<meta http-equiv=""Content-Type"" content=""text/html; charset=UTF-8"" />",
					@"<title>" + title + @"</title>",
					@"<link href='shCore.css' rel='stylesheet' type='text/css'/>",
					@"<link href='shCoreDefault.css' rel='stylesheet' type='text/css'/>",
					@"<script src='shCore.js' type='text/javascript'></script>",
					@"<script src='shBrushSql.js' type='text/javascript'></script>",
					@"<script type='text/javascript'>SyntaxHighlighter.all();</script>",
					@"</head>",
					@"<body style=""background: white; font-family: Consolas; font-size:12pt;"">"
				});
		}

		#endregion Methods
	}
}
