﻿using System.IO;
using System.Reflection;

namespace NH3SQLLogger.Resources.Util
{
    public class CopyToOutputDir
    {
        #region Methods (2)

        // Public Methods (1) 

        public static void Start(string dir)
        {
            File.WriteAllText(string.Format("{0}\\shBrushSql.js", dir), getResourceFile("NH3SQLLogger.Resources.shBrushSql.js"));
            File.WriteAllText(string.Format("{0}\\shCore.css", dir), getResourceFile("NH3SQLLogger.Resources.shCore.css"));
            File.WriteAllText(string.Format("{0}\\shCore.js", dir), getResourceFile("NH3SQLLogger.Resources.shCore.js"));
            File.WriteAllText(string.Format("{0}\\shCoreDefault.css", dir), getResourceFile("NH3SQLLogger.Resources.shCoreDefault.css"));
        }
        // Private Methods (1) 

        private static string getResourceFile(string filename)
        {
            var thisAssembly = Assembly.GetExecutingAssembly();
            var stream = thisAssembly.GetManifestResourceStream(filename);
            return new StreamReader(stream).ReadToEnd();
        }

        #endregion Methods
    }
}
