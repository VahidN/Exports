﻿using System;
using System.IO;
using NHibernate;

namespace NH3SQLLogger
{
	public class EventsLogger : IInternalLogger
	{
		#region Fields (1)

		readonly string _fileName;

		#endregion Fields

		#region Constructors (1)

		public EventsLogger(string fileName)
		{
			_fileName = fileName;
		}

		#endregion Constructors

		#region Properties (5)

		public bool IsDebugEnabled
		{
			get { return true; }
		}

		public bool IsErrorEnabled
		{
			get { return true; }
		}

		public bool IsFatalEnabled
		{
			get { return true; }
		}

		public bool IsInfoEnabled
		{
			get { return true; }
		}

		public bool IsWarnEnabled
		{
			get { return true; }
		}

		#endregion Properties

		#region Methods (14)

		// Public Methods (14) 

		public void Debug(object message)
		{
			if (message == null) return;
			File.AppendAllLines(_fileName, new[]
			{
			  string.Empty,
			  "<pre class='brush: sql'>" ,
			  string.Format("---+ {0} +---", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.ff")),
			  CallingMethod.GetCallingMethodInfo().EscapeXml(),
			  FormatSQL.ApplyFormat(message.ToString().Trim()).EscapeXml(),
			  "</pre>"
			});
		}

		public void Debug(object message, Exception exception)
		{
			if (message == null || exception == null) return;
			File.AppendAllLines(_fileName, new[]
			{
			  string.Empty,
			  "<pre class='brush: sql'>" , 
			  string.Format("---+ {0} +---", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.ff")),
			  CallingMethod.GetCallingMethodInfo().EscapeXml(),
			  message.ToString().Trim().EscapeXml() ,
			  exception.ToString().EscapeXml(),
			  "</pre>"
			});
		}

		public void DebugFormat(string format, params object[] args)
		{
			File.AppendAllLines(_fileName, new[]
			{
			  string.Empty,
			  "<pre class='brush: sql'>" , 
			  string.Format("---+ {0} +---", DateTime.Now.ToString("MM/dd/yyyy hh:mm:ss.ff")),
			  CallingMethod.GetCallingMethodInfo().EscapeXml(),
			  FormatSQL.ApplyFormat(string.Format(format, args)).EscapeXml(),
			  "</pre>"
			});
		}

		public void Error(object message)
		{
			Debug(message);
		}

		public void Error(object message, Exception exception)
		{
			Debug(message, exception);
		}

		public void ErrorFormat(string format, params object[] args)
		{
			DebugFormat(format, args);
		}

		public void Fatal(object message)
		{
			Debug(message);
		}

		public void Fatal(object message, Exception exception)
		{
			Debug(message, exception);
		}

		public void Info(object message)
		{
			Debug(message);
		}

		public void Info(object message, Exception exception)
		{
			Debug(message, exception);
		}

		public void InfoFormat(string format, params object[] args)
		{
			DebugFormat(format, args);
		}

		public void Warn(object message)
		{
			Debug(message);
		}

		public void Warn(object message, Exception exception)
		{
			Debug(message, exception);
		}

		public void WarnFormat(string format, params object[] args)
		{
			DebugFormat(format, args);
		}

		#endregion Methods
	}
}
