﻿using System.Text;
using NHibernate.AdoNet.Util;

namespace NH3SQLLogger
{
    public class FormatSQL
    {
        #region Methods (2)

        // Public Methods (1) 

        public static string ApplyFormat(string sql)
        {
            if (string.IsNullOrWhiteSpace(sql)) return string.Empty;
            sql = sql.Trim();

            if (sql.ToLowerInvariant().StartsWith("create table"))
            {
                return sql;
            }
            if (sql.ToLowerInvariant().StartsWith("alter table") ||
                sql.ToLowerInvariant().StartsWith("comment on"))
            {
                sql = new DdlFormatter().Format(sql);
            }
            else
            {
                sql = new BasicFormatter().Format(sql).Trim();
            }

            return formatParams(sql);
        }
        // Private Methods (1) 

        private static string formatParams(string sql)
        {
            if (!sql.Contains(";")) return sql;

            var sqlLines = sql.Split(';');

            var sb = new StringBuilder();
            foreach (var line in sqlLines)
            {
                if (line.Trim().StartsWith("@p"))
                {
                    var paramsLines = line.Split(',');

                    foreach (var paramLine in paramsLines)
                        sb.AppendLine(paramLine.Trim());
                }
                else
                {
                    sb.AppendLine(line.Trim() + ";\n");
                }
            }

            return sb.ToString();
        }

        #endregion Methods
    }
}
