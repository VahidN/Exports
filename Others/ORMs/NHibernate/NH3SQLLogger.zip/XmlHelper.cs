﻿
namespace NH3SQLLogger
{
    public static class XmlHelper
    {
        public static string EscapeXml(this string xml)
        {
            if (string.IsNullOrWhiteSpace(xml)) return string.Empty;
            // replace literal values with entities
            //xml = xml.Replace("&", "&amp;");
            //all right angle brackets must be HTML escaped
            //from: http://alexgorbatchev.com/SyntaxHighlighter/manual/installation.html
            xml = xml.Replace("<", "&lt;");
            //xml = xml.Replace(">", "&gt;");
            //xml = xml.Replace("\"", "&quot;");
            //xml = xml.Replace("'", "&apos;");
            return xml;
        }
    }
}
