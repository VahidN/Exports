﻿namespace QueryOverSqlFuncsExts
{
    public class SqlFunc
    {
        #region Constructors (1)

        public SqlFunc()
        {
            EvaluateArgs = new EvaluateArgs();
        }

        #endregion Constructors

        #region Properties (1)

        public EvaluateArgs EvaluateArgs { private set; get; }

        #endregion Properties

        #region Methods (18)

        // Public Methods (18) 

        public Restrictions<SqlFunc> Abs()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Abs;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> BitLength()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.BitLength;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> CharIndex(string theChar, int startLocation)
        {
            EvaluateArgs.Args.Add(theChar);
            EvaluateArgs.Args.Add(startLocation);
            EvaluateArgs.NativeFunction = NativeFunctions.CharIndex;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Coalesce(object replaceValueIfIsNull)
        {
            EvaluateArgs.Args.Add(replaceValueIfIsNull);
            EvaluateArgs.NativeFunction = NativeFunctions.Coalesce;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Concat(string value)
        {
            EvaluateArgs.Args.Add(value);
            EvaluateArgs.NativeFunction = NativeFunctions.Concat;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Day()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Day;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Hour()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Hour;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Length()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Length;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Minute()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Minute;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Mod(int divisor)
        {
            EvaluateArgs.Args.Add(divisor);
            EvaluateArgs.NativeFunction = NativeFunctions.Mod;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Month()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Month;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Second()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Second;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Sqrt()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Sqrt;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        /// <summary>
        /// This is the native substring which usually starts at 1
        /// </summary>
        /// <param name="startIndex"></param>
        /// <param name="length"></param>
        /// <returns></returns>
        public Restrictions<SqlFunc> Substring(int startIndex, int length)
        {
            EvaluateArgs.Args.Add(startIndex);
            EvaluateArgs.Args.Add(length);
            EvaluateArgs.NativeFunction = NativeFunctions.Substring;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> ToLower()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.ToLower;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> ToUpper()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.ToUpper;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Trim()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Trim;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        public Restrictions<SqlFunc> Year()
        {
            EvaluateArgs.NativeFunction = NativeFunctions.Year;
            return new Restrictions<SqlFunc>(this, EvaluateArgs);
        }

        #endregion Methods
    }
}