﻿namespace QueryOverSqlFuncsExts
{
    public enum QueryRestrictions
    {
        /// <summary>
        /// Default value
        /// </summary>
        NotSet,
        Eq,
        Ge,
        Gt,
        Le,
        Lt,
        Not,
        Like,
        InsensitiveLike,
        In,
        Between,
        IsNotNull,
        IsNull
    }
}