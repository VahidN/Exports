﻿using System;
using System.Linq.Expressions;
using NHibernate.Criterion;
using NHibernate.Impl;

namespace QueryOverSqlFuncsExts
{
    public static class QueryOverExt
    {
        public static bool Evaluate(this object projection, SqlFunc nativeFunction)
        {
            throw new Exception("Not to be used directly - use inside QueryOver expression");
        }

        public static ICriterion ProcessEvaluate(MethodCallExpression methodCallExpression)
        {
            string property = ExpressionProcessor.FindMemberExpression(methodCallExpression.Arguments[0]);
            var nativeSqlFunction = (SqlFunc)ExpressionProcessor.FindValue(methodCallExpression.Arguments[1]);

            if (nativeSqlFunction.EvaluateArgs.NativeFunction == NativeFunctions.NotSet)
                throw new InvalidOperationException("Please call a native SQL function first.");

            if (nativeSqlFunction.EvaluateArgs.QueryRestriction == QueryRestrictions.NotSet)
                throw new InvalidOperationException("Please apply a restriction on the SQL function.");

            IProjection projection = ApplyProjection.ApplySqlFunc(property, nativeSqlFunction);
            return ApplyRestriction.Apply(nativeSqlFunction, projection);
        }
    }
}