﻿using System;
using NHibernate;
using NUnit.Framework;
using QueryOverSqlFuncsExts.Tests.Helper;
using QueryOverSqlFuncsExts.Tests.Model;

namespace QueryOverSqlFuncsExts.Tests
{
    public class TestEvaluateMethod : NhTestBase
    {
        #region Methods (24)

        // Public Methods (21) 

        [Test]
        public virtual void TestAbs()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                  .Where(x => x.Balance.Evaluate(new SqlFunc().Abs().IsEqualTo(100)))
                                  .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestCharIndex()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                .Where(x => x.Name.Evaluate(new SqlFunc().CharIndex("a", 1).IsEqualTo(2)))
                                .List();
                    tx.Commit();

                    Assert.That(data.Count == 2);
                }
            }
        }

        [Test]
        public virtual void TestCoalesce()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.Name.Evaluate(new SqlFunc().Coalesce("--").IsEqualTo("Vahid")))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestConcat()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.Name.Evaluate(new SqlFunc().Concat("N").IsEqualTo("VahidN")))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestDay()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {

                    var data = session.QueryOver<Account>()
                                .Where(x => x.AddDate.Evaluate(new SqlFunc().Day().IsEqualTo(3)))
                                .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestDayIsBetween()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                .Where(x => x.AddDate.Evaluate(new SqlFunc().Day().IsBetween(2, 3)))
                                .List();
                    tx.Commit();

                    Assert.That(data.Count == 2);
                }
            }
        }

        [Test]
        public virtual void TestDayIsNotNull()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                .Where(x => x.AddDate.Evaluate(new SqlFunc().Day().IsNotNull()))
                                .List();
                    tx.Commit();

                    Assert.That(data.Count == 2);
                }
            }
        }

        [Test]
        public virtual void TestDayIsNull()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                .Where(x => x.AddDate.Evaluate(new SqlFunc().Day().IsNull()))
                                .List();
                    tx.Commit();

                    Assert.That(data.Count == 0);
                }
            }
        }

        [Test]
        public virtual void TestHour()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.AddDate.Evaluate(new SqlFunc().Hour().IsEqualTo(4)))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestLength()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                  .Where(x => x.Name.Evaluate(new SqlFunc().Length().IsEqualTo(5)))
                                  .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestMinute()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.AddDate.Evaluate(new SqlFunc().Minute().IsEqualTo(5)))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestMod()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                          .Where(x => x.Balance.Evaluate(new SqlFunc().Mod(10).IsEqualTo(0)))
                          .List();
                    tx.Commit();

                    Assert.That(data.Count == 2);
                }
            }
        }

        [Test]
        public virtual void TestMonth()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.AddDate.Evaluate(new SqlFunc().Month().IsEqualTo(3)))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 0);
                }
            }
        }

        [Test]
        public virtual void TestSecond()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.AddDate.Evaluate(new SqlFunc().Second().IsEqualTo(5)))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestSqrt()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.Balance.Evaluate(new SqlFunc().Sqrt().IsEqualTo(10)))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestSubstring()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                 .Where(x => x.Name.Evaluate(new SqlFunc().Substring(1, 2).IsEqualTo("Va")))
                                 .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestSubstringIsIn()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                .Where(x => x.Name.Evaluate(new SqlFunc().Substring(1, 2).IsIn(new[] { "Va", "Na", "a" })))
                                .List();
                    tx.Commit();

                    Assert.That(data.Count == 2);
                }
            }
        }

        [Test]
        public virtual void TestToLower()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                   .Where(x => x.Name.Evaluate(new SqlFunc().ToLower().IsEqualTo("vahid")))
                                   .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestToUpper()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                   .Where(x => x.Name.Evaluate(new SqlFunc().ToUpper().IsEqualTo("VAHID")))
                                   .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }

        [Test]
        public virtual void TestYear()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                    .Where(x => x.AddDate.Evaluate(new SqlFunc().Year().IsEqualTo(2010)))
                                    .List();
                    tx.Commit();

                    Assert.That(data.Count == 2);
                }
            }
        }

        [Test]
        public virtual void Trim()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    var data = session.QueryOver<Account>()
                                  .Where(x => x.Name.Evaluate(new SqlFunc().Trim().IsEqualTo("Vahid")))
                                  .List();
                    tx.Commit();

                    Assert.That(data.Count == 1);
                }
            }
        }
        // Protected Methods (2) 

        protected override void OnRunAfterAllTests()
        {
            base.OnRunAfterAllTests();
        }

        protected override void OnRunBeforeAllTests()
        {
            base.OnRunBeforeAllTests();
            addSomeRecordsFirst();
        }
        // Private Methods (1) 

        private void addSomeRecordsFirst()
        {
            using (ISession session = SessionFactory.OpenSession())
            {
                using (ITransaction tx = session.BeginTransaction())
                {
                    session.Save(new Account
                    {
                        AddDate = new DateTime(2010, 1, 2, 3, 4, 5),
                        Balance = 100,
                        Name = "Vahid"
                    });

                    session.Save(new Account
                    {
                        AddDate = new DateTime(2010, 2, 3, 4, 5, 6),
                        Balance = 200,
                        Name = "Nasiri"
                    });

                    tx.Commit();
                }
            }
        }

        #endregion Methods
    }
}
