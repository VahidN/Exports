﻿using FluentNHibernate.Automapping;
using FluentNHibernate.Cfg;
using FluentNHibernate.Cfg.Db;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using NUnit.Framework;
using QueryOverSqlFuncsExts.Tests.Model;

namespace QueryOverSqlFuncsExts.Tests.Helper
{
    public class NhTestBase
    {
        protected ISessionFactory SessionFactory;

        private void config()
        {
            //Creating tables, mappings, sessionFactory, etc.
            var dbType = MsSqlConfiguration.MsSql2008.ShowSql().FormatSql()
                            .ConnectionString("Data Source=(local);Initial Catalog=testdb;Integrated Security=true");
            var cfg = dbType.ConfigureProperties(new Configuration());
            var autoPM = new AutoPersistenceModel()
                 .Where(x => x.Namespace.EndsWith("Model"))
                 .AddEntityAssembly(typeof(Account).Assembly);
            autoPM.Configure(cfg);
            new SchemaExport(cfg).SetOutputFile("db.sql").Create(true, true);
            SessionFactory = Fluently.Configure().Database(dbType)
                                     .Mappings(m => m.AutoMappings.Add(autoPM).ExportTo(System.Environment.CurrentDirectory))
                                     .BuildSessionFactory();

            //Registering our extension method, otherwise NH knows nothing about it.
            RegistrExt.RegistrMyQueryOverExts();
        }

        [TestFixtureSetUp]
        public void RunBeforeAllTests()
        {
            config();
            OnRunBeforeAllTests();
        }

        protected virtual void OnRunBeforeAllTests()
        {
        }

        [TestFixtureTearDown]
        public void RunAfterAllTests()
        {
            SessionFactory.Close();
            OnRunAfterAllTests();
        }

        protected virtual void OnRunAfterAllTests()
        {
        }

        [SetUp]
        public void RunBeforeEachTest()
        {
            OnRunBeforeEachTest();
        }

        protected virtual void OnRunBeforeEachTest()
        {
        }


        [TearDown]
        public void RunAfterEachTest()
        {
            OnRunAfterEachTest();
        }

        protected virtual void OnRunAfterEachTest()
        {
        }
    }
}
