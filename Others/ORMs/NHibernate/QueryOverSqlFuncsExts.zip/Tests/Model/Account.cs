﻿using System;

namespace QueryOverSqlFuncsExts.Tests.Model
{
    public class Account
    {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual int Balance { set; get; }
        public virtual DateTime AddDate { set; get; }
    }
}
