﻿using System;
using NHibernate.Criterion;
using NHibernate;

namespace QueryOverSqlFuncsExts
{
    public class ApplyProjection
    {
        public static IProjection ApplySqlFunc(string property, SqlFunc nativeSqlFunction)
        {
            IProjection projection;
            switch (nativeSqlFunction.EvaluateArgs.NativeFunction)
            {
                case NativeFunctions.Year:
                    projection = Projections.SqlFunction("year", NHibernateUtil.DateTime, Projections.Property(property));
                    break;

                case NativeFunctions.Day:
                    projection = Projections.SqlFunction("day", NHibernateUtil.DateTime, Projections.Property(property));
                    break;

                case NativeFunctions.Month:
                    projection = Projections.SqlFunction("month", NHibernateUtil.DateTime, Projections.Property(property));
                    break;

                case NativeFunctions.Hour:
                    projection = Projections.SqlFunction("hour", NHibernateUtil.DateTime, Projections.Property(property));
                    break;

                case NativeFunctions.Minute:
                    projection = Projections.SqlFunction("minute", NHibernateUtil.DateTime, Projections.Property(property));
                    break;

                case NativeFunctions.Second:
                    projection = Projections.SqlFunction("second", NHibernateUtil.DateTime, Projections.Property(property));
                    break;

                case NativeFunctions.Sqrt:
                    projection = Projections.SqlFunction("sqrt", NHibernateUtil.Double, Projections.Property(property));
                    break;

                case NativeFunctions.ToLower:
                    projection = Projections.SqlFunction("lower", NHibernateUtil.String, Projections.Property(property));
                    break;

                case NativeFunctions.ToUpper:
                    projection = Projections.SqlFunction("upper", NHibernateUtil.String, Projections.Property(property));
                    break;

                case NativeFunctions.Abs:
                    projection = Projections.SqlFunction("abs", NHibernateUtil.Object, Projections.Property(property));
                    break;

                case NativeFunctions.Trim:
                    projection = Projections.SqlFunction("trim", NHibernateUtil.String, Projections.Property(property));
                    break;

                case NativeFunctions.Length:
                    projection = Projections.SqlFunction("length", NHibernateUtil.Int32, Projections.Property(property));
                    break;

                case NativeFunctions.BitLength:
                    projection = Projections.SqlFunction("bit_length", NHibernateUtil.Int32, Projections.Property(property));
                    break;

                case NativeFunctions.Substring:
                    object startIndex = nativeSqlFunction.EvaluateArgs.Args[0];
                    object length = nativeSqlFunction.EvaluateArgs.Args[1];
                    projection = Projections.SqlFunction("substring", NHibernateUtil.String, Projections.Property(property), Projections.Constant(startIndex), Projections.Constant(length));
                    break;

                case NativeFunctions.CharIndex:
                    object theChar = nativeSqlFunction.EvaluateArgs.Args[0];
                    object startLocation = nativeSqlFunction.EvaluateArgs.Args[1];
                    projection = Projections.SqlFunction("locate", NHibernateUtil.Int32, Projections.Constant(theChar), Projections.Property(property), Projections.Constant(startLocation));
                    break;

                case NativeFunctions.Coalesce:
                    object replaceValueIfIsNull = nativeSqlFunction.EvaluateArgs.Args[0];
                    projection = Projections.SqlFunction("coalesce", NHibernateUtil.Object, Projections.Property(property), Projections.Constant(replaceValueIfIsNull));
                    break;

                case NativeFunctions.Concat:
                    object concatWithValue = nativeSqlFunction.EvaluateArgs.Args[0];
                    projection = Projections.SqlFunction("concat", NHibernateUtil.String, Projections.Property(property), Projections.Constant(string.Empty), Projections.Constant(concatWithValue));
                    break;

                case NativeFunctions.Mod:
                    object divisor = nativeSqlFunction.EvaluateArgs.Args[0];
                    projection = Projections.SqlFunction("mod", NHibernateUtil.Int32, Projections.Property(property), Projections.Constant(divisor));
                    break;

                default:
                    throw new NotSupportedException("Using unsupported sql function, please revise your code.");
            }
            return projection;
        }
    }
}
