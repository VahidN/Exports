﻿namespace QueryOverSqlFuncsExts
{
    public enum NativeFunctions
    {
        /// <summary>
        /// Default value
        /// </summary>
        NotSet,
        Year,
        Month,
        Day,
        Hour,
        Minute,
        Second,
        Sqrt,
        ToLower,
        ToUpper,
        Abs,
        Trim,
        Length,
        BitLength,
        Substring,
        CharIndex,
        Coalesce,
        Concat,
        Mod
    }
}