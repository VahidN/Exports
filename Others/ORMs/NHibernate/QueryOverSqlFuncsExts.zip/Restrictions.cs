﻿using System.Collections;

namespace QueryOverSqlFuncsExts
{
    public class Restrictions<TParent>
    {
        #region Fields (2)

        private readonly EvaluateArgs _evaluateArgs;
        private readonly TParent _parent;

        #endregion Fields

        #region Constructors (1)

        public Restrictions(TParent parent, EvaluateArgs evaluateArgs)
        {
            _evaluateArgs = evaluateArgs;
            _parent = parent;
        }

        #endregion Constructors

        #region Methods (12)

        // Public Methods (12) 

        public TParent IsBetween(object lo, object hi)
        {
            _evaluateArgs.QueryRestrictionValues.Add(lo);
            _evaluateArgs.QueryRestrictionValues.Add(hi);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Between;
            return _parent;
        }

        public TParent IsEqualTo(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Eq;
            return _parent;
        }

        public TParent IsGreaterThan(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Gt;
            return _parent;
        }

        public TParent IsGreaterThanOrEqualTo(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Ge;
            return _parent;
        }

        public TParent IsIn(ICollection values)
        {
            _evaluateArgs.QueryRestrictionValues.Add(values);
            _evaluateArgs.QueryRestriction = QueryRestrictions.In;
            return _parent;
        }

        public TParent IsInsensitiveLike(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.InsensitiveLike;
            return _parent;
        }

        public TParent IsLessThan(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Lt;
            return _parent;
        }

        public TParent IsLessThanOrEqualTo(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Le;
            return _parent;
        }

        public TParent IsLike(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Like;
            return _parent;
        }

        public TParent IsNot(object val)
        {
            _evaluateArgs.QueryRestrictionValues.Add(val);
            _evaluateArgs.QueryRestriction = QueryRestrictions.Not;
            return _parent;
        }

        public TParent IsNotNull()
        {
            _evaluateArgs.QueryRestriction = QueryRestrictions.IsNotNull;
            return _parent;
        }

        public TParent IsNull()
        {
            _evaluateArgs.QueryRestriction = QueryRestrictions.IsNull;
            return _parent;
        }

        #endregion Methods
    }
}