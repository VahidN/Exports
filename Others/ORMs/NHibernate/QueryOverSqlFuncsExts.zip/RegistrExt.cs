﻿using NHibernate.Impl;

namespace QueryOverSqlFuncsExts
{
    public class RegistrExt
    {
        public static bool _isRegistered;
        public static void RegistrMyQueryOverExts()
        {
            if (_isRegistered) return;
            ExpressionProcessor.RegisterCustomMethodCall(() => QueryOverExt.Evaluate(null, null), QueryOverExt.ProcessEvaluate);
            _isRegistered = true;
        }
    }
}
