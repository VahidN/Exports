﻿using System;
using NHibernate.Criterion;
using System.Collections;

namespace QueryOverSqlFuncsExts
{
    class ApplyRestriction
    {
        public static ICriterion Apply(SqlFunc nativeSqlFunction, IProjection projection)
        {
            switch (nativeSqlFunction.EvaluateArgs.QueryRestriction)
            {
                case QueryRestrictions.Eq:
                    return Restrictions.Eq(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.Ge:
                    return Restrictions.Ge(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.Gt:
                    return Restrictions.Gt(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.Le:
                    return Restrictions.Le(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.Lt:
                    return Restrictions.Lt(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.Not:
                    return !Restrictions.Eq(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.Like:
                    return Restrictions.Like(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.InsensitiveLike:
                    return Restrictions.InsensitiveLike(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.In:
                    return Restrictions.In(projection, (ICollection)nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0]);

                case QueryRestrictions.Between:
                    return Restrictions.Between(projection, nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[0], nativeSqlFunction.EvaluateArgs.QueryRestrictionValues[1]);

                case QueryRestrictions.IsNotNull:
                    return Restrictions.IsNotNull(projection);

                case QueryRestrictions.IsNull:
                    return Restrictions.IsNull(projection);

                default:
                    throw new NotSupportedException("Using unsupported restriction type, please revise your code.");
            }
        }
    }
}
