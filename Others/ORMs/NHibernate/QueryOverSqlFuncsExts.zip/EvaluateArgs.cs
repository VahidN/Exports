﻿using System.Collections;

namespace QueryOverSqlFuncsExts
{
    public class EvaluateArgs
    {
        #region Constructors (1)

        public EvaluateArgs()
        {
            Args = new ArrayList();
            QueryRestrictionValues = new ArrayList();
        }

        #endregion Constructors

        #region Properties (4)

        public ArrayList Args { set; get; }

        public NativeFunctions NativeFunction { get; set; }

        public QueryRestrictions QueryRestriction { get; set; }

        public ArrayList QueryRestrictionValues { get; set; }

        #endregion Properties
    }
}