﻿using System.Collections.Generic;
using NHibernate.Validator.Constraints;

namespace NH32AutoMap.Models
{
    public class Product : BaseEntity
    {
        public Product()
        {
            Orders = new List<Order>();
        }

        [Length(Max = 450)]
        [NotNullNotEmpty]
        public virtual string Name { set; get; }
        
        public virtual IList<Order> Orders { set; get; } // Many-to-many Association        
    }
}
