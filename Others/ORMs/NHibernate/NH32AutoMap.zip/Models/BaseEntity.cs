﻿
namespace NH32AutoMap.Models
{
    public class BaseEntity
    {
        public virtual int Id { set; get; }
    }
}
