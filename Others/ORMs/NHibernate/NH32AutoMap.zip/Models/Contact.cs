﻿using NHibernate.Validator.Constraints;

namespace NH32AutoMap.Models
{
    public class Contact : Address // Base-type as an inheritance strategy
    {
        [Length(Max = 200)]
        [NotNullNotEmpty]
        public virtual string Email { set; get; }

        [Length(Max = 50)]
        public virtual string Mobile { set; get; }

        [Length(Max = 50)]
        public virtual string Phone { set; get; }
    }
}