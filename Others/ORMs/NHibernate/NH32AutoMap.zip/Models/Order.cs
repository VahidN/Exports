﻿using System;
using System.Collections.Generic;
using NHibernate.Validator.Constraints;

namespace NH32AutoMap.Models
{
    public class Order : BaseEntity
    {
        public Order()
        {
            Products = new List<Product>();
            Customer = new Customer();
        }

        [NotNull]
        public virtual DateTime DateTime { set; get; }

        [NotNull]
        public virtual Customer Customer { set; get; } // Many-to-one Association        

        public virtual IList<Product> Products { set; get; } // Many-to-many Association        
    }
}
