﻿using NHibernate.Validator.Constraints;

namespace NH32AutoMap.Models
{
    public class InterestComponent
    {
        [Length(Max = 450)]
        public virtual string Interest1 { get; set; }

        [Length(Max = 450)]
        public virtual string Interest2 { get; set; }
    }
}
