﻿using System.Collections.Generic;
using NHibernate.Validator.Constraints;

namespace NH32AutoMap.Models
{
    public class Customer : BaseEntity
    {
        public Customer()
        {
            Orders = new List<Order>();
            Address = new Address();
            RelatedCustomers = new List<Customer>();
        }

        [Length(Max = 450)]
        [NotNullNotEmpty]
        public virtual string Name { set; get; }

        [NotNull]
        public virtual Level Level { set; get; }

        [NotNull]
        public virtual Address Address { set; get; } // Many-to-one Association

        public virtual InterestComponent Interest { set; get; } // Component mapping

        public virtual IList<Order> Orders { set; get; } // One-to-many Association

        public virtual IList<Customer> RelatedCustomers { set; get; } // A self-referencing object
    }
}
