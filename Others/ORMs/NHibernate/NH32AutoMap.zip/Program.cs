﻿using System;
using NH32AutoMap.Core;
using NH32AutoMap.Models;

namespace NH32AutoMap
{
    class Program
    {
        static void Main(string[] args)
        {
            var config = new NH32Config
            {
                ConnectionString = "Data Source=(local);Initial Catalog=testdb;Integrated Security = true",
                // It can be defined in another assembly.
                MappingsAssembly = typeof(Product).Assembly,
                MappingsNamespace = typeof(Product).Namespace,
                ValidationDefinitionsNamespace = typeof(Product).Namespace,
                ShowLogs = true,
                DropTablesCreateDbSchema = true,
                OutputXmlMappingsFile = "Mappings.xml",
                DbSchemaOutputFile = "Db.sql",
                // I want to ignore the base-type, Otherwise NHibernate would see the BaseEntity as an actual entity.
                BaseEntityToIgnore = typeof(BaseEntity),
                MapAllEnumsToStrings = true, // Otherwise Enums will be mapped to integers automatically.
                AutoMappingOverride = modelMapper =>
                {
                    modelMapper.BeforeMapProperty += (modelInspector, member, map) =>
                    {
                        // I want all of the "Name" fields to be unique.
                        if (member.LocalMember.Name.Equals("Name"))
                        {
                            map.Unique(true);
                        }
                    };
                }
            };

            var addresses = InMemoryDataSource.CreateAddresses();
            var customers = InMemoryDataSource.CreateCustomers(addresses);
            InMemoryDataSource.AddRelatedCustomers(customers);
            var products = InMemoryDataSource.CreateProducts();
            var orders = InMemoryDataSource.CreateOrders(customers, products);

            using (var sessionFactory = config.SetUpSessionFactory())
            {
                using (var session = sessionFactory.OpenSession())
                {
                    using (var tx = session.BeginTransaction())
                    {
                        // Save Products
                        foreach (var product in products)
                            session.SaveOrUpdate(product);

                        // Save Orders (also saves Customers and their Addresses & Contacts)
                        foreach (var order in orders)
                            session.SaveOrUpdate(order);

                        tx.Commit();
                    }
                }
            }

            Console.WriteLine("Press a key...");
            Console.Read();
        }
    }
}