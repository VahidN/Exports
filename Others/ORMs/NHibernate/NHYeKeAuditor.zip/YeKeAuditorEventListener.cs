﻿using NHibernate.Event;

namespace NHYeKeAuditor
{
    public class YeKeAuditorEventListener : IPreInsertEventListener, IPreUpdateEventListener
    {
        // Represents a pre-insert event, which occurs just prior to performing the
        // insert of an entity into the database.
        public bool OnPreInsert(PreInsertEvent preInsertEvent)
        {
            var entity = preInsertEvent.Entity;
            new CorrectYeKe(preInsertEvent.Persister, preInsertEvent.State).ApplyCorrectYeKe(entity);
            return false;
        }

        // Represents a pre-update event, which occurs just prior to performing the
        // update of an entity in the database.
        public bool OnPreUpdate(PreUpdateEvent preUpdateEvent)
        {
            var entity = preUpdateEvent.Entity;
            new CorrectYeKe(preUpdateEvent.Persister, preUpdateEvent.State).ApplyCorrectYeKe(entity);
            return false;
        }
    }
}
