﻿using System;
using System.Linq;
using System.Reflection;
using NHibernate.Persister.Entity;

namespace NHYeKeAuditor
{
    public class CorrectYeKe
    {
        readonly IEntityPersister _persister;
        readonly object[] _state;

        public CorrectYeKe(IEntityPersister persister, object[] state)
        {
            _persister = persister;
            _state = state;
        }

        public static string ApplyCorrectYeKe(string data)
        {
            if (string.IsNullOrEmpty(data)) return data;
            return data.Replace("ي", "ی").Replace("ك", "ک");
        }

        public void ApplyCorrectYeKe(object entity)
        {
            if (entity == null)
                return;

            //يافتن خواص قابل تنظيم و رشته‌اي اين موجوديت‌
            var propertyInfos = entity.GetType().GetProperties(
                BindingFlags.Public | BindingFlags.Instance
                ).Where(p => p.CanRead && p.CanWrite && p.PropertyType == typeof(string));

            var pr = new PropertyReflector();

            //اعمال يكپارچگي نهايي
            foreach (var propertyInfo in propertyInfos)
            {
                var propName = propertyInfo.Name;
                var val = pr.GetValue(entity, propName);
                if (val != null)
                {
                    var newVal = ApplyCorrectYeKe(val.ToString());
                    if (newVal == val.ToString()) continue;
                    //we have to update both the entity and the entity state
                    setState(propName, newVal);
                    pr.SetValue(entity, propName, newVal);
                }
            }
        }

        private void setState(string propertyName, object value)
        {
            var index = Array.IndexOf(_persister.PropertyNames, propertyName);
            if (index == -1)
                return;
            _state[index] = value;
        }
    }
}
