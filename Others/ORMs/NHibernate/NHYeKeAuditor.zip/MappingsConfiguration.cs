﻿using System;
using System.Linq;
using FluentNHibernate.Cfg;
using NHibernate.Cfg;

namespace NHYeKeAuditor
{
    public static class MappingsConfiguration
    {
        public static FluentConfiguration InjectYeKeAuditorEventListener(this FluentConfiguration fc)
        {
            return fc.ExposeConfiguration(configListeners());
        }

        private static Action<Configuration> configListeners()
        {
            return
                c =>
                {
                    var listener = new YeKeAuditorEventListener();
                    c.EventListeners.PreInsertEventListeners =
                        c.EventListeners.PreInsertEventListeners
                        .Concat(new[] { listener })
                        .ToArray();
                    c.EventListeners.PreUpdateEventListeners =
                        c.EventListeners.PreUpdateEventListeners
                        .Concat(new[] { listener })
                        .ToArray();
                };
        }
    }
}
