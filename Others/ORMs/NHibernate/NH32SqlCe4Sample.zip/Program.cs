﻿using System;
using System.Collections.Generic;
using NH32SqlCeSample.Core;
using NH32SqlCeSample.Models;

namespace NH32SqlCeSample
{
    class Program
    {
        static void Main(string[] args)
        {
            SqlCEDbHelper.CreateEmptyDatabaseFile("db.sdf", "1234");

            using (var sessionFactory = new NH32Config
                                        {
                                            ConnectionString = "Data Source=db.sdf;Password=1234;Encrypt Database=True"
                                        }.SetUp())
            {
                using (var session = sessionFactory.OpenSession())
                {
                    using (var tx = session.BeginTransaction())
                    {

                        var child1 = new Child { Id = 1, Name = "Child1", DOB = DateTime.Now.AddYears(10) };
                        var child2 = new Child { Id = 2, Name = "Child2", DOB = DateTime.Now.AddYears(11) };
                        var child3 = new Child { Id = 3, Name = "Child3", DOB = DateTime.Now.AddYears(12) };
                        var child4 = new Child { Id = 4, Name = "Child4", DOB = DateTime.Now.AddYears(13) };

                        var parent1 = new Parent { Id = 1, Name = "Parent1", DOB = DateTime.Now.AddYears(-13) };
                        var parent2 = new Parent { Id = 2, Name = "Parent2", DOB = DateTime.Now.AddYears(-12) };
                        var parent3 = new Parent { Id = 3, Name = "Parent3", DOB = DateTime.Now.AddYears(-11) };
                        var parent4 = new Parent { Id = 4, Name = "Parent4", DOB = DateTime.Now.AddYears(-10) };

                        parent1.Child.Add(child1);
                        parent1.Child.Add(child2);

                        parent3.Child.Add(child3);
                        parent3.Child.Add(child4);

                        var parents = new List<Parent> { parent1, parent2, parent3, parent4 };
                        var children = new List<Child> { child1, child2, child3, child4 };

                        foreach (var parent in parents)
                        {
                            session.SaveOrUpdate(parent);
                        }

                        foreach (var child in children)
                        {
                            session.SaveOrUpdate(child);
                        }

                        tx.Commit();
                    }

                    using (var session2 = sessionFactory.OpenSession())
                    {
                        using (var tx2 = session.BeginTransaction())
                        {
                            var cnt1 = session2.QueryOver<Parent>().RowCount();
                            var cnt2 = session2.QueryOver<Child>().RowCount();
                            Console.WriteLine(cnt1);
                            Console.WriteLine(cnt2);

                            tx2.Commit();
                        }
                    }
                }
            }

            Console.WriteLine("Press a key...");
            Console.Read();
        }
    }
}
