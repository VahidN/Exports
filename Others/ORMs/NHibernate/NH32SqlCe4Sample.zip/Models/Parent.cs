﻿using System;
using System.Collections.Generic;
using NHibernate.Mapping.ByCode.Conformist;

namespace NH32SqlCeSample.Models
{
    public class Parent
    {
        public Parent()
        {
            Child = new List<Child>();
        }

        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual DateTime? DOB { set; get; }
        public virtual IList<Child> Child { set; get; }
    }

    public class ParentMap : ClassMapping<Parent>
    {
        public ParentMap()
        {
            Id(x => x.Id);
            Property(x => x.Name);
            Property(x => x.DOB);
            Bag(x => x.Child, cp => { }, cr => cr.OneToMany(x => x.Class(typeof(Child))));
        }
    }
}
