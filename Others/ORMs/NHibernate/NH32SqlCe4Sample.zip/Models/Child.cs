﻿using System;
using NHibernate.Mapping.ByCode.Conformist;

namespace NH32SqlCeSample.Models
{
    public class Child
    {
        public virtual int Id { get; set; }
        public virtual string Name { get; set; }
        public virtual DateTime? DOB { set; get; }
        public virtual Parent Parent { set; get; }
    }

    public class ChildMap : ClassMapping<Child>
    {
        public ChildMap()
        {
            Id(x => x.Id);
            Property(x => x.Name);
            Property(x => x.DOB);
            ManyToOne(x => x.Parent);
        }
    }
}
