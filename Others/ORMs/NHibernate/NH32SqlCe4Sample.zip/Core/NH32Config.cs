﻿using System;
using System.Data;
using NH32SqlCeSample.Models;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Cfg.MappingSchema;
using NHibernate.Connection;
using NHibernate.Dialect;
using NHibernate.Driver;
using NHibernate.Mapping.ByCode;
using NHibernate.Tool.hbm2ddl;

namespace NH32SqlCeSample.Core
{
    class NH32Config
    {
        #region Properties (1)

        public string ConnectionString { set; get; }

        #endregion Properties

        #region Methods (4)

        // Public Methods (1) 

        public ISessionFactory SetUp()
        {
            var config = getConfig();
            var mapping = getMappings();
            config.AddDeserializedMapping(mapping, "NHSchemaTest");
            var sessionFactory = config.BuildSessionFactory();
            createDbSchema(config);
            return sessionFactory;
        }
        // Private Methods (3) 

        private void createDbSchema(Configuration cfg)
        {
            new SchemaExport(cfg).SetOutputFile("db.sql").Create(true, true);
        }

        private Configuration getConfig()
        {
            var configure = new Configuration();
            configure.SessionFactoryName("BuildIt");

            configure.DataBaseIntegration(db =>
            {
                db.ConnectionProvider<DriverConnectionProvider>();
                db.Dialect<MsSqlCe40Dialect>();
                db.Driver<SqlServerCeDriver>();
                db.KeywordsAutoImport = Hbm2DDLKeyWords.AutoQuote;
                db.IsolationLevel = IsolationLevel.ReadCommitted;
                db.ConnectionString = ConnectionString;
                db.Timeout = 10;

                //for testing ...
                db.LogFormattedSql = true;
                db.LogSqlInConsole = true;
            });

            return configure;
        }

        private static HbmMapping getMappings()
        {
            var mapper = new ModelMapper();
            mapper.AddMapping<ChildMap>();
            mapper.AddMapping<ParentMap>();
            var mapping = mapper.CompileMappingFor(new[] { typeof(Parent), typeof(Child) });
            //Output XML mappings
            Console.WriteLine(mapping.AsString());
            return mapping;
        }

        #endregion Methods
    }
}