﻿using System;
using System.Data.Entity;
using EF_Sample35.DataLayer;

namespace EF_Sample35
{
    class Program
    {
        static void Main(string[] args)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<Sample35Context, Configuration>());

            using (var db = new Sample35Context())
            {
                var customer1 = db.Customers.Find(1);
                if (customer1 != null)
                {
                    Console.WriteLine(customer1.FirstName);
                }
            } 
        }
    }
}
