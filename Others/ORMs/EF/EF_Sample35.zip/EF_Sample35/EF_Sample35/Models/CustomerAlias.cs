﻿
namespace EF_Sample35.Models
{
    public class CustomerAlias
    {
        public int Id { get; set; }        
        public string Aka { get; set; }

        public virtual Customer Customer { get; set; }
    }
}
