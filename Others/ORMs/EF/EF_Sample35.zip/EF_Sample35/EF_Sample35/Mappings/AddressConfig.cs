﻿using System.Data.Entity.ModelConfiguration;
using EF_Sample35.Models;

namespace EF_Sample35.Mappings
{
    public class AddressConfig : EntityTypeConfiguration<Address>
    {
        public AddressConfig()
        {            
        }
    }
}
