﻿using System.ComponentModel.DataAnnotations;

namespace EF_Sample05.DomainClasses.Models
{
    //[Table("Players")] // for TPT
    public class Player : Person
    {
        public int Number { get; set; }        
        public string Description { get; set; }
    }
}
