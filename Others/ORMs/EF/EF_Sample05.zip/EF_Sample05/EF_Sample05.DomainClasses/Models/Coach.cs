﻿using System.ComponentModel.DataAnnotations;

namespace EF_Sample05.DomainClasses.Models
{
    //[Table("Coaches")] // for TPT
    public class Coach : Person
    {
        public string TeamName { set; get; }        
    }
}
