﻿using System.Data.Entity.Migrations;

namespace EF_Sample05.DataLayer.Context
{
    public class Configuration : DbMigrationsConfiguration<Sample05Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(Sample05Context context)
        {
            base.Seed(context);
        }
    }
}
