﻿using System.Data.Entity;
using EF_Sample05.DomainClasses.Models;
using EF_Sample05.DataLayer.Mappings;

namespace EF_Sample05.DataLayer.Context
{
    public class Sample05Context : DbContext
    {
        public DbSet<Person> People { set; get; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new PersonConfig());
            modelBuilder.Configurations.Add(new CoachConfig());
            modelBuilder.Configurations.Add(new PlayerConfig());
            base.OnModelCreating(modelBuilder);
        }
    }
}
