﻿using System;
using System.Linq;
using System.Data.Entity;
using EF_Sample05.DataLayer.Context;
using EF_Sample05.DomainClasses.Models;

namespace EF_Sample05
{
    class Program
    {
        static void Main(string[] args)
        {
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<Sample05Context, Configuration>());

            using (var db = new Sample05Context())
            {
                db.People.Add(new Coach { Id = 1, FirstName = "Coach F1", LastName = "Coach L1", DateOfBirth = DateTime.Now.AddYears(-50), TeamName = "Team A" });
                db.People.Add(new Coach { Id = 2, FirstName = "Coach F2", LastName = "Coach L2", DateOfBirth = DateTime.Now.AddYears(-50), TeamName = "Team B" });
                db.People.Add(new Player { Id = 3, Number = 1, Description = "...", FirstName = "Coach F1", LastName = "Coach L1", DateOfBirth = DateTime.Now.AddYears(-50) });
                db.SaveChanges();
            }

            using (var db = new Sample05Context())
            {
                var coach1 = db.People.OfType<Coach>().FirstOrDefault(x => x.LastName == "Coach L1");
                if (coach1 != null)
                {
                    Console.WriteLine(coach1.FirstName);
                }
            }

            using (var db = new Sample05Context())
            {
                var person1 = db.People.Find(1);
                if (person1 != null)
                {
                    Console.WriteLine(person1.FirstName);
                }
            }
        }
    }
}
