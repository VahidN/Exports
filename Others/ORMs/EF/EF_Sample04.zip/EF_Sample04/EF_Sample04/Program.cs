﻿using System;
using System.Data.Entity;
using EF_Sample04.DataLayer;
using EF_Sample04.Models;

namespace EF_Sample04
{
    class Program
    {
        static void Main(string[] args)
        {
            Database.SetInitializer<Sample04Context>(null);
            Database.SetInitializer(new MigrateDatabaseToLatestVersion<Sample04Context, Configuration>());

            using (var db = new Sample04Context())
            {
                var manager = new Employee
                {
                    FirstName = "man1",
                    LastName = "man1"
                };

                var emp1 = new Employee
                {
                    FirstName = "emp1",
                    LastName = "emp1",
                    Manager = manager
                };

                var emp2 = new Employee
                {
                    FirstName = "emp2",
                    LastName = "emp2",
                    Manager = emp1
                };

                db.Employees.Add(emp1);
                db.Employees.Add(emp2);
                db.SaveChanges();
            }

            using (var db = new Sample04Context())
            {
                foreach (var item in db.EmployeesView)
                {
                    Console.WriteLine(item.FirstName);
                }
            }

            using (var db = new Sample04Context())
            {
                db.ActivityTypes.Add(new ActivityType { UserId = 1, ActivityID = 15 });
                db.SaveChanges();
            }

            using (var db = new Sample04Context())
            {
                var activity1 = db.ActivityTypes.Find(15, 1);
                if (activity1 != null)
                {
                    Console.WriteLine(activity1.UserId);
                }
            }
        }
    }
}
