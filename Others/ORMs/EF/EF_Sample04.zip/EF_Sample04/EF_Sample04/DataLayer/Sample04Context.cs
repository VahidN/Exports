﻿using System.Data.Entity;
using System.Data.Entity.Migrations;
using EF_Sample04.Mappings;
using EF_Sample04.Models;

namespace EF_Sample04.DataLayer
{
    public class Sample04Context : DbContext
    {
        public DbSet<ActivityType> ActivityTypes { set; get; }
        public DbSet<Employee> Employees { set; get; }
        public DbSet<MyXMLTable> MyXMLTable { set; get; }
        public DbSet<EmployeesView> EmployeesView { set; get; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new ActivityTypeConfig());
            modelBuilder.Configurations.Add(new EmployeeConfig());
            base.OnModelCreating(modelBuilder);
        }
    }

    public class Configuration : DbMigrationsConfiguration<Sample04Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(Sample04Context context)
        {
            base.Seed(context);
        }
    }
}
