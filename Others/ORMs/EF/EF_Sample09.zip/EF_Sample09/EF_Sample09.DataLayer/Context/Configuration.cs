﻿using System.Data.Entity.Migrations;

namespace EF_Sample09.DataLayer.Context
{
    public class Configuration : DbMigrationsConfiguration<Sample09Context>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = true;
            AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(Sample09Context context)
        {
            base.Seed(context);
        }
    }
}
