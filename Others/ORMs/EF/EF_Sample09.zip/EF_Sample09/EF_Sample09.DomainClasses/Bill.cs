﻿using System;

namespace EF_Sample09.DomainClasses
{
    public class Bill : BaseEntity
    {
        public decimal Amount { set; get; }        
        public string Description { get; set; }

        public virtual Payee Payee { get; set; }
    }
}
