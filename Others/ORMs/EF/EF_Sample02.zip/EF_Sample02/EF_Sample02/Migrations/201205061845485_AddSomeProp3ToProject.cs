namespace EF_Sample02.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class AddSomeProp3ToProject : DbMigration
    {
        public override void Up()
        {
            AddColumn("Projects", "SomeProp3", c => c.String(defaultValue: "some data"));
            Sql("Update Projects set SomeProp3=N'some data'");
        }
        
        public override void Down()
        {
            DropColumn("Projects", "SomeProp3");
        }
    }
}
