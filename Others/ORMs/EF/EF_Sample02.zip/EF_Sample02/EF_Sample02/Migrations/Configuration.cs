namespace EF_Sample02.Migrations
{
    using System;
    using System.Data.Entity.Migrations;

    using EF_Sample02.DataLayer;

    internal sealed class Configuration : DbMigrationsConfiguration<Sample2Context>
    {
        public Configuration()
        {
            this.AutomaticMigrationsEnabled = false;
            this.AutomaticMigrationDataLossAllowed = true;
        }

        protected override void Seed(Sample2Context context)
        {
            context.Users.AddOrUpdate(
                 a => a.Name,
                 new Models.User { Name = "Vahid", AddDate = DateTime.Now },
                 new Models.User { Name = "Vahid", AddDate = DateTime.Now });
        }
    }
}
