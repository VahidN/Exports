namespace EF_Sample02.Migrations
{
    using System.Data.Entity.Migrations;
    
    public partial class AddSomeProp5ToProject : DbMigration
    {
        public override void Up()
        {
            AddColumn("Projects", "SomeProp5", c => c.String());
        }
        
        public override void Down()
        {
            DropColumn("Projects", "SomeProp5");
        }
    }
}
