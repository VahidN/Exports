﻿using System;
using System.Data.Entity;

namespace EF_Sample02
{
    using EF_Sample02.DataLayer;

    class Program
    {
        static void Main(string[] args)
        {
            //Database.SetInitializer(new Sample2DbInitializer());
            //Database.SetInitializer(new MigrateDatabaseToLatestVersion<Sample2Context, Migrations.Configuration>());
            //SimpleDbMigrations.UpdateDatabaseSchema<Sample2Context>();
            
            using (var db = new Sample2Context())
            {
                var project1 = db.Projects.Find(1);
                Console.WriteLine(project1.Title);

                //delete
                /*var user = db.Users.Find(1);
                //user.Name = "User name 1";
                db.Users.Remove(user);
                db.SaveChanges();*/
            } 
        }
    }
}
