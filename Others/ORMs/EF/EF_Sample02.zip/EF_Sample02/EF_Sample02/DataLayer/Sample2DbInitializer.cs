namespace EF_Sample02.DataLayer
{
    using System;
    using System.Collections.Generic;
    using System.Data.Entity;

    using EF_Sample02.Models;

    public class Sample2DbInitializer : DropCreateDatabaseAlways<Sample2Context>
    {
        protected override void Seed(Sample2Context context)
        {
            context.Users.Add(new User
                {
                    AddDate = DateTime.Now,
                    Name = "Vahid",
                    LastName = "N.",
                    Email = "name@site.com",
                    Description = "-",
                    AdminProjects = new List<Project>
                        {
                            new Project
                                {
                                    Title = "Project 1",
                                    AddDate = DateTime.Now.AddDays(-10),
                                    Description = "..."
                                }
                        }
                });

            base.Seed(context);
        }
    }
}