﻿namespace EF_Sample02.DataLayer
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Data.Entity.Migrations.Infrastructure;
    using System.IO;

    public class Configuration<T> : DbMigrationsConfiguration<T> where T : DbContext
    {
        public Configuration()
        {
            this.AutomaticMigrationsEnabled = true;
            this.AutomaticMigrationDataLossAllowed = true;
        }
    }

    public class SimpleDbMigrations
    {
        public static void UpdateDatabaseSchema<T>(string sqlScriptPath = "script.sql") where T : DbContext
        {
            var configuration = new Configuration<T>();
            var dbMigrator = new DbMigrator(configuration);
            saveToFile(sqlScriptPath, dbMigrator);
            dbMigrator.Update();
        }

        private static void saveToFile(string sqlScriptPath, MigratorBase dbMigrator)
        {
            if (string.IsNullOrWhiteSpace(sqlScriptPath)) return;

            var scriptor = new MigratorScriptingDecorator(dbMigrator);
            var script = scriptor.ScriptUpdate(sourceMigration: null, targetMigration: null);
            File.WriteAllText(sqlScriptPath, script);
            Console.WriteLine(script);
        }
    }
}