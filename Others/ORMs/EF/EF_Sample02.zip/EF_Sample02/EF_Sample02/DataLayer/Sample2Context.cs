﻿namespace EF_Sample02.DataLayer
{
    using System.Data.Entity;
    using EF_Sample02.Models;

    public class Sample2Context : DbContext
    {
        public DbSet<User> Users { set; get; }
        public DbSet<Project> Projects { set; get; }
    }
}
