﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace EF_Sample02.Models
{
    public class User
    {
        //[DatabaseGenerated(DatabaseGeneratedOption.Computed)]
        public int Id { set; get; }
        public DateTime? AddDate { set; get; }

        [ConcurrencyCheck]
        public string Name { set; get; }

        public string LastName { set; get; }

        [NotMapped]
        public string FullName
        {
            get { return Name + " " + LastName; }
        }

        public string Email { set; get; }
        public string Description { set; get; }
        public byte[] Photo { set; get; }
        public IList<Project> AdminProjects { set; get; }
        
        [Timestamp]
        public byte[] RowVersion { set; get; }
                
        public InterestComponent Interests { set; get; }

        public User()
        {
            Interests = new InterestComponent();
        }
    }
}
