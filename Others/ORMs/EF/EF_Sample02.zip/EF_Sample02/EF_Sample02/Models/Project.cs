﻿using System;
using System.ComponentModel.DataAnnotations;

namespace EF_Sample02.Models
{
    //[Table("tblProject", Schema = "guest")]
    public class Project 
    {
        public int Id { set; get; }

        [Column("DateStarted", Order = 4, TypeName = "date")]
        public DateTime? AddDate { set; get; }

        [MaxLength(50, ErrorMessage = "حداكثر 50 حرف"), MinLength(4, ErrorMessage = "حداقل 4 حرف")]
        public string Title { set; get; }
                
        public string Description { set; get; }

        //[ForeignKey("FK_User_Id")]
        public virtual User AdminUser { set; get; }
        //public int FK_User_Id { set; get; }

        public string SomeProp { set; get; }
        public string SomeProp2 { set; get; }
        public string SomeProp3 { set; get; }
        public string SomeProp5 { set; get; }

        [Timestamp]
        public byte[] RowVesrion { set; get; } 
    }
}
