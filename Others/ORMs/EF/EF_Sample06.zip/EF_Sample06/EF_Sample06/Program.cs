﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Xml;
using EF_Sample06.DataLayer;
using EF_Sample06.Models;

namespace EF_Sample06
{
    class Program
    {
        static IList<Employee> FindEmployees(string fName, string lName, bool byName, bool byLName)
        {
            using (var db = new Sample06Context())
            {
                IQueryable<Employee> query = db.Employees.AsQueryable();

                if (byLName)
                {
                    query = query.Where(x => x.LastName == lName);
                }

                if (byName)
                {
                    query = query.Where(x => x.FirstName == fName);
                }

                return query.ToList();
            }
        }

        static void ExportMappings(DbContext context, string edmxFile)
        {
            var settings = new XmlWriterSettings { Indent = true };
            using (XmlWriter writer = XmlWriter.Create(edmxFile, settings))
            {
                System.Data.Entity.Infrastructure.EdmxWriter.WriteEdmx(context, writer);
            }
        }

        static void Main(string[] args)
        {
            // note: remove this line if you received : CreateDatabase is not supported by the provider.
            HibernatingRhinos.Profiler.Appender.EntityFramework.EntityFrameworkProfiler.Initialize();

            Database.SetInitializer(new MigrateDatabaseToLatestVersion<Sample06Context, Configuration>());

            exportMappings();
            testFindEmployees();
            testLazyLoading();
            testEagerLoading();
            testNPlus1Error();
            
        }

        private static void testEagerLoading()
        {
            using (var db = new Sample06Context())
            {
                foreach (var dept in db.Departments.Include(x => x.Employees))
                {
                    Console.WriteLine(dept.Name);
                    foreach (var item in dept.Employees)
                    {
                        Console.WriteLine(item.FirstName);
                    }
                }
            }
        }

        private static void testNPlus1Error()
        {
            using (var db = new Sample06Context())
            {
                foreach (var dept in db.Departments)
                {
                    Console.WriteLine(dept.Name);
                    foreach (var item in dept.Employees)
                    {
                        Console.WriteLine(item.FirstName);
                    }
                }
            }
        }

        private static void testLazyLoading()
        {
            using (var db = new Sample06Context())
            {
                var dept1 = db.Departments.Find(1);
                if (dept1 != null)
                {
                    Console.WriteLine(dept1.Name);
                    foreach (var item in dept1.Employees)
                    {
                        Console.WriteLine(item.FirstName);
                    }
                }
            }
        }

        private static void testFindEmployees()
        {
            var list = FindEmployees("f name1", "l name1", true, true);
            foreach (var item in list)
            {
                Console.WriteLine(item.FirstName + " - " + item.LastName);
            }
        }

        private static void exportMappings()
        {
            using (var db = new Sample06Context())
            {
                ExportMappings(db, "mappings.edmx");
            }
        }
    }
}
