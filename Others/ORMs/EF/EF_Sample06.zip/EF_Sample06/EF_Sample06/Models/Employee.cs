﻿
namespace EF_Sample06.Models
{
    public class Employee
    {
        public int EmployeeId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }        

        //Creates Department navigation property for Lazy Loading
        public virtual Department Department { get; set; }
    }
}
