﻿using System.Data.Entity;
using EF_Sample06.Models;

namespace EF_Sample06.DataLayer
{
    public class Sample06Context : DbContext
    {
        public Sample06Context()
        {
            // disable lazy loading for all entities
            //this.Configuration.LazyLoadingEnabled = false;
        }

        public DbSet<Department> Departments { set; get; }
        public DbSet<Employee> Employees { set; get; }
    }
}
