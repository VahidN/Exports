namespace EF_Sample01.DataLayer
{
    using System.Data.Entity;
    using EF_Sample01.Models;

    public class MyCustomInitializer : DropCreateDatabaseIfModelChanges<Context>
    {
        protected override void Seed(Context context)
        {
            context.Blogs.Add(new Blog { AuthorName = "Vahid", Title = ".NET Tips" });
            context.Database.ExecuteSqlCommand("CREATE INDEX IX_title ON tblBlogs (title)");
            base.Seed(context);
        }
    }
}