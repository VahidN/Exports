﻿namespace EF_Sample01.DataLayer
{
    using System.Data.Entity;
    using EF_Sample01.Mappings;
    using EF_Sample01.Models;

    public class Context : DbContext
    {
        //public Context()
        //    : base("name=EF_Sample01_Db")
        //{}

        public DbSet<Blog> Blogs { set; get; }
        public DbSet<Post> Posts { set; get; }

        public override int SaveChanges()
        {
            return base.SaveChanges();
        }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add(new BlogConfig());
            modelBuilder.Entity<Blog>().ToTable("tblBlogs"/*, schemaName:"someUser"*/);
            modelBuilder.Entity<Blog>().Property(x => x.Id).HasColumnName("MyTableKey");
            modelBuilder.Entity<Blog>().Property(x => x.RowVersion).HasColumnType("Timestamp");
            /*modelBuilder.Entity<Blog>().HasKey(x => x.MyTableKey);
            modelBuilder.Entity<Blog>().Property(x => x.Title).HasMaxLength(100);
            modelBuilder.Entity<Blog>().Property(x => x.AuthorName).IsRequired();*/

            base.OnModelCreating(modelBuilder);
        }
    }
}
