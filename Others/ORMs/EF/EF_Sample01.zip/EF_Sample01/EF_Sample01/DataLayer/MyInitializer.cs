namespace EF_Sample01.DataLayer
{
    using System.Data.Entity;

    public class MyInitializer : IDatabaseInitializer<Context>
    {
        public void InitializeDatabase(Context context)
        {
            if (context.Database.Exists() ||
                context.Database.CompatibleWithModel(throwIfNoMetadata: false))
                context.Database.Delete();

            context.Database.Create();            
            context.Database.ExecuteSqlCommand("CREATE INDEX IX_title ON tblBlogs (title)");
        }
    }
}