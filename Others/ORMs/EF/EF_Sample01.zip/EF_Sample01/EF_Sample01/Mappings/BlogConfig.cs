namespace EF_Sample01.Mappings
{
    using System.Data.Entity.ModelConfiguration;
    using EF_Sample01.Models;

    public class BlogConfig : EntityTypeConfiguration<Blog>
    {
        public BlogConfig()
        {
            this.Property(x => x.Id).HasColumnName("MyTableKey");
            this.Property(x => x.RowVersion).HasColumnType("Timestamp");
        }
    }
}