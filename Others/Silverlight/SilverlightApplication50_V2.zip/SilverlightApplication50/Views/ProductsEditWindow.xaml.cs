﻿using GalaSoft.MvvmLight.Messaging;
using System.Windows.Controls;
using SilverlightApplication50.Models;

namespace SilverlightApplication50.Views
{
    public partial class ProductsEditWindow
    {
        void cleanUp()
        {
            Messenger.Default.Unregister<string>("CloseEdit");
            Messenger.Default.Unregister<Product>("edit product");
            Messenger.Default.Unregister<Product>("doEdit");
        }

        public ProductsEditWindow()
        {
            cleanUp();

            Messenger.Default.Register<string>(
                "CloseEdit",
                x =>
                {
                    this.Close();

                    this.txtDescription.GetBindingExpression(TextBox.TextProperty).UpdateSource();
                    this.txtQuantity.GetBindingExpression(TextBox.TextProperty).UpdateSource();

                    cleanUp();
                });

            InitializeComponent();
        }
    }
}

