﻿using System.Collections.ObjectModel;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using SilverlightApplication50.Models;

namespace SilverlightApplication50.ViewModels
{
    public class ProductsViewModel
    {
        public ProductsViewModel()
        {
            //Add some dummy products
            Items = new ObservableCollection<Product>
              {
                   new Product { Description="Product #1", Quantity=12},
                   new Product { Description="Product #2", Quantity=42},
                   new Product { Description="Product #3", Quantity=7}
              };

            //Respond to the events
            EditCommand = new RelayCommand<Product>(
                product => //selected item
                {
                    if (product == null) return;
                    Messenger.Default.Send(product, "edit product");
                });
        }


        public ObservableCollection<Product> Items { get; private set; }

        public RelayCommand<Product> EditCommand
        {
            get;
            private set;
        }
    }
}
