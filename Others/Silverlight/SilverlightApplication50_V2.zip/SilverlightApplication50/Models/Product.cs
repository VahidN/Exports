﻿using System.ComponentModel;

namespace SilverlightApplication50.Models
{
    public class Product : INotifyPropertyChanged
    {
        private int _quantity;
        public int Quantity
        {
            set
            {
                _quantity = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("Quantity");
            }
            get { return _quantity; }
        }

        private string _description;
        public string Description
        {
            set
            {
                _description = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("Description");
            }
            get { return _description; }
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;
        private void onPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null) return;
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
