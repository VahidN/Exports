﻿using System;
using System.ComponentModel;

namespace SilverlightApplication73.Models
{
    public class Book : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        public void OnPropertyChanged(string propertyName)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private string _title;
        private string _author;
        private int _pageCount;
        private DateTime _purchaseDate;
        private Category _category;
        private string _publisher;
        private Languages _language;
        private string _imageName;
        private bool _alreadyRead;

        public string Title
        {
            get { return _title; }
            set
            {
                _title = value;
                OnPropertyChanged("Title");
            }
        }
        public string Author
        {
            get { return _author; }
            set
            {
                _author = value;
                OnPropertyChanged("Author");
            }
        }
        public int PageCount
        {
            get { return _pageCount; }
            set
            {
                _pageCount = value;
                OnPropertyChanged("PageCount");
            }
        }
        public DateTime PurchaseDate
        {
            get { return _purchaseDate; }
            set
            {
                _purchaseDate = value;
                OnPropertyChanged("PurchaseDate");
            }
        }
        public Category Category
        {
            get { return _category; }
            set
            {
                _category = value;
                OnPropertyChanged("Category");
            }
        }
        public string Publisher
        {
            get{ return _publisher; }
            set
            {
                _publisher = value;
                OnPropertyChanged("Publisher");
            }
        }
        public Languages Language
        {
            get { return _language; }
            set
            {
                _language = value;
                OnPropertyChanged("Language");
            }
        }
        public string ImageName
        {
            get { return _imageName; }
            set
            {
                _imageName = value;
                OnPropertyChanged("ImageName");
            }
        }
        public bool AlreadyRead
        {
            get { return _alreadyRead; }
            set
            {
                _alreadyRead = value;
                OnPropertyChanged("AlreadyRead");
            }
        }
    }
}
