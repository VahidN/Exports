﻿namespace SilverlightApplication73.Models
{
    public enum Category
    {
        Thriller,
        Fiction,
        Comics,
        Computing,
        Biography
    }
}
