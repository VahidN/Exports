﻿namespace SilverlightApplication73.Models
{
    public enum Languages
    {
        English,
        Persian,
        Dutch,
        French,
        German
    }
}
