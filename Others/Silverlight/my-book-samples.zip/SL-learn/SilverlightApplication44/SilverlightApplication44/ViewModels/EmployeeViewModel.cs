﻿using System;
using System.Windows.Threading;
using SilverlightApplication44.Models;

namespace SilverlightApplication44.ViewModels
{
    public class EmployeeViewModel
    {
        public Employee Employee { set; get; }

        public EmployeeViewModel()
        {
            this.Employee = new Employee
                                {
                                    Name = "Vahid",
                                    Salary = 1000
                                };

            startTimer();
        }
        
        //create a timer in Silverlight
        private void startTimer()
        {
            var myDispatcherTimer =
                new DispatcherTimer
                    {
                        // 1000 Milliseconds 
                        Interval = new TimeSpan(0, 0, 0, 0, 1000)
                    };
            myDispatcherTimer.Tick += eachTick;
            myDispatcherTimer.Start();
        }

        void eachTick(object o, EventArgs sender)
        {
            Employee.Salary += 10;
        }
    }
}
