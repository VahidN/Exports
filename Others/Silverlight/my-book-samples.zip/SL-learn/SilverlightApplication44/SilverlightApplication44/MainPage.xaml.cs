﻿using SilverlightApplication44.ViewModels;

namespace SilverlightApplication44
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            this.DataContext = new EmployeeViewModel();
        }
    }
}
