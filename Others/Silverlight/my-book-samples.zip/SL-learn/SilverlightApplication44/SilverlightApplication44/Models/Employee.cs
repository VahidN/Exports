﻿using System.ComponentModel;

namespace SilverlightApplication44.Models
{
    public class Employee : INotifyPropertyChanged
    {
        string _name;
        public string Name
        {
            get { return _name; }
            set
            {
                if (_name == value) return;
                _name = value;
                raisePropertyChanged("Name");
            }
        }

        int _salary;
        public int Salary
        {
            get { return _salary; }
            set
            {
                if (_salary == value) return;
                _salary = value;
                raisePropertyChanged("Salary");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        void raisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler == null) return;
            handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
