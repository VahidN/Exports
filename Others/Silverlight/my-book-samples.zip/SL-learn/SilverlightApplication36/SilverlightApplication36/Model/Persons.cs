﻿using System.Collections.Generic;

namespace SilverlightApplication36.Model
{
    public class Persons : List<Person>
    {
        public Persons()
        {
            this.Add(new Person
                         {
                             FirstName = "Albert",
                             LastName = "Einstein",
                             Gender = "M",
                             ScienceGroup = "Physicist"
                         });
            this.Add(new Person
                         {
                             FirstName = "Marie",
                             LastName = "Curie ",
                             Gender = "F",
                             ScienceGroup = "Chemist"
                         });
            this.Add(new Person
                         {
                             FirstName = "Daniel ",
                             LastName = "Bernoulli",
                             Gender = "F",
                             ScienceGroup = "Physicist"
                         });

            this.Add(new Person
                         {
                             FirstName = "Rachel",
                             LastName = "Carson",
                             Gender = "F",
                             ScienceGroup = "Biologist"
                         });
            this.Add(new Person
                         {
                             FirstName = "Linus",
                             LastName = "Pauling",
                             Gender = "M",
                             ScienceGroup = "Chemist"
                         });
        }
    }
}
