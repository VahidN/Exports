﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using SilverlightApplication36.Model;

namespace SilverlightApplication36
{
    public partial class GroupingData
    {
        public GroupingData()
        {
            InitializeComponent();
            Loaded += MainPage_Loaded;
        }

        PagedCollectionView _pagedView;
        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            // get the underlying source 
            _pagedView = new PagedCollectionView(new Persons());

            _pagedView.GroupDescriptions.Add(
                new PropertyGroupDescription("ScienceGroup"));

            personGrid.ItemsSource = _pagedView;
        }

        private void GroupNames_SelectionChanged(
            object sender, SelectionChangedEventArgs e)
        {
            if (_pagedView == null) return;
            // comment this next line out to see
            // adding additional groupings.
            _pagedView.GroupDescriptions.Clear();
            var selectedItem = (ComboBoxItem)GroupNames.SelectedItem;

            _pagedView.GroupDescriptions.Add(
                new PropertyGroupDescription(
                    selectedItem.Content.ToString()));
        }
    }
}
