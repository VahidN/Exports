﻿using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace WordProcessorContract
{
    [InheritedExport]
    public interface IWordProcessorPlugin
    {
        RichTextBox RichTextBox { set; }
    }
}
