﻿using System;
using System.Collections.Generic;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using System.Windows;
using System.Windows.Controls;
using WordProcessorContract;

namespace SilverlightApplication103
{
    public partial class MainPage : IPartImportsSatisfiedNotification
    {
        [ImportMany(AllowRecomposition = true)]
        public IEnumerable<IWordProcessorPlugin> Plugins { set; get; }

        public MainPage()
        {
            InitializeComponent();
            initialize();
        }

        private void initialize()
        {
            var pluginXap = new Uri("WordProcessorPlugins.xap", UriKind.Relative);
            var deploymentCatalog = new DeploymentCatalog(pluginXap);
            deploymentCatalog.DownloadAsync();

            var container = new CompositionContainer(deploymentCatalog);
            CompositionHost.Initialize(container);
            CompositionInitializer.SatisfyImports(this);
        }

        #region IPartImportsSatisfiedNotification Members

        public void OnImportsSatisfied()
        {
            PluginPanel.Children.Clear();

            foreach (var plugin in Plugins)
            {
                if (plugin is UserControl)
                {
                    plugin.RichTextBox = textBox;
                    var uc = plugin as UserControl;
                    uc.Margin = new Thickness(2);
                    PluginPanel.Children.Add(uc);
                }
            }
        }

        #endregion
    }
}
