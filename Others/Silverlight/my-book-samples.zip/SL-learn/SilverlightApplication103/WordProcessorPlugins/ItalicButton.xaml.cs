﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using WordProcessorContract;

namespace WordProcessorPlugins
{
    public partial class ItalicButton : IWordProcessorPlugin
    {
        public ItalicButton()
        {
            InitializeComponent();
        }

        #region IWordProcessorPlugin Members
        private RichTextBox _richTextBox;

        public RichTextBox RichTextBox
        {
            set
            {
                _richTextBox = value;
            }
        }
        #endregion

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (_richTextBox == null) return;
            _richTextBox.Selection.ApplyPropertyValue(
               TextElement.FontStyleProperty,
                FontStyles.Italic);
        }
    }
}
