﻿using System.Runtime.Serialization;

namespace SilverlightApplication60.Web
{
    [DataContract]
    public class Product
    {
        [DataMember]
        public int ProductId { get; set; }
        [DataMember]
        public string ProductName { get; set; }
    }
}