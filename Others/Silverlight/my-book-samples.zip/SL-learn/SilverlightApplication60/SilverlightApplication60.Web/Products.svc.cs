﻿using System;
using System.Collections.Generic;
using System.ServiceModel.Activation;

namespace SilverlightApplication60.Web
{
    [AspNetCompatibilityRequirements(RequirementsMode
        = AspNetCompatibilityRequirementsMode.Allowed)]
    public class Products : IProductServiceContract
    {
        public List<Product> GetProductsList(out MyFaultContract myFault)
        {
            List<Product> result = null;
            myFault = null;

            try
            {
                result = new List<Product>
                    {
                        new Product
                            {
                                ProductId = 1,
                                ProductName = "CD"
                            },
                        new Product
                            {
                                ProductId = 2,
                                ProductName = "DVD"
                            },
                        new Product
                            {
                                ProductId = 3,
                                ProductName = "RAM"
                            }
                    };

                //ex...
                throw new NullReferenceException("Table not found");
            }
            catch (Exception ex)
            {
                myFault = new MyFaultContract
                              {
                                  FaultType = ex.GetType().FullName,
                                  Message = ex.Message
                              };
            }

            return result;
        }
    }
}