﻿using System.Collections.Generic;
using System.ServiceModel;

namespace SilverlightApplication60.Web
{
    [ServiceContract]
    public interface IProductServiceContract
    {
        [OperationContract]
        List<Product> GetProductsList(out MyFaultContract myFault);
    }
}