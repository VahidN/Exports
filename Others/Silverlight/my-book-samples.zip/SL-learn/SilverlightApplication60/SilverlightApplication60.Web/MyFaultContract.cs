﻿using System.Runtime.Serialization;

namespace SilverlightApplication60.Web
{
    [DataContract]
    public class MyFaultContract
    {
        [DataMember]
        public string FaultType { get; set; }

        [DataMember]
        public string Message { get; set; }
    }
}