﻿using System.Collections.ObjectModel;
using SilverlightApplication60.ProductsService;

namespace SilverlightApplication60.ViewModels
{
    public class ProductsViewModel
    {
        public ObservableCollection<Product> ProductsList { set; get; }

        public ProductsViewModel()
        {
            ProductsList = new ObservableCollection<Product>();
            loadData();
        }

        private void loadData()
        {
            var srv = new ProductServiceContractClient();
            srv.GetProductsListCompleted += srv_GetProductsListCompleted;
            srv.GetProductsListAsync();
        }

        void srv_GetProductsListCompleted(object sender,
            GetProductsListCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                //TODO: Show a general error msg 
            }
            else if(e.myFault!=null)
            {
                //TODO: log  e.myFault.FaultType + "\n" + e.myFault.Message;
            }
            else
            {
                foreach (var product in e.Result)
                {
                    ProductsList.Add(product);
                }
            }
        }
    }
}
