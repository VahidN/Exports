﻿using System;
using System.Net.NetworkInformation;

namespace SilverlightApplication60
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            NetworkChange.NetworkAddressChanged += NetworkChanged;
        }

        private void NetworkChanged(object sender, EventArgs e)
        {
            if (NetworkInterface.GetIsNetworkAvailable())
            {
                // Currently online.
            }
            else
            {
                // Currently offline.
            }
        }
    }
}
