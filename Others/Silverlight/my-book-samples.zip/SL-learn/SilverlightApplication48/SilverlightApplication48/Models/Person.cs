﻿using System.ComponentModel;

namespace SilverlightApplication48.Models
{
    public class Person : INotifyPropertyChanged
    {
        #region Fields (3)

        private int _age;
        private string _firstName;
        private string _lastName;

        #endregion Fields

        #region Properties (3)

        public int Age
        {
            set
            {
                _age = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("Age");
            }
            get { return _age; }
        }

        public string FirstName
        {
            set
            {
                _firstName = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("FirstName");
            }
            get { return _firstName; }
        }

        public string LastName
        {
            set
            {
                _lastName = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("LastName");
            }
            get { return _lastName; }
        }

        #endregion Properties

        #region Delegates and Events (1)

        // Events (1) 

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Delegates and Events

        #region Methods (1)

        // Private Methods (1) 

        private void onPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null) return;
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion Methods
    }

}
