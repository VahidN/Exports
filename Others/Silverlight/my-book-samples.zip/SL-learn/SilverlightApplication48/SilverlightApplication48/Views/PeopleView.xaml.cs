﻿namespace SilverlightApplication48.Views
{
    public partial class PeopleView
    {
        public PeopleView()
        {
            InitializeComponent();
        }
    }
}
