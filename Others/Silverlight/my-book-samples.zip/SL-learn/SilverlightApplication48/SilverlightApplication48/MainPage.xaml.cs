﻿namespace SilverlightApplication48
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
