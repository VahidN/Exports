﻿using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Windows.Input;
using SilverlightApplication48.Helper;
using SilverlightApplication48.Models;

namespace SilverlightApplication48.ViewModels
{
    public class PeopleViewModel : INotifyPropertyChanged
    {
        #region Fields (2)
        
        private Person _currentPerson;
        private readonly ObservableCollection<Person> _people;

        #endregion Fields

        #region Constructors (1)

        public PeopleViewModel()
        {
            SelectedPerson = new Person();

            _people = new ObservableCollection<Person>
                         {
                new Person { Age = 53, FirstName = "P1", LastName = "L1" },
                new Person { Age = 30, FirstName = "P2", LastName = "L2" },
                new Person { Age = 26, FirstName = "P3", LastName = "L3" },
            };

            DecreaseCommand = new DelegateCommand<Person>(decrease, canDecrease);
            IncreaseCommand = new DelegateCommand<Person>(increase, canIncrease);
        }

        #endregion Constructors

        #region Properties (4)

        public ICommand DecreaseCommand { set; get; }

        public ICommand IncreaseCommand { set; get; }

        public ObservableCollection<Person> People
        {
            get { return _people; }
        }

        public Person SelectedPerson
        {
            set
            {
                _currentPerson = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("SelectedPerson");
            }
            get { return _currentPerson; }
        }

        #endregion Properties

        #region Delegates and Events (1)

        // Events (1) 

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Delegates and Events

        #region Methods (5)

        // Private Methods (5) 

        static bool canDecrease(Person person)
        {
            return person != null && person.Age > 0;
        }

        static bool canIncrease(Person person)
        {
            return person != null && person.Age < 60;
        }

        static void decrease(Person person)
        {
            if (person == null) return;
            person.Age--;
        }

        static void increase(Person person)
        {
            if (person == null) return;
            person.Age++;
        }

        private void onPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null) return;
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion Methods
    }
}
