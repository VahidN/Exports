﻿namespace SilverlightApplication51.Views
{
    public partial class TweetsList
    {
        public TweetsList()
        {
            InitializeComponent();
        }
    }
}
