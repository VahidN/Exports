﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Net;
using System.ServiceModel.Syndication;
using System.Xml;
//add a ref. to System.ServiceModel.Syndication

namespace SilverlightApplication51.Models
{
    public class LoadFeed
    {

        public IList<Tweet> TweetList { set; get; }
        public event EventHandler LoadComplete;

        public void LoadTweets(string url)
        {
            var wc = new WebClient();
            wc.OpenReadCompleted += wc_OpenReadCompleted;
            var feedUri = new Uri(url, UriKind.Absolute);
            wc.OpenReadAsync(feedUri);
        }

        private void wc_OpenReadCompleted(object sender, OpenReadCompletedEventArgs e)
        {
            if (e.Error != null)
            {
                //Error in Reading Feed. Try Again later!!
                return;
            }

            using (Stream s = e.Result)
            {
                SyndicationFeed feed;
                TweetList = new List<Tweet>();

                using (XmlReader reader = XmlReader.Create(s))
                {
                    feed = SyndicationFeed.Load(reader);
                    foreach (SyndicationItem item in feed.Items)
                    {
                        TweetList.Add(
                            new Tweet
                                {
                                    CreatedAt = item.PublishDate.DateTime,
                                    Text = item.Summary.Text
                                }
                            );
                    }
                }
            }

            LoadComplete.Invoke(sender,e);
        }
    }
}
