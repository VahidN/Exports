﻿using System;

namespace SilverlightApplication51.Models
{
    public class Tweet
    {
        public DateTime CreatedAt { get; set; }
        public string Text { get; set; }
    }
}
