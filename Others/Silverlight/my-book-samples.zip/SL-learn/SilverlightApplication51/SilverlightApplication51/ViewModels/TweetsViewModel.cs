﻿using System;
using System.Collections.ObjectModel;
using System.ComponentModel;
using GalaSoft.MvvmLight;
using GalaSoft.MvvmLight.Command;
using SilverlightApplication51.Models;

namespace SilverlightApplication51.ViewModels
{
    public class TweetsViewModel : INotifyPropertyChanged
    {
        private readonly ObservableCollection<Tweet> _tweetItems =
            new ObservableCollection<Tweet>();

        public ObservableCollection<Tweet> TweetItems
        {
            get
            {
                return _tweetItems;
            }
        }

        public TweetsViewModel()
        {
            DoFetch = new RelayCommand<string>(loadTweetItems);

            if (ViewModelBase.IsInDesignModeStatic)
            {
                _tweetItems.Add(new Tweet { Text = "Item1", CreatedAt = DateTime.Now });
                _tweetItems.Add(new Tweet { Text = "Item2", CreatedAt = DateTime.Now });
                _tweetItems.Add(new Tweet { Text = "Item3", CreatedAt = DateTime.Now });
                _tweetItems.Add(new Tweet { Text = "Item4", CreatedAt = DateTime.Now });
                _tweetItems.Add(new Tweet { Text = "Item5", CreatedAt = DateTime.Now });
            }
        }

        public RelayCommand<string> DoFetch { get; private set; }

        private LoadFeed _loadFeed;
        void loadTweetItems(string url)
        {
            if (string.IsNullOrEmpty(url)) return;

            BusyIndicatorIsBusy = true;

            _loadFeed = new LoadFeed();
            _loadFeed.LoadComplete += tweetItems_LoadComplete;
            _loadFeed.LoadTweets(url);
        }

        void tweetItems_LoadComplete(object sender, EventArgs e)
        {
            if (_loadFeed.TweetList == null) return;
            _tweetItems.Clear();
            foreach (var tweetItem in _loadFeed.TweetList)
            {
                _tweetItems.Add(tweetItem);
            }

            BusyIndicatorIsBusy = false;
        }

        private bool _busyIndicatorIsBusy;
        public bool BusyIndicatorIsBusy
        {
           set
            {
                _busyIndicatorIsBusy = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("BusyIndicatorIsBusy");
            }
            get { return _busyIndicatorIsBusy; }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        private void onPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null) return;
            PropertyChanged(this, 
                  new PropertyChangedEventArgs(propertyName));
        }
    }
}
