﻿namespace SilverlightApplication66.Web
{
    public class SecurityManager
    {
        public static bool Authenticate(
                string username, string password)
        {
            //منطق اعتبار سنجي سفارشي خود را در اينجا پياده سازي نمائيد
            return username == password;
        }
    }
}