﻿using System;

namespace SilverlightApplication66.Web
{
    public partial class _default : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Redirect("SilverlightApplication66TestPage.aspx");
        }
    }
}