﻿using System;
using System.Web.Security;
using System.Web.UI.WebControls;

namespace SilverlightApplication66.Web
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
        }

        protected void ctrlLogin_Authenticate(object sender, 
            AuthenticateEventArgs e)
        {
            if (SecurityManager.Authenticate(
                ctrlLogin.UserName, ctrlLogin.Password))
            {
                //authenticated
                FormsAuthentication.RedirectFromLoginPage(
                    ctrlLogin.UserName, ctrlLogin.RememberMeSet);
            }
        }
    }
}