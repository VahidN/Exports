﻿using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Web;

namespace SilverlightApplication66.Web
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode 
        = AspNetCompatibilityRequirementsMode.Allowed)]
    public class TestService
    {
        [OperationContract]
        public string GetAuthenticationType()
        {
            return HttpContext.Current.User.Identity.AuthenticationType;
        }

        [OperationContract]
        public string GetLoggedUser()
        {
            return HttpContext.Current.User.Identity.Name;
        }
    }
}
