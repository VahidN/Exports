﻿using System.ComponentModel;

namespace SilverlightApplication66.Model
{
    public class ServiceInfo : INotifyPropertyChanged
    {
        string _authenticationType;
        public string AuthenticationType
        {
            get { return _authenticationType; }
            set
            {
                if (_authenticationType == value) return;
                _authenticationType = value;
                raisePropertyChanged("AuthenticationType");
            }
        }

        string _identityName;
        public string IdentityName
        {
            get { return _identityName; }
            set
            {
                if (_identityName == value) return;
                _identityName = value;
                raisePropertyChanged("IdentityName");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        void raisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler == null) return;
            handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
