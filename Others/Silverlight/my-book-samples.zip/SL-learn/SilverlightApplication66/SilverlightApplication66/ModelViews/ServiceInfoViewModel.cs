﻿using System.Windows.Input;
using SilverlightApplication66.Helper;
using SilverlightApplication66.Model;
using SilverlightApplication66.TestServiceReference;

namespace SilverlightApplication66.ModelViews
{
    public class ServiceInfoViewModel
    {
        public ServiceInfoViewModel()
        {
            ServiceInfo = new ServiceInfo();
            GetLoggedInUserName = new DelegateCommand<ServiceInfo>(
                getLoggedInUserName, canGetLoggedInUserName);
            GetAuthType = new DelegateCommand<ServiceInfo>(
                getAuthType, canGetAuthType);
        }

        public ICommand GetAuthType { set; get; }

        public ICommand GetLoggedInUserName { set; get; }

        public ServiceInfo ServiceInfo { set; get; }

        private bool canGetAuthType(ServiceInfo arg)
        {
            return true;
        }

        private bool canGetLoggedInUserName(ServiceInfo arg)
        {
            return true;
        }

        private void getAuthType(ServiceInfo obj)
        {
            var srv = new TestServiceClient();
            srv.GetAuthenticationTypeCompleted += srv_GetAuthenticationTypeCompleted;
            srv.GetAuthenticationTypeAsync();
        }

        private void getLoggedInUserName(ServiceInfo obj)
        {
            var srv = new TestServiceClient();
            srv.GetLoggedUserCompleted += srv_GetLoggedUserCompleted;
            srv.GetLoggedUserAsync();
        }

        void srv_GetAuthenticationTypeCompleted(object sender,
            GetAuthenticationTypeCompletedEventArgs e)
        {
            if (e.Error == null)
                ServiceInfo.AuthenticationType = e.Result;
        }

        void srv_GetLoggedUserCompleted(object sender,
            GetLoggedUserCompletedEventArgs e)
        {
            if (e.Error == null)
                ServiceInfo.IdentityName = e.Result;
        }
    }
}
