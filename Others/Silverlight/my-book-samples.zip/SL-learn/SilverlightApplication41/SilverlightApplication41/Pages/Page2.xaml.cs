﻿using System;
using System.Windows;
using System.Windows.Navigation;

namespace SilverlightApplication41.Pages
{
    public partial class Page2
    {
        public Page2()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void btnGotoPage1_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(
                new Uri("/Page1", UriKind.Relative)
                );
        }
    }
}
