﻿using System;
using System.Windows;
using System.Windows.Navigation;

namespace SilverlightApplication41.Pages
{
    public partial class Page1
    {
        public Page1()
        {
            InitializeComponent();
        }

        // Executes when the user navigates to this page.
        protected override void OnNavigatedTo(NavigationEventArgs e)
        {
        }

        private void btnGotoPage2_Click(object sender, RoutedEventArgs e)
        {
            this.NavigationService.Navigate(
                new Uri("/Page2", UriKind.Relative)
                );
        }
    }
}
