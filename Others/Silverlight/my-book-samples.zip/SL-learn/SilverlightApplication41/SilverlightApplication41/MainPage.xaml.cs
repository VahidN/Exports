﻿using System;
using System.Windows;
using SilverlightApplication41.UserControls;

namespace SilverlightApplication41
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnContent_Click(object sender, RoutedEventArgs e)
        {
            frame1.Content = new BlueUserControl();
        }

        private void btnNavigation_Click(object sender, RoutedEventArgs e)
        {
            frame1.Navigate(new Uri("/UserControls/BlueUserControl.xaml", 
                UriKind.Relative));
        }

        private void frame1_NavigationFailed(object sender, 
            System.Windows.Navigation.NavigationFailedEventArgs e)
        {
            e.Handled = true;
        }
    }
}
