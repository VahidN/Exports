﻿namespace SilverlightApplication41.UserControls
{
    public partial class BlueUserControl
    {
        public BlueUserControl()
        {
            InitializeComponent();
        }
    }
}
