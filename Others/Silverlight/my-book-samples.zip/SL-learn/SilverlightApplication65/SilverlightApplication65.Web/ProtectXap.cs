﻿using System;
using System.Web;

namespace SilverlightApplication65.Web
{
    public class ProtectXap : IHttpModule
    {
        public void Dispose()
        { }

        public void Init(HttpApplication context)
        {
            context.EndRequest += context_EndRequest;
        }

        static void context_EndRequest(object sender, EventArgs e)
        {
            var app = (HttpApplication)sender;
            HttpContext context = app.Context;

            if (context.Request.Url.AbsolutePath.ToUpper().Contains(".XAP"))
            {
                if (context.User == null ||
                    context.User.Identity.IsAuthenticated == false)
                    context.Response.Redirect(
                        "login.aspx?ReturnUrl=" + context.Request.Url);
            }
        }
    }
}