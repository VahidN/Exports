﻿using System;
using System.Web.Security;

namespace SilverlightApplication65.Web
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //just for test...
            FormsAuthentication.RedirectFromLoginPage("Vahid", false);
        }
    }
}