﻿using System.Windows;
using System.Windows.Input;

namespace SilverlightApplication24
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += InCodeBehind_Loaded;
        }

        void InCodeBehind_Loaded(object sender, RoutedEventArgs e)
        {
            demoShape.MouseLeftButtonUp += shape_Handler;
            //or ...
            demoShape.AddHandler(MouseLeftButtonUpEvent,
                                 new MouseButtonEventHandler(shape_Handler),
                                 false);

            demoButton1.Click += demoButton1_Click;
        }

        void demoButton1_Click(object sender, RoutedEventArgs e)
        {
            resultTextBlock.Text = "Button.";
        }

        void shape_Handler(object sender, MouseButtonEventArgs e)
        {
            resultTextBlock.Text = "Shape.";
        }
    }
}
