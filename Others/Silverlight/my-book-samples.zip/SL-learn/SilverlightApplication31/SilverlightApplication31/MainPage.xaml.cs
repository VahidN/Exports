﻿using System.Collections.Generic;
using System.Windows;

namespace SilverlightApplication31
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            var days = new List<string>
                                    {
                                        "Monday", "Tuesday", 
                                        "Wednesday", "Thursday", 
                                        "Friday", "Saturday", "Sunday"
                                    };
            autoCompleteBox.ItemsSource = days;
        }

        private void getSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            string selected = selectionTextbox.SelectedText;
            simpleTextBox.Text = selected;
        }

        private void setSelectedButton_Click(object sender, RoutedEventArgs e)
        {
            selectionTextbox.Focus();
            selectionTextbox.Select(12, 30);
        }

        private void selectAllButton_Click(object sender, RoutedEventArgs e)
        {
            selectionTextbox.Focus();
            selectionTextbox.SelectAll();
        }

        private void selectByStringButton_Click(object sender, RoutedEventArgs e)
        {
            selectionTextbox.Focus();
            if (selectionTextbox.SelectionLength > 0)
            {
                selectionTextbox.SelectedText = "dolor sit amet";
            }
        }
    }
}
