﻿namespace SilverlightApplication68.CustomValidations
{
    public class MyValidations
    {
        /*
         Usage: 
         [CustomValidation(typeof(MyValidations), "UnitsValidation")]
         public int UnitsOnOrder; 
         */
        public static bool UnitsValidation(int units)
        {
            return units < 100;
        }
    }
}
