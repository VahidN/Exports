﻿using System;
using System.ComponentModel;
using SilverlightApplication68.Helper;

namespace SilverlightApplication68.Models
{
    public class Employee1 : INotifyPropertyChanged

    {
        private string _name = string.Empty;
        public string Name
        {
            get { return _name; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Name is required");
                }

                if (_name != value)
                {
                    _name = value;
                    PropertyChanged.Raise(() => Name);
                }
            }
        }

        private int _age;
        public int Age
        {
            get { return _age; }
            set
            {
                if (value > 60 || value<25)
                {
                    throw new ArgumentException("Age should be between 25-60");
                }

                if (_age != value)
                {
                    _age = value;
                    PropertyChanged.Raise(() => Age);
                }
            }
        }


        private string _email = string.Empty;
        public string Email
        {
            get { return _email; }
            set
            {
                if (string.IsNullOrEmpty(value))
                {
                    throw new ArgumentException("Email is required");
                }

                if (!value.Contains("@") && !value.Contains("."))
                {
                    throw new ArgumentException("Email is Invalid");
                }

                if (_email != value)
                {
                    _email = value;
                    PropertyChanged.Raise(() => Email);
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

    }
}
