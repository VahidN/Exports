﻿using System.ComponentModel;
using SilverlightApplication68.Helper;

namespace SilverlightApplication68.Models
{
    public class Employee : INotifyPropertyChanged, IDataErrorInfo
    {
        private string _name = string.Empty;
        public string Name
        {
            get { return _name; }
            set
            {
                if (_name != value)
                {
                    _name = value;
                    PropertyChanged.Raise(() => Name);
                }
            }
        }

        private int _age;
        public int Age
        {
            get { return _age; }
            set
            {
                if (_age != value)
                {
                    _age = value;
                    PropertyChanged.Raise(() => Age);
                }
            }
        }


        private string _email = string.Empty;
        public string Email
        {
            get { return _email; }
            set
            {
                if (_email != value)
                {
                    _email = value;
                    PropertyChanged.Raise(() => Email);
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;


        #region IDataErrorInfo Members
        public string Error
        {
            get { return null; }
        }

        public string this[string columnName]
        {
            get
            {
                switch (columnName)
                {
                    case "Name":
                        if (string.IsNullOrEmpty(Name))
                            return "Name is required";

                        break;

                    case "Age":
                        if (Age > 60 || Age < 25)
                            return "Age should be between 25-60";

                        break;

                    case "Email":
                        if (string.IsNullOrEmpty(Email))
                        {
                            return "Email is required";
                        }

                        if (!Email.Contains("@") && !Email.Contains("."))
                        {
                            return "Email is Invalid";
                        }

                        break;
                    default:
                        break;
                }

                return string.Empty;
            }
        }
        #endregion
    }
}
