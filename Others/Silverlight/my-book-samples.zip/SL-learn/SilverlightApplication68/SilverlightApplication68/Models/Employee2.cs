﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using SilverlightApplication68.Helper;

namespace SilverlightApplication68.Models
{
    public class Employee2 : INotifyPropertyChanged
    {
        private string _name = string.Empty;
        [Required(ErrorMessage = "{0} is required.")]
        [StringLength(15, MinimumLength = 6,
            ErrorMessage = "{0} len must be between {1} and {2}")]
        public string Name
        {
            get { return _name; }
            set
            {
                if (_name != value)
                {
                    ValidationHelper.ValidateProperty(value, () => Name);
                    _name = value;
                    PropertyChanged.Raise(() => Name);
                }
            }
        }

        private int _age;
        [Required(ErrorMessage = "{0} is required.")]
        [Range(25, 60, ErrorMessage = "{0} must be set between {1} and {2}")]
        public int Age
        {
            get { return _age; }
            set
            {
                if (_age != value)
                {
                    ValidationHelper.ValidateProperty(value, () => Age);
                    _age = value;
                    PropertyChanged.Raise(() => Age);
                }
            }
        }


        private string _email = string.Empty;
        [Required(ErrorMessage = "{0} is required.")]
        [RegularExpression(@"\w+([-+.']\w+)*@\w+([-.]\w+)*\.\w+([-.]\w+)*",
            ErrorMessage = "Please enter a valid email.")]
        public string Email
        {
            get { return _email; }
            set
            {
                if (_email != value)
                {
                    ValidationHelper.ValidateProperty(value, () => Email);
                    _email = value;
                    PropertyChanged.Raise(() => Email);
                }
            }
        }

        #region INotifyPropertyChanged Members
        public event PropertyChangedEventHandler PropertyChanged;
        #endregion
    }

}
