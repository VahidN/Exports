﻿using System.Linq;
using System.Windows;
using System.Windows.Input;
using SilverlightApplication68.Helper;
using SilverlightApplication68.Models;

namespace SilverlightApplication68.ViewModels
{
    public class EmployeeViewModel 
    {
        public ICommand SaveCommand { set; get; }

        public Employee EmployeeInfo { set; get; }

        public EmployeeViewModel()
        {
            EmployeeInfo = new Employee();
            SaveCommand = new DelegateCommand<Employee>(
                saveCommand, canSaveCommand);
        }

        private bool canSaveCommand(Employee arg)
        {
            return arg != null;
        }

        private void saveCommand(Employee obj)
        {
            //validating model
            var errorInfos = ValidationHelper.GetErrors(obj);
            if(errorInfos.Any())
            {
                MessageBox.Show("Model is not valid");
                return;
            }

            MessageBox.Show(string.Format("{0} Saved.", obj.Name));
        }
    }
}
