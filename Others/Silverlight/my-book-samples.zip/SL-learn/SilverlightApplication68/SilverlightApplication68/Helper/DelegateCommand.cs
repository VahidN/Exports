﻿using System;
using System.Windows.Input;

namespace SilverlightApplication68.Helper
{
    public class DelegateCommand<T> : ICommand
    {
        readonly Func<T, bool> _canExecute;
        readonly Action<T> _executeAction;
        bool _canExecuteCache;

        public DelegateCommand(Action<T> executeAction,
            Func<T, bool> canExecute)
        {
            _executeAction = executeAction;
            _canExecute = canExecute;
        }

        public bool CanExecute(object parameter)
        {
            bool temp = _canExecute((T)parameter);

            if (_canExecuteCache != temp)
            {
                _canExecuteCache = temp;

                if (CanExecuteChanged != null)
                {
                    CanExecuteChanged(this, new EventArgs());
                }
            }

            return _canExecuteCache;
        }

        public event EventHandler CanExecuteChanged;
        public void Execute(object parameter)
        {
            _executeAction((T)parameter);
        }
    }
}
