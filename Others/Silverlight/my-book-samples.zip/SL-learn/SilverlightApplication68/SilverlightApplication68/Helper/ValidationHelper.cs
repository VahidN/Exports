﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq.Expressions;
using System.Reflection;

namespace SilverlightApplication68.Helper
{
    public class ValidationHelper
    {
        public static IList<ValidationResult> GetErrors(object instance)
        {
            var res = new List<ValidationResult>();
            Validator.TryValidateObject(instance,
                new ValidationContext(instance, null, null), res, true);
            return res;
        }

        public static void ValidateProperty(object value,
            Expression<Func<object>> expression)
        {
            PropertyInfo propertyInfo;
            var constantExpression = expression.GetPropertyInfo(out propertyInfo);
            Validator.ValidateProperty(value,
                new ValidationContext(constantExpression.Value, null, null)
                {
                    MemberName = propertyInfo.Name
                });
        }
    }
}
