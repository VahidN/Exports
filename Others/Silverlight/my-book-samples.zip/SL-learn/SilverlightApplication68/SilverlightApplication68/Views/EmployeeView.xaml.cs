﻿namespace SilverlightApplication68.Views
{
    public partial class EmployeeView
    {
        public EmployeeView()
        {
            InitializeComponent();
        }
    }
}
