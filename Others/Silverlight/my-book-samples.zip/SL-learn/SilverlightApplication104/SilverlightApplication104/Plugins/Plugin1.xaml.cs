﻿using System.ComponentModel.Composition;
using System.Windows.Controls;

namespace SilverlightApplication104.Plugins
{
    [Export(typeof(UserControl))]
    public partial class Plugin1 : UserControl
    {
        public Plugin1()
        {
            InitializeComponent();
        }

        [Import("HelloMEF.Message")]
        public string Message
        {
            get { return (string)btn1.Content; }
            set { btn1.Content = value; }
        }
    }
}
