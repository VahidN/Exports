﻿using System.ComponentModel.Composition;

namespace SilverlightApplication104
{
    public class MessagePart
    {
        [Export("HelloMEF.Message")]
        public string Message = "Hello MEF";
    }
}
