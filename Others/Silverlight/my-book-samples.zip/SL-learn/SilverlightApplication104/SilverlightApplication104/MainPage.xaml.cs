﻿using System.ComponentModel.Composition;
using System.Windows;
using System.Windows.Controls;
using System.Collections.Generic;

namespace SilverlightApplication104
{
    public partial class MainPage : UserControl
    {
        [ImportMany]
        public IEnumerable<UserControl> Plugins { get; set; }

        public MainPage()
        {
            InitializeComponent();
            this.Loaded += MainPage_Loaded;
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            CompositionInitializer.SatisfyImports(this);

            foreach (var plugin in Plugins)
            {
                plugin.Margin = new Thickness(5);
                PluginPanel.Children.Add(plugin);
            }
        }
    }
}
