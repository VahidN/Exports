﻿using System.Windows;

namespace SilverlightApplication38
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnEllipse_Click(object sender, 
            RoutedEventArgs e)
        {
            border1.Child = new Views.Ellipse();
        }

        private void btnRectangle_Click(object sender, 
            RoutedEventArgs e)
        {
            border1.Child = new Views.Rectangle();
        }
    }
}
