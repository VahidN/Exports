﻿using System.Windows;
using System.Windows.Input;

namespace SilverlightApplication23
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            resultTextBlock.Text = "Button";
        }

        private void DemoButton1_Click(object sender, RoutedEventArgs e)
        {
            resultTextBlock.Text = "DemoButton";
        }

        private void DemoShape_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            resultTextBlock.Text = "DemoShape";
        }
    }
}
