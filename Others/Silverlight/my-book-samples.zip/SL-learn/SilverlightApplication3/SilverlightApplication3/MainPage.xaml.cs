﻿using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SilverlightApplication3
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            // equivalent code for four attribute types
            var rect = new Rectangle
                           {
                               Width = 40, 
                               Fill = new SolidColorBrush(Colors.Orange)
                           };

            // read value from property
            double w = rect.Width;

            // assign delegate to event
            rect.MouseLeave += Rectangle_MouseEnter; 

            // directive attributes are only needed in XAML

            // assign value to attached property
            Canvas.SetLeft(rect, 50);
            // read value from attached property
            double l = Canvas.GetLeft(rect); 

            LayoutRoot.Children.Add(rect);
        }

        private void Rectangle_MouseEnter(object sender, MouseEventArgs e)
        { }
    }
}
