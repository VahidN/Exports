﻿using System.Windows;
using System.Windows.Controls;

namespace SilverlightApplication40
{
    public partial class PrintChildWindow
    {
        public PrintChildWindow()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = true;
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }

        // create properties to expose values to other pages
        public int NumberOfCopies
        {
            get
            {
                return int.Parse(numberCopiesTextbox.Text);
            }
        }
        public string PrinterName
        {
            get
            {
                var textBlock = listPrinters.SelectedItem as TextBlock;
                return textBlock != null ? textBlock.Text : string.Empty;
            }
        }
    }
}

