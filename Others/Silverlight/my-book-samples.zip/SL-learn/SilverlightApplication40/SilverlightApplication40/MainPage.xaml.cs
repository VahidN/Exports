﻿using System;
using System.Windows;

namespace SilverlightApplication40
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnShow_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new PrintChildWindow();
            dialog.Closed += dialog_Closed;
            dialog.Show();
        }

        void dialog_Closed(object sender, EventArgs e)
        {
            var dialog = sender as PrintChildWindow;
            if (dialog == null) return;
            if (dialog.DialogResult == true) //if OK ...
                txtResult.Text = string.Format(
                    "NumberOfCopies: {0}, PrinterName: {1}",
                    dialog.NumberOfCopies,
                    dialog.PrinterName);
        }
    }
}
