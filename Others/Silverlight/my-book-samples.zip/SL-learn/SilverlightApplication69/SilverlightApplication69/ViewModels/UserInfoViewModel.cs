﻿using System.Windows;
using System.Windows.Input;
using SilverlightApplication69.Helper;
using SilverlightApplication69.Models;

namespace SilverlightApplication69.ViewModels
{
    public class UserInfoViewModel
    {
        public ICommand SaveUserInfo { set; get; }
        public UserInfo UserInfo { set; get; }

        public UserInfoViewModel()
        {
            UserInfo = new UserInfo();
            SaveUserInfo = new DelegateCommand<UserInfo>(
                saveUserInfo, canSaveUserInfo);
        }

        private bool canSaveUserInfo(UserInfo arg)
        {
            return true;
        }

        private void saveUserInfo(UserInfo obj)
        {
            if (obj.HasErrors)
            {
                MessageBox.Show("Model is not valid");
                return;
            }
            MessageBox.Show(string.Format("{0} Saved!", obj.Name));
        }
    }
}
