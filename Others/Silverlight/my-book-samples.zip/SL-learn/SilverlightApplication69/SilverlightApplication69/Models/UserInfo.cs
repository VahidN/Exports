﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using SilverlightApplication69.Helper;

namespace SilverlightApplication69.Models
{
    public class UserInfo : INotifyPropertyChanged, INotifyDataErrorInfo
    {
        private string _name = string.Empty;
        public string Name
        {
            get { return _name; }
            set
            {
                if (_name != value)
                {
                    _name = value;
                    validateNameProperty();
                    PropertyChanged.Raise(() => Name);
                }
            }
        }

        private void validateNameProperty()
        {
            IsBusy = true;
            clearValidationErrors("Name");

            var srv = new ValidationService.ValidateUserClient();
            srv.IsValidCompleted += (o, h) =>
            {
                if (h.Error != null)
                    return;

                string errMsg = string.Format("Account with the ID {0} already exists", Name);
                if (!h.Result)
                {
                    addValidationError("Name",errMsg);
                }
                else
                {
                    removeValidationError("Name", errMsg);
                }

                IsBusy = false;
            };
            srv.IsValidAsync(Name);
        }

        private int _age;
        public int Age
        {
            get { return _age; }
            set
            {
                if (_age != value)
                {
                    _age = value;
                    validateAgeProperty();
                    PropertyChanged.Raise(() => Age);
                }
            }
        }

        private void validateAgeProperty()
        {
            const string errMsg = "Age should be between 25-60";
            if (Age > 60 || Age < 25)
            {
                 addValidationError("Age", errMsg);
            }
            else
            {
                removeValidationError("Age", errMsg);
            }
        }

        private bool _isBusy;
        public bool IsBusy
        {
            get { return _isBusy; }
            set
            {
                if (_isBusy != value)
                {
                    _isBusy = value;
                    PropertyChanged.Raise(() => IsBusy);
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;


        #region INotifyDataErrorInfo Members

        public event EventHandler<DataErrorsChangedEventArgs> ErrorsChanged;

        public System.Collections.IEnumerable GetErrors(string propertyName)
        {
            if (_errorList != null && _errorList.ContainsKey(propertyName))
                return _errorList[propertyName];

            return null;      
        }

        public bool HasErrors
        {
            get
            {
                if (_errorList == null)
                    return false;

                return _errorList.Any();
            }
        }

        Dictionary<string, List<object>> _errorList;
        private void addValidationError(string propName, object error)
        {
            if (_errorList == null)
                _errorList = new Dictionary<string, List<object>>();
            if (!_errorList.ContainsKey(propName))
                _errorList[propName] = new List<object>();
            if (!_errorList[propName].Contains(error))
            {
                _errorList[propName].Add(error);
                OnErrorsChanged(propName);
            }
        }

        private void removeValidationError(string propName, object error)
        {
            if (_errorList == null)
                _errorList = new Dictionary<string, List<object>>();
            if (!_errorList.ContainsKey(propName))
                _errorList[propName] = new List<object>();
            if (_errorList[propName].Contains(error))
            {
                _errorList[propName].Remove(error);
                OnErrorsChanged(propName);
            }
        }

        private void clearValidationErrors(string propName)
        {
            if (_errorList == null)
                return;
            if (!_errorList.ContainsKey(propName))
                return;
            _errorList[propName] = new List<object>();
            OnErrorsChanged(propName);
        }

        protected void OnErrorsChanged(string propName)
        {
            if (ErrorsChanged != null)
                ErrorsChanged(this, new DataErrorsChangedEventArgs(propName));
        }

        #endregion
    }
}
