﻿using System.ServiceModel;
using System.ServiceModel.Activation;
using System.Threading;

namespace SilverlightApplication69.Web
{
    [ServiceContract(Namespace = "")]
    [AspNetCompatibilityRequirements(RequirementsMode =
        AspNetCompatibilityRequirementsMode.Allowed)]
    public class ValidateUser
    {
        [OperationContract]
        public bool IsValid(string userName)
        {
            //TODO: رعايت مسايل امنيتي ذكر شده در فصل امنيت
            //TODO: منطق دريافت اطلاعات از بانك اطلاعاتي را در اينجا پياده سازي نمائيد
            Thread.Sleep(2000); //شبيه سازي عملياتي طولاني
            return userName.ToLower().Trim() != "vahid";
        }
    }
}
