﻿using System.Windows.Input;

namespace SilverlightApplication25
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            this.MouseLeftButtonDown += CommonMouseDownCode;
            DemoBorder.MouseLeftButtonDown += CommonMouseDownCode;
            DemoButton.MouseLeftButtonDown += CommonMouseDownCode;
            DemoImage.MouseLeftButtonDown += CommonMouseDownCode;
            DemoStackPanel.MouseLeftButtonDown += CommonMouseDownCode;
            DemoTextBlock.MouseLeftButtonDown += CommonMouseDownCode;

            listResults.MouseLeftButtonUp += listResults_MouseLeftButtonUp;
        }

        void listResults_MouseLeftButtonUp(object sender, MouseButtonEventArgs e)
        {
            listResults.Items.Clear();
        }

        void CommonMouseDownCode(object sender, MouseButtonEventArgs e)
        {
            string whatHappened = string.Format("Sender = {0}", sender);
            listResults.Items.Add(whatHappened);
        }
    }
}
