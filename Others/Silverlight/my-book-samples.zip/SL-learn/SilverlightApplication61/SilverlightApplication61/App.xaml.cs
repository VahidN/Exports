﻿using System;
using System.Windows;

namespace SilverlightApplication61
{
    public partial class App
    {
		#region Constructors (1) 

        public App()
        {
            this.Startup += this.Application_Startup;
            this.Exit += this.Application_Exit;
            this.UnhandledException += Application_UnhandledException;

            InitializeComponent();
        }

		#endregion Constructors 

		#region Methods (4) 

		// Private Methods (4) 

        private void Application_Exit(object sender, EventArgs e)
        {
            
        }

        private void Application_Startup(object sender, StartupEventArgs e)
        {
            //this.RootVisual = new MainPage();
        }

        private void Application_UnhandledException(object sender, ApplicationUnhandledExceptionEventArgs e)
        {
            if (!System.Diagnostics.Debugger.IsAttached)
            {
                e.Handled = true;
                Deployment.Current.Dispatcher.BeginInvoke(() => ReportErrorToDOM(e));
            }
        }

        private void ReportErrorToDOM(ApplicationUnhandledExceptionEventArgs e)
        {
            try
            {
                string errorMsg = e.ExceptionObject.Message + e.ExceptionObject.StackTrace;
                errorMsg = errorMsg.Replace('"', '\'').Replace("\r\n", @"\n");

                System.Windows.Browser.HtmlPage.Window.Eval("throw new Error(\"Unhandled Error in Silverlight Application " + errorMsg + "\");");
            }
            catch (Exception)
            {
            }
        }

		#endregion Methods 
    }
}
