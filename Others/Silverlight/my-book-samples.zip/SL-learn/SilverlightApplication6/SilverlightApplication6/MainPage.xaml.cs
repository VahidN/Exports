﻿namespace SilverlightApplication6
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            /*txtDp.FontSize = 20; //valid
            var size = txtDp.FontSize;//valid

            //using DP system
            txtDp.SetValue(FontSizeProperty,20);
            size = (double ) txtDp.GetValue(FontSizeProperty);*/
        }
    }
}
