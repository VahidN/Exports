﻿using System;
using System.Windows;

namespace SilverlightApplication34
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            tb1.Text = "Clicked : " + DateTime.Now.ToLongTimeString();
        }

        private void btn2_Click(object sender, RoutedEventArgs e)
        {
            tb2.Text = "Clicked : " + DateTime.Now.ToLongTimeString();
        }

        long _counter;
        private void btn3_Click(object sender, RoutedEventArgs e)
        {
            ++_counter;
            tb3.Text = _counter.ToString();
        }
    }
}
