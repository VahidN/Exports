﻿using System.Windows.Input;

namespace SilverlightApplication26
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            this.MouseLeftButtonDown += BubbleToRoot_MouseLeftButtonDown;
        }

        void BubbleToRoot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            string whatHappened = string.Format(
                "Sender = {0}, Original= {1}", sender, e.OriginalSource);
            listResults.Items.Add(whatHappened);
        }
    }
}
