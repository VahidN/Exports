﻿using System.ComponentModel;
using System.Windows.Media;

namespace SilverlightApplication4
{
    public partial class WeatherControl
    {
        public WeatherControl()
        {
            InitializeComponent();
        }

        [TypeConverter(typeof(WeatherTypeConverter))]
        public Brush WeatherBackground
        {
            get
            {
                return LayoutRoot.Background;
            }
            set
            {
                LayoutRoot.Background = value;
            }
        }
    }
}
