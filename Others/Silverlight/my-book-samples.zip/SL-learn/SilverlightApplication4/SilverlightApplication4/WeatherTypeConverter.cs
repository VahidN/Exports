﻿using System;
using System.ComponentModel;
using System.Globalization;
using System.Windows.Media;

namespace SilverlightApplication4
{
    public class WeatherTypeConverter : TypeConverter
    {
        public override bool CanConvertFrom(ITypeDescriptorContext context,
                                            Type sourceType)
        {
            if (sourceType == typeof(string))
            {
                return true;
            }
            return base.CanConvertFrom(context, sourceType);

        }

        public override object ConvertFrom(ITypeDescriptorContext context,
                                           CultureInfo culture, object value)
        {
            var text = value as string;

            switch (text)
            {
                case "Sunny":
                    return new SolidColorBrush(Colors.Yellow);
                case "Foggy":
                    return new SolidColorBrush(Colors.Gray);
                case "Rainy":
                    return new SolidColorBrush(Colors.Blue);
                default:
                    return new SolidColorBrush(Colors.White); 
            }
        }
    }
}
