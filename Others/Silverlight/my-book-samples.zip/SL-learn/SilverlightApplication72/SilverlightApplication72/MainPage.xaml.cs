﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Windows;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Threading;

namespace SilverlightApplication72
{
    public partial class MainPage : INotifyPropertyChanged
    {
        #region Fields (3)

        private bool _isPlaying;
        string _mediaLen;
        private DispatcherTimer _timer;

        #endregion Fields

        #region Constructors (1)

        public MainPage()
        {
            InitializeComponent();
            initTimer();
        }

        #endregion Constructors

        #region Properties (3)

        //نمايش خودكار مدت زمان كل و مدت زمان پخش شده
        public string MediaLen
        {
            get { return _mediaLen; }
            set
            {
                if (_mediaLen == value) return;
                _mediaLen = value;
                raisePropertyChanged("MediaLen");
            }
        }

        //اين تصاوير در حين پخش بايد تغيير كنند
        static BitmapImage pauseImg
        {
            get
            {
                return new BitmapImage
                {
                    UriSource =
                           new Uri("Images/debug-pause-icon.png",
                           UriKind.Relative)
                };
            }
        }

        //دريافت تصوير از منابع پروژه
        static BitmapImage runImg
        {
            get
            {
                return new BitmapImage
                {
                    UriSource =
                    new Uri("Images/debug-run-icon.png",
                    UriKind.Relative)
                };
            }
        }

        #endregion Properties

        #region Delegates and Events (1)

        // Events (1) 

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion Delegates and Events

        #region Methods (13)

        // Private Methods (13) 

        //نمايش ميزان پيشرفت پخش مديا
        void _timer_Tick(object sender, EventArgs e)
        {
            seekBar.Value = mediaElement1.Position.TotalSeconds;
            if (mediaElement1.NaturalDuration.HasTimeSpan)
            {
                var remaningVal = mediaElement1.NaturalDuration.TimeSpan
                                    - mediaElement1.Position;
                MediaLen = string.Format(
                    "{0}:{1}:{2}",
                    remaningVal.Hours.ToString("00"), remaningVal.Minutes.ToString("00"),
                    remaningVal.Seconds.ToString("00"));
            }
            else
                Debug.WriteLine("!NaturalDuration.HasTimeSpan");
        }

        //تغيير اندازه‌ي صفحه‌ي نمايش
        private void btnExpand_Click(object sender, RoutedEventArgs e)
        {
            mediaElement1.Stretch =
                mediaElement1.Stretch == Stretch.UniformToFill
                ? Stretch.None
                : Stretch.UniformToFill;
        }

        //درخواست مكث يا شروع به كار
        //به همراه تغيير آيكون دكمه‌ها
        private void btnPlay_Click(object sender, RoutedEventArgs e)
        {
            if (!_isPlaying)
            {
                mediaElement1.Play();
                _isPlaying = true;
                imgPaly.Source = runImg;
            }
            else
            {
                mediaElement1.Pause();
                _isPlaying = false;
                imgPaly.Source = pauseImg;
            }
        }

        //درخواست توقف نمايش
        private void btnStop_Click(object sender, RoutedEventArgs e)
        {
            _isPlaying = false;
            mediaElement1.Stop();
            imgPaly.Source = runImg;
        }

        //نمايش طول مدت پخش يك فيلم يا مديا
        string getMediaLen()
        {
            return !mediaElement1.NaturalDuration.HasTimeSpan
                       ? "00:00:00"
                       : string.Format("{0}:{1}:{2}",
                         mediaElement1.NaturalDuration.TimeSpan.Hours.ToString("00"),
                         mediaElement1.NaturalDuration.TimeSpan.Minutes.ToString("00"),
                         mediaElement1.NaturalDuration.TimeSpan.Seconds.ToString("00"));
        }

        //آغاز به  كار يك تايمر جهت بررسي ميزان پيشرفت كار
        private void initTimer()
        {
            _timer = new DispatcherTimer { Interval = TimeSpan.FromMilliseconds(200) };
            _timer.Tick += _timer_Tick;
        }

        //فايل ويديويي بارگذاري شده است
        private void mediaElement1_Loaded(object sender, RoutedEventArgs e)
        {
            _isPlaying = true;
            imgPaly.Source = pauseImg;
            imgPaly.ImageFailed += (send, er)
                => Debug.WriteLine(er.ErrorException.ToString());
        }

        //پايان كار پخش
        private void mediaElement1_MediaEnded(object sender, RoutedEventArgs e)
        {
            btnStop_Click(this, null);
        }

        //آيا مشكلي رخ داده است؟
        private void mediaElement1_MediaFailed(object sender,
                        ExceptionRoutedEventArgs e)
        {
            Debug.WriteLine(e.ErrorException.ToString());
        }

        //شروع يك تايمر جهت بررسي ميزان پيشرفت پخش فيلم
        private void mediaElement1_MediaOpened(object sender, RoutedEventArgs e)
        {
            _timer.Stop();
            if (mediaElement1.NaturalDuration.HasTimeSpan)
            {
                var ts = mediaElement1.NaturalDuration.TimeSpan;
                seekBar.Maximum = ts.TotalSeconds;
                seekBar.SmallChange = 1;
                seekBar.LargeChange = Math.Min(10, ts.Seconds / 10);

                MediaLen = getMediaLen();
            }
            _timer.Start();
        }

        //جهت اعمال انقياد داده‌ها و آگاه سازي خودكار
        void raisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler == null) return;
            handler(this, new PropertyChangedEventArgs(propertyName));
        }

        //تغيير نقطه‌ي در حال پخش
        private void seekBar_ValueChanged(object sender,
            RoutedPropertyChangedEventArgs<double> e)
        {
            if (seekBar != null)
            {
                var fromSeconds = TimeSpan.FromSeconds(seekBar.Value);
                if (mediaElement1.Position.CompareTo(fromSeconds) != 0)
                    mediaElement1.Position = fromSeconds;
            }
        }

        //تغيير شدت صداي در حال پخش
        private void volumeSlider_ValueChanged(object sender,
            RoutedPropertyChangedEventArgs<double> e)
        {
            if (volumeSlider != null)
                mediaElement1.Volume = volumeSlider.Value;
        }

        #endregion Methods
    }
}
