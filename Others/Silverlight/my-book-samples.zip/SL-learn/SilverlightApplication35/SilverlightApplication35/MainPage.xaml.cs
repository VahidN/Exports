﻿using System.Collections.Generic;
using System.Windows;

namespace SilverlightApplication35
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += FromCollectionInCode_Loaded;
        }

        void FromCollectionInCode_Loaded(object sender, RoutedEventArgs e)
        {
            listBox1.Items.Add("January");
            listBox1.Items.Add("February");
            listBox1.Items.Add("March");
            listBox1.Items.Add("April");
            listBox1.Items.Add("May");

            var days = new List<string>
                           {
                               "Monday", "Tuesday", "Wednesday", 
                               "Thursday", "Friday", "Saturday", "Sunday"
                           };

            // listbox can have data assigned with Items or ItemsSource
            // cannot have existing data in Items collection before 
            // assigning to the itemsource however.
            listBox2.ItemsSource = days;
        }
    }
}
