﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace SilverlightApplication29
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            listResults.Items.Clear();
        }

        private void LayoutRoot_KeyUp(object sender, KeyEventArgs e)
        {
            //  ALT key is used by IE
            string modifiers = null;

            if ((Keyboard.Modifiers & ModifierKeys.Control) == ModifierKeys.Control)
            {
                modifiers += "Ctrl |";
            }

            if ((Keyboard.Modifiers & ModifierKeys.Shift) == ModifierKeys.Shift)
            {
                modifiers += "Shift";
            }

            listResults.Items.Add(string.Format(
                "Key = {0}, Modifiers = {1}", e.Key, modifiers));
        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            listResults.Items.Add("TextChanged");
        }

        private void TextBox_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Key == Key.B)
            {
                // reject this key and do not show in textbox
                e.Handled = true;
            }
        }
    }
}
