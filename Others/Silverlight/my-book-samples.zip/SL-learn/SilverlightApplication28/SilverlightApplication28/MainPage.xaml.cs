﻿using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Shapes;

namespace SilverlightApplication28
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Ellipse_MouseEnter(object sender, MouseEventArgs e)
        {
            var ellipse = sender as Ellipse;
            if (ellipse != null) ellipse.Fill = new SolidColorBrush(Colors.Orange);

            // MouseEventArgs contains mouse details.
        }

        private void Ellipse_MouseLeave(object sender, MouseEventArgs e)
        {
            var ellipse = sender as Ellipse;
            if (ellipse != null) ellipse.Fill = new SolidColorBrush(Colors.White);
        }

        private void Ellipse_MouseMove(object sender, MouseEventArgs e)
        {
            // get the mouse location relative to UserControl (this)
            var point = e.GetPosition(this);
            textBlockResults.Text = string.Format("{0},{1}", point.X, point.Y);

            // get the mouse location relative to Ellipse
            var point2 = e.GetPosition(moveEllipse);
            textBlockResults2.Text = string.Format("{0},{1}", point2.X, point2.Y);
        }

        private void wheelEllipse_MouseWheel(object sender, MouseWheelEventArgs e)
        {
            // wheel event only works on Internet Explorer on Windows
            // e.Delta refers to which direction you moved the wheel
            // Delta is always 120  or -120
            wheelEllipse.Width += e.Delta / 10;
        }
    }
}
