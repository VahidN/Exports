﻿using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace SilverlightApplication64
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void btnTxt_Click(object sender, RoutedEventArgs e)
        {
            /*var dialog = new OpenFileDialog
                             {
                                 Filter = "Text Files (*.txt)|*.txt",
                                 Multiselect = true
                             };
            // Show the dialog box.
            if (dialog.ShowDialog() == true)
            {
                // Copy all the selected files to isolated storage.
                foreach (FileInfo file in dialog.Files)
                {
                    using (StreamReader reader = file.OpenText())
                    {
                        string data = reader.ReadToEnd();
                    }
                }
            }*/

            var dialog = new OpenFileDialog
            {
                Filter = "Text Files (*.txt)|*.txt"
            };

            if (dialog.ShowDialog() == true)
            {
                using (var reader = dialog.File.OpenText())
                {
                    string data = reader.ReadToEnd();
                }
            }
        }

        private void btnImg_Click(object sender, RoutedEventArgs e)
        {
            var dialog = new OpenFileDialog
                             {
                                 Filter = "All files (*.*)|*.*", 
                                 Multiselect = true
                             };
            // Show the dialog box.
            if (dialog.ShowDialog() == true)
            {
                foreach (FileInfo file in dialog.Files)
                {
                    using (Stream fileStream = file.OpenRead())
                    {
                        //1 KB block at a time.
                        byte[] buffer = new byte[1024];
                        int count;
                        do
                        {
                            count = fileStream.Read(buffer, 0, buffer.Length);
                        } while (count > 0);
                    }
                }
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            var saveDialog = new SaveFileDialog
                                 {
                                     Filter = "Text Files (*.txt)|*.txt"
                                 };
            if (saveDialog.ShowDialog() == true)
            {
                using (var stream = saveDialog.OpenFile())
                {
                    using (var writer = new StreamWriter(stream))
                    {
                        writer.Write("some data...");
                    }
                }
            }
        }
    }
}
