﻿using System;
using System.Windows;
using System.Windows.Media.Imaging;

namespace SilverlightApplication70
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            //showImg();
            //loadExternalImg();
        }
        /*
        private void loadExternalImg()
        {
            var bi = new BitmapImage
                         {
                             UriSource = new Uri("http://www.google.com/images/firefox/personas.png")
                         };
            img1.Source = bi;
            img1.ImageOpened += img1_ImageOpened;
            img1.ImageFailed += img1_ImageFailed;
        }

        void img1_ImageFailed(object sender, ExceptionRoutedEventArgs e)
        {
            MessageBox.Show(e.ErrorException.Message);
        }

        void img1_ImageOpened(object sender, RoutedEventArgs e)
        {
        }
       
        void showImg()
        {
            var sr = 
                Application.GetResourceStream(
                   new Uri("SilverlightApplication70;component/Images/Camera.png",
                       UriKind.Relative));
            var bmp = new BitmapImage();
            bmp.SetSource(sr.Stream);
            img1.Source = bmp;
            img1.Width = 48;
            img1.Height = 48;
        }*/
    }
}
