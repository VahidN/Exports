﻿using System.Collections.ObjectModel;
using SilverlightApplication70.Models;

namespace SilverlightApplication70.ViewModels
{
    public class SiteInfoViewModel
    {
        public ObservableCollection<SiteInfo> SitesInfo { set; get; }
        public SiteInfoViewModel()
        {
            SitesInfo = new ObservableCollection<SiteInfo>
                 {
                    new SiteInfo
                    {
                       Title = "Yahoo",
                       LogoUrl = "http://l.yimg.com/a/i/ww/met/yahoo_logo_us_061509.png"
                    },
                    new SiteInfo
                    {
                       Title = "Google",
                       LogoUrl = "http://www.google.com/intl/en_ALL/images/srpr/logo1w.png"
                    }
               };
        }
    }
}
