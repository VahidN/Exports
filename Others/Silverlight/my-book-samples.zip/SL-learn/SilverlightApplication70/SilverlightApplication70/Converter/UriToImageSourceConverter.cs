﻿using System;
using System.Diagnostics;
using System.Globalization;
using System.Windows.Data;
using System.Windows.Media.Imaging;

namespace SilverlightApplication70.Converter
{
    public class UriToImageSourceConverter : IValueConverter
    {
        public object Convert(object value,
            Type targetType, object parameter,
            CultureInfo culture)
        {
            if (value == null) return null;
            string imageUrl = value.ToString();
            var uriSource = new Uri(imageUrl, UriKind.Absolute);
            var result = new BitmapImage(uriSource);
            result.ImageFailed +=
                (sender, e) => Debug.WriteLine(e.ErrorException.ToString());
            return result;
        }

        public object ConvertBack(object value, Type targetType,
            object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
