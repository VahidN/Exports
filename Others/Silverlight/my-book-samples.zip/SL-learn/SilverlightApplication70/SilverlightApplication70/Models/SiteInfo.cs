﻿using System.ComponentModel;
using SilverlightApplication70.Helpers;

namespace SilverlightApplication70.Models
{
    public class SiteInfo : INotifyPropertyChanged
    {
        private string _title = string.Empty;
        public string Title
        {
            get { return _title; }
            set
            {
                if (_title != value)
                {
                    _title = value;
                    PropertyChanged.Raise(() => Title);
                }
            }
        }

        private string _logoUrl = string.Empty;
        public string LogoUrl
        {
            get { return _logoUrl; }
            set
            {
                if (_logoUrl != value)
                {
                    _logoUrl = value;
                    PropertyChanged.Raise(() => LogoUrl);
                }
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;
    }
}
