﻿using System.Windows;
using System.Windows.Browser;

namespace SilverlightApplication100
{
    [ScriptableType]
    public class FooClass
    {
        [ScriptableMember]
        public void Foo(string data)
        {
            MessageBox.Show("FromJavascript: " + data);
        }
    }
}
