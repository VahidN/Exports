﻿using System.Windows;
using System.Windows.Browser;

namespace SilverlightApplication100
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            HtmlPage.RegisterScriptableObject("MyFooClass", new FooClass());
            this.Loaded += MainPage_Loaded;
        }

        void MainPage_Loaded(object sender, RoutedEventArgs e)
        {
            HtmlElement button = HtmlPage.Document.GetElementById("HTMLButtonA");
            if (button != null)
                button.AttachEvent("onclick",
                    (object o, HtmlEventArgs args) =>
                    {
                        MessageBox.Show("HTMLButtonA Clicked!");
                    }
                    );
        }

        private void btnModifyDOM_Click(object sender,
            RoutedEventArgs e)
        {
            var span = HtmlPage.Document.GetElementById("SilverlightMessage");
            if (span != null)
                span.SetAttribute("innerHTML",
                    "From Silverlight Button!");
        }

        private void btnCallJs_Click(object sender, RoutedEventArgs e)
        {
            HtmlPage.Window.Invoke("Foo", "param1", "param2");
        }
    }
}
