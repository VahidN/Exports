﻿using System.Windows;

namespace SilverlightApplication37
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void closeButton_click(object sender, 
            RoutedEventArgs e)
        {
            propertyPopup.IsOpen = false;

        }

        private void ShowPopup_Click(object sender, 
            RoutedEventArgs e)
        {
            propertyPopup.IsOpen = true;
        }
    }
}
