﻿using System.Windows;
using System.Windows.Controls;

namespace SilverlightApplication18
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            Canvas.SetZIndex(blueButton, 90);
        }
    }
}
