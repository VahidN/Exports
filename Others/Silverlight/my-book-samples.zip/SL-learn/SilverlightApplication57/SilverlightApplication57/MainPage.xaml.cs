﻿using System;
using System.Windows;

namespace SilverlightApplication57
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            this.Loaded += pageLoaded;
        }

        void pageLoaded(object sender, RoutedEventArgs e)
        {
            var rd = new ResourceDictionary();
            rd.Source =
                new Uri("/Themes/System.Windows.Controls.Theming.RainierOrange.xaml",
                        UriKind.Relative);
            //Load resourse dictonary
            //Clear previous styles if any...
            Application.Current.Resources.MergedDictionaries.Clear();
            //Add the loaded resource dictionary to the application merged dictionaries
            Application.Current.Resources.MergedDictionaries.Add(rd);
        }
    }
}
