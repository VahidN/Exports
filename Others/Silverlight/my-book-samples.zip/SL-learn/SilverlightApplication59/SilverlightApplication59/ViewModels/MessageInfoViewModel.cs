﻿using System.ComponentModel;
using System.Windows.Input;
using SilverlightApplication59.Helper;
using SilverlightApplication59.Models;

namespace SilverlightApplication59.ViewModels
{
    public class MessageInfoViewModel
    {
        public MessageInfo MessageInfo { set; get; }
        public ICommand SendMessage { set; get; }

        public MessageInfoViewModel()
        {
            MessageInfo = new MessageInfo
                              {
                                  FromAddress = "from@site.com",
                                  ToAddress = "vahid_nasiri@yahoo.com",
                                  Subject = "Hello!",
                                  Body = "This is a test...",
                                  Result = string.Empty
                              };

            SendMessage = new DelegateCommand<MessageInfo>(sendEmail, canSendEmail);
        }


        private static bool canSendEmail(MessageInfo enteredInfo)
        {
            //TODO: Validation
            return enteredInfo != null;
        }

        private void sendEmail(MessageInfo enteredInfo)
        {
            var srv = new ASMXEmailService.EmailServiceSoapClient();
            srv.SendMailMessageCompleted += srv_SendMailMessageCompleted;
            srv.SendMailMessageAsync(
                enteredInfo.FromAddress,
                enteredInfo.ToAddress,
                enteredInfo.Subject,
                enteredInfo.Body
                );
        }

        void srv_SendMailMessageCompleted(object sender, 
            AsyncCompletedEventArgs e)
        {
            string msg = "Message was ";
            if (e.Error != null)
                msg += string.Format("not sent.\n\n{0}", e.Error.Message);
            else
                msg += "sent using ASMX";

            MessageInfo.Result = msg;
        }
    }
}
