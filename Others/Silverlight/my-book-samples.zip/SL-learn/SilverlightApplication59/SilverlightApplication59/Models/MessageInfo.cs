﻿using System.ComponentModel;

namespace SilverlightApplication59.Models
{
    public class MessageInfo : INotifyPropertyChanged
    {
        public string FromAddress { get; set; }
        public string ToAddress { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }
        
        string _result;
        public string Result
        {
            get { return _result; }
            set
            {
                if (_result == value) return;
                _result = value;
                raisePropertyChanged("Result");
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        void raisePropertyChanged(string propertyName)
        {
            var handler = PropertyChanged;
            if (handler == null) return;
            handler(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}
