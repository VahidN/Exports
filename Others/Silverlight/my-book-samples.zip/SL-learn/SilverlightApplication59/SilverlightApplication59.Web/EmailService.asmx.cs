﻿using System.Web.Services;

namespace SilverlightApplication59.Web
{
    /// <summary>
    /// Summary description for EmailService
    /// </summary>
    [WebService(Namespace = "http://tempuri.org/")]
    [WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
    [System.ComponentModel.ToolboxItem(false)]
    public class EmailService : WebService
    {
        [WebMethod]
        public void SendMailMessage(string from, string to,
            string subject, string body)
        {
            new SendMail().SendMessage(from, to, subject, body);
        }
    }
}
