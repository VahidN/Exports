﻿using System.Net.Mail;

namespace SilverlightApplication59.Web
{
    public class SendMail
    {
        //TODO: read these values form web.config
        private readonly string host = "mail.yoursmtpserver.net";
        private readonly int port = 25;

        public void SendMessage(string from, string to,
            string subject, string body)
        {
            using (var message =
            new MailMessage
            {
                From = new MailAddress(from),
                Body = body,
                Subject = subject
                })
            {
                message.To.Add(to);
                var smtpClient = new SmtpClient(host, port);
                smtpClient.Send(message);
            }
        }
    }
}