﻿using System.IO;
using System.Web;

namespace SilverlightApplication67.Web
{
    /// <summary>
    /// Summary description for GetXap
    /// </summary>
    public class GetXap : IHttpHandler
    {
        public void ProcessRequest(HttpContext context)
        {
            if (!context.User.Identity.IsAuthenticated)
                return;

            // Render XAP Stream Back To Client  
            var buffer = File.ReadAllBytes(
                context.Server.MapPath("ClientBin/SilverlightApplication67.xap"));

            context.Response.ContentType = "application/x-silverlight-app";
            context.Response.BinaryWrite(buffer);
        }

        public bool IsReusable
        {
            get
            {
                return false;
            }
        }
    }
}