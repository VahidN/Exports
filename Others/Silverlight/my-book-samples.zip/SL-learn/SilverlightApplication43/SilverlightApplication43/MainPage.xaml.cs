﻿using SilverlightApplication43.ViewModels;

namespace SilverlightApplication43
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            this.DataContext = new CustomerViewModel();
        }
    }
}
