﻿using SilverlightApplication43.Models;

namespace SilverlightApplication43.ViewModels
{
    public class CustomerViewModel
    {
        public Customer Customer { get; set; }

        public CustomerViewModel()
        {
            this.Customer = new Customer
            {
                FirstName = "Vahid",
                LastName = "Nasiri",
                Age = 55,
                Country = "Iran"
            };
        }
    }
}
