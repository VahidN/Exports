﻿using GalaSoft.MvvmLight.Messaging;

namespace SilverlightApplication50.Views
{
    public partial class ProductsEditWindow
    {
        public ProductsEditWindow()
        {
            Messenger.Default.Register<string>(
                "CloseEdit",
                x => this.Close());

            InitializeComponent();
        }
    }
}

