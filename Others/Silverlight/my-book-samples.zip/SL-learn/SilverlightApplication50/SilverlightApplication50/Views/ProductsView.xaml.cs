﻿using GalaSoft.MvvmLight.Messaging;
using SilverlightApplication50.Models;

namespace SilverlightApplication50.Views
{
    public partial class ProductsView
    {
        public ProductsView()
        {
            Messenger.Default.Register<Product>(this,
                "edit product",
                x =>
                {
                    var selectedItem = x;
                    if (selectedItem == null) return;
                    var win1 = new ProductsEditWindow();
                    Messenger.Default.Send(selectedItem, "doEdit");
                    win1.Show();
                }
                );

            InitializeComponent();
        }
    }
}
