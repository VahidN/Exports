﻿using System.ComponentModel;
using GalaSoft.MvvmLight.Command;
using GalaSoft.MvvmLight.Messaging;
using SilverlightApplication50.Models;

namespace SilverlightApplication50.ViewModels
{
    public class ProductsEditViewModel : INotifyPropertyChanged
    {
        public ProductsEditViewModel()
        {
            EditCommand = new RelayCommand(
                () =>
                    Messenger.Default.Send("CloseEdit")
                    );

            Messenger.Default.Register<Product>(this,
               "doEdit",
                x =>
                {
                    SelectedProduct = x;
                });
        }

        private Product _selectedProduct;
        public Product SelectedProduct
        {
            set
            {
                _selectedProduct = value;
                if (PropertyChanged == null) return;
                onPropertyChanged("SelectedProduct");
            }
            get { return _selectedProduct; }
        }

        public RelayCommand EditCommand
        {
            get;
            private set;
        }

        #region INotifyPropertyChanged Members

        public event PropertyChangedEventHandler PropertyChanged;
        private void onPropertyChanged(string propertyName)
        {
            if (PropertyChanged == null) return;
            PropertyChanged(this, new PropertyChangedEventArgs(propertyName));
        }
        #endregion
    }
}
