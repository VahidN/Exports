﻿using System.Windows.Input;

namespace SilverlightApplication27
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();

            this.MouseLeftButtonDown += BubbleToRoot_MouseLeftButtonDown;
            DemoImage.MouseLeftButtonDown += DemoImage_MouseLeftButtonDown;
        }

        void DemoImage_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            // stop bubbling
            e.Handled = true;
            listResults.Items.Add("Stopped");
        }

        void BubbleToRoot_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {

            string whatHappened = string.Format(
                "Sender = {0}, Original= {1}", sender, e.OriginalSource);
            listResults.Items.Add(whatHappened);
        }
    }
}
