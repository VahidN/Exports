﻿using System;
using System.Windows.Data;

namespace SilverlightApplication47
{
    public class FarenheitToCelciusConverter : IValueConverter
    {
        public object Convert(object value, Type targetType,
               object parameter, System.Globalization.CultureInfo culture)
        {
            string sourceValue = value.ToString();
            double decimalValue;
            if (Double.TryParse(sourceValue, out decimalValue))
            {
                if (parameter.ToString() == "format1")
                {
                    //do something...
                }
                return (decimalValue - 32.0) * (5.0 / 9.0);
            }
            return value;
        }

        public object ConvertBack(object value, Type targetType,
               object parameter, System.Globalization.CultureInfo culture)
        {
            string sourceValue = value.ToString();
            double decimalValue;
            if (Double.TryParse(sourceValue, out decimalValue))
            {
                return (decimalValue * (9.0 / 5.0)) + 32.0;
            }
            return value;
        }
    }
}
