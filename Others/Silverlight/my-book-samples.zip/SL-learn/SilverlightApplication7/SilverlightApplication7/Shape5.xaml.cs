﻿using System.Windows;
using System.Windows.Media;

namespace SilverlightApplication7
{
    public partial class Shape5
    {
        public Shape5()
        {
            InitializeComponent();
        }

        public Brush FillColor
        {
            get { return (Brush)GetValue(FillColorProperty); }
            set { SetValue(FillColorProperty, value); }
        }

        public static readonly DependencyProperty FillColorProperty =
            DependencyProperty.Register("FillColor", typeof(Brush), typeof(Shape5),
              new PropertyMetadata(new SolidColorBrush(Colors.Brown), colorChangedCallBack));

        private static void colorChangedCallBack(DependencyObject d, 
                                DependencyPropertyChangedEventArgs e)
        {
            var shape5 = d as Shape5;
            if (shape5 != null) 
                shape5.onFillColorPropertyChanged(e);
        }
        
        private void onFillColorPropertyChanged(DependencyPropertyChangedEventArgs e)
        {
            var color = e.NewValue as SolidColorBrush;
            if (color != null) 
                star5.Fill = new SolidColorBrush(color.Color);
        }
    }
}
