﻿namespace SilverlightApplication53
{
    public partial class DefineStyles
    {
        public DefineStyles()
        {
            InitializeComponent();
        }
    }
}
