﻿namespace SilverlightApplication53.Model
{
    public class CalendarDay
    {
        public string DayName { get; set; }
        public bool IsWeekend { get; set; }
    }
}
