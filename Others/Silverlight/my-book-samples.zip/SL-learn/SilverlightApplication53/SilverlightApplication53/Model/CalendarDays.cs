﻿using System.Collections.Generic;

namespace SilverlightApplication53.Model
{
    public class CalendarDays : List<CalendarDay>
    {
        public CalendarDays()
        {

            this.Add(new CalendarDay { DayName = "شنبه", IsWeekend = false });
            this.Add(new CalendarDay { DayName = "يك شنبه", IsWeekend = false });
            this.Add(new CalendarDay { DayName = "دو شنبه", IsWeekend = false });
            this.Add(new CalendarDay { DayName = "سه شنبه", IsWeekend = false });
            this.Add(new CalendarDay { DayName = "چهار شنبه", IsWeekend = false });
            this.Add(new CalendarDay { DayName = "پنج شنبه", IsWeekend = true });
            this.Add(new CalendarDay { DayName = "جمعه", IsWeekend = true });
        }
    }
}
