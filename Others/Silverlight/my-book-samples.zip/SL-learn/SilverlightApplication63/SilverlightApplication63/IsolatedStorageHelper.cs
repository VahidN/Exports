﻿using System.IO;
using System.IO.IsolatedStorage;

namespace SilverlightApplication63
{
    public class IsolatedStorageHelper
    {
        public static void SaveData(string data, string fileName)
        {
            using (var isf =
                IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (var isfs =
                    new IsolatedStorageFileStream(
                        fileName, FileMode.Create, isf))
                {
                    using (var sw = new StreamWriter(isfs))
                    {
                        sw.Write(data);
                    }
                }
            }
        }

        public static void CreateDirectory(string dir)
        {
            using (var isf =
                IsolatedStorageFile.GetUserStoreForApplication())
            {
                isf.CreateDirectory(dir);
            }
        }

        public static string LoadData(string fileName)
        {
            using (var isf =
                IsolatedStorageFile.GetUserStoreForApplication())
            {
                using (var isfs =
                    new IsolatedStorageFileStream(
                        fileName, FileMode.Open, isf))
                {
                    using (var sr = new StreamReader(isfs))
                    {
                        return sr.ReadToEnd();
                    }
                }
            }
        }
    }
}
