﻿using System;
using System.Collections.Generic;
using System.IO.IsolatedStorage;
using System.Linq;
using System.Net;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace SilverlightApplication63
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            using (var store = IsolatedStorageFile.GetUserStoreForApplication())
            {
                int spaceneed = 1024 * 1024 * 5;
                if (store.AvailableFreeSpace < spaceneed)
                {
                    if (store.IncreaseQuotaTo(store.Quota + spaceneed))
                    {
                        MessageBox.Show("User Has approved the quota Increase");
                        MessageBox.Show(store.AvailableFreeSpace.ToString());
                    }
                    else
                    {
                        MessageBox.Show("User Has Not Approved the quota Increase ");
                        MessageBox.Show(store.AvailableFreeSpace.ToString());
                    }
                }
            }
        }
    }
}
