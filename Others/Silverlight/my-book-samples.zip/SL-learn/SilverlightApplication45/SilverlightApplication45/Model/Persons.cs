﻿using System.Collections.ObjectModel;

namespace SilverlightApplication45.Model
{
    public class Persons : ObservableCollection<Person>
    {
    }
}
