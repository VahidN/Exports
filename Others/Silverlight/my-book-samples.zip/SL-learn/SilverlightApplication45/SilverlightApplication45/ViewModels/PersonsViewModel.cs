﻿using System.Windows.Input;
using SilverlightApplication45.Helper;
using SilverlightApplication45.Model;

namespace SilverlightApplication45.ViewModels
{
    public class PersonsViewModel
    {
        public ICommand AddDataCommand { get; set; }

        public Person EnteredData { set; get; }

        public Persons Persons { set; get; }
        public PersonsViewModel()
        {
            Persons = new Persons
                          {
                              new Person
                                  {
                                      FirstName = "Albert",
                                      LastName = "Einstein",
                                  },
                              new Person
                                  {
                                      FirstName = "Marie",
                                      LastName = "Curie "
                                  }
                          };

            AddDataCommand = new DelegateCommand<Person>(addData, canAddData);
            EnteredData = new Person();
        }

        private bool canAddData(Person enteredPerson)
        {
            return enteredPerson != null;
        }

        private void addData(Person enteredPerson)
        {
            if (enteredPerson == null) return;
            Persons.Add(new Person
                            {
                                FirstName = enteredPerson.FirstName,
                                LastName = enteredPerson.LastName
                            });
        }
    }
}
