﻿using System;
using System.Windows;
using System.Windows.Controls;

namespace SilverlightApplication19
{
    public class CircularPanel : Panel
    {
        protected override Size MeasureOverride(Size availableSize)
        {
            // called by parent element
            // our opportunity to measure our children
            foreach (UIElement elem in Children)
            {
                elem.Measure(new Size(
                    double.PositiveInfinity, 
                    double.PositiveInfinity));
            }
            return base.MeasureOverride(availableSize);
        }

        protected override Size ArrangeOverride(Size finalSize)
        {
            // called by our parent element
            // our opportunity to arrange our children
            if (Children.Count == 0)

                return finalSize;

            double angle = 0;

            //Degrees converted to Radian by multiplying with PI/180
            double angularCounter = (360.0 / Children.Count) * (Math.PI / 180);

            // hacky way to find radiuses (radii?)
            double radiusX = finalSize.Width / 2.4;
            double radiusY = finalSize.Height / 2.4;

            foreach (UIElement elem in Children)
            {
                // position each child
                var childPoint = new Point(
                    Math.Cos(angle) * radiusX, 
                    -Math.Sin(angle) * radiusY);
                var actualChildPoint = new Point(
                    finalSize.Width / 2 + childPoint.X - elem.DesiredSize.Width / 2, 
                    finalSize.Height / 2 + childPoint.Y - elem.DesiredSize.Height / 2);

                elem.Arrange(new Rect(
                    actualChildPoint.X, 
                    actualChildPoint.Y, 
                    elem.DesiredSize.Width, 
                    elem.DesiredSize.Height));

                angle += angularCounter;
            }

            return finalSize;
        }
    }
}
