﻿using System.Windows;
using System.Windows.Controls;

namespace SilverlightApplication19
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            circPanel.Children.Add(new Button { Content = "Button" });
        }
    }
}
