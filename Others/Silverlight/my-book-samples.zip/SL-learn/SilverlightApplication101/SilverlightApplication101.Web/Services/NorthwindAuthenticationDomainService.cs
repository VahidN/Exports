﻿using System;
using System.Security.Principal;
using System.ServiceModel.DomainServices.Hosting;
using System.ServiceModel.DomainServices.Server.ApplicationServices;
using System.Web;
using System.Web.Security;

namespace SilverlightApplication101.Web.Services
{
    [EnableClientAccess]
    public class NorthwindAuthenticationDomainService : AuthenticationBase<User>
    {
        protected override bool ValidateUser(
            string userName, string password)
        {
            if (string.IsNullOrWhiteSpace(userName))
                return false;

            if (userName == password)
            {
                //todo: read from db...
                return true;
            }

            return false;
        }

        protected override void IssueAuthenticationToken(
            IPrincipal principal, bool isPersistent)
        {
            //using named parameters of C# 4.0
            var ticket = new FormsAuthenticationTicket
                (
                  version: 1,
                  name: principal.Identity.Name,
                  issueDate: DateTime.Now,
                //todo: read it from config...
                  expiration: DateTime.Now.AddMonths(1),
                  isPersistent: true,
                  userData: string.Empty,
                  cookiePath: FormsAuthentication.FormsCookiePath
                );

            string encryptedTicket = FormsAuthentication.Encrypt(ticket);

            var cookie = new HttpCookie(
                            FormsAuthentication.FormsCookieName,
                            encryptedTicket)
                             {
                                 Expires = DateTime.Now.AddMinutes(30)
                             };

            HttpContext.Current.Response.Cookies.Add(cookie);
        }

        protected override User GetAuthenticatedUser(IPrincipal principal)
        {
            return new User
                       {
                           EmployeeId = principal.Identity.Name,
                           Name = principal.Identity.Name,
                           Roles = MyRoleManager.GetRoles(
                                    principal.Identity.Name)
                       };
        }
    }

    public class User : UserBase
    {
        public string EmployeeId { get; set; }
    }

    public class MyRoleManager
    {
        public static string[] GetRoles(string userName)
        {
            //todo: read from db...
            return new[] { "Reader" };
        }
    }
}