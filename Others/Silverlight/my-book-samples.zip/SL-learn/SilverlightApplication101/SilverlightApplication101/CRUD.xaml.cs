﻿using System.ComponentModel;
using System.Windows;
using System.Windows.Controls;

namespace SilverlightApplication101
{
    public partial class CRUD
    {
        public CRUD()
        {
            InitializeComponent();
            this.Loaded += crudLoaded;
        }

        void crudLoaded(object sender, RoutedEventArgs e)
        {
            productDomainDataSource.SubmittedChanges +=
                productDomainDataSource_SubmittedChanges;
        }

        static void productDomainDataSource_SubmittedChanges(
            object sender, SubmittedChangesEventArgs e)
        {
            if (e.HasError)
            {
                MessageBox.Show(e.Error.ToString(),
                    "SubmittedChanges Error", MessageBoxButton.OK);
                e.MarkErrorAsHandled();
            }
            else
            {
                MessageBox.Show("Submitted!");
            }
        }

        private void productDomainDataSource_LoadedData(object sender,
            LoadedDataEventArgs e)
        {
            if (e.HasError)
            {
                MessageBox.Show(e.Error.ToString(),
                    "Load Error", MessageBoxButton.OK);
                e.MarkErrorAsHandled();
            }
        }

        private void dataForm1_EditEnded(object sender,
            DataFormEditEndedEventArgs e)
        {
            if (e.EditAction != DataFormEditAction.Commit)
                return;

            //save to db (add new item / edit current item)
            if (!productDomainDataSource.IsSubmittingChanges &&
                productDomainDataSource.HasChanges)
            {
                productDomainDataSource.SubmitChanges();
            }
        }

        private void dataForm1_DeletingItem(object sender,
            CancelEventArgs e)
        {
            var res = MessageBox.Show("Do you want to delete this item?",
                "DeletingItem",
                MessageBoxButton.OKCancel);
            if (res == MessageBoxResult.Cancel)
            {
                e.Cancel = true;
                return;
            }

            if (productDomainDataSource.DataView.CanRemove)
            {
                var currentItem = productDomainDataSource.DataView.CurrentItem;
                productDomainDataSource.DataView.Remove(currentItem);
                productDomainDataSource.SubmitChanges();
            }
        }

        private void dataForm1_AddingNewItem(object sender,
            DataFormAddingNewItemEventArgs e)
        {
            //save to db
            if (productDomainDataSource.DataView.CanAdd &&
                productDomainDataSource.HasChanges)
            {
                productDomainDataSource.SubmitChanges();
            }
        }
    }
}
