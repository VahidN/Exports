﻿using System.ServiceModel.DomainServices.Client.ApplicationServices;
using System.Windows;

namespace SilverlightApplication101
{
    public partial class ChildLoginWindow
    {
        public ChildLoginWindow()
        {
            InitializeComponent();
        }

        private void OKButton_Click(object sender, RoutedEventArgs e)
        {
            var lp = new LoginParameters(UserName.Text, Password.Password);
            WebContext.Current.Authentication.Login(
                lp, 
                this.loginOperationCompleted, 
                null);
            LoginResult.Text = "";
            OKButton.IsEnabled = false;
        }

        private void loginOperationCompleted(LoginOperation lo)
        {
            if (lo.HasError)
            {
                LoginResult.Text = lo.Error.Message;
                lo.MarkErrorAsHandled();
                OKButton.IsEnabled = true;
            }
            else if (!lo.LoginSuccess)
            {
                LoginResult.Text = "Login failed. Please check user name and password.";
                OKButton.IsEnabled = true;
            }
            else if (lo.LoginSuccess)
            {
                //refresh user state
                //WebContext.Current.Authentication.LoadUser();

                this.DialogResult = true;
                this.Close();
            }
        }

        private void CancelButton_Click(object sender, RoutedEventArgs e)
        {
            this.DialogResult = false;
        }
    }
}

