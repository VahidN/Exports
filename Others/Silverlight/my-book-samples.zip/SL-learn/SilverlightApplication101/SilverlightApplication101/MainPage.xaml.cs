﻿using System.Windows;
using System.Windows.Controls;

namespace SilverlightApplication101
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
            //this.Loaded += mainPageLoaded;
        }

        void mainPageLoaded(object sender, RoutedEventArgs e)
        {
            /*var ctx = new NorthwindDomainContext();
            ctx.Load(ctx.GetProductsQuery());
            dataGrid1.ItemsSource = ctx.Products;*/
        }

        private void productDomainDataSource_LoadedData(object sender, 
            LoadedDataEventArgs e)
        {
            if (e.HasError)
            {
                MessageBox.Show(e.Error.ToString(), "Load Error", MessageBoxButton.OK);
                e.MarkErrorAsHandled();
            }
        }
    }
}
