﻿using System;
using System.ServiceModel.DomainServices.Client.ApplicationServices;
using System.Windows;

namespace SilverlightApplication101
{
    public partial class TestFormsAuth
    {
        public TestFormsAuth()
        {
            InitializeComponent();
            this.Loaded += TestFormsAuth_Loaded;
        }

        void TestFormsAuth_Loaded(object sender, RoutedEventArgs e)
        {
            if(!WebContext.Current.User.IsAuthenticated)
            {
                btnLogin_Click(this, null);
            }
        }

        private void btnLogin_Click(object sender, RoutedEventArgs e)
        {
            var loginForm = new ChildLoginWindow();
            loginForm.Closed += loginForm_Closed;
            loginForm.Show();
        }

        private void loginForm_Closed(object sender, EventArgs e)
        {
            txtUserName.Text = string.Empty;

            var dialog = sender as ChildLoginWindow;
            if (dialog == null) return;
            if (dialog.DialogResult == true) //if OK ...
            {
                txtUserName.Text = WebContext.Current.User.Name;
                userInfoPanel.Visibility = Visibility.Visible;

                if (WebContext.Current.User.IsInRole("Managers"))
                {
                    //do something ...
                }
            }
            else
            {
                userInfoPanel.Visibility = Visibility.Collapsed;
            }
        }

        private void btnLogout_Click(object sender, RoutedEventArgs e)
        {
            WebContext.Current.Authentication.Logout(
                this.LogoutOperation_Completed,
                null);
        }

        private void LogoutOperation_Completed(LogoutOperation lo)
        {
            if (!lo.HasError)
            {
                userInfoPanel.Visibility = Visibility.Collapsed;
            }
            else
            {
                //Logout failed.
                lo.MarkErrorAsHandled();
            }
        }
    }
}
