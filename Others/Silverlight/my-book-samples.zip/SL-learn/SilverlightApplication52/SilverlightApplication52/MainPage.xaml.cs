﻿namespace SilverlightApplication52
{
    public partial class MainPage
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
