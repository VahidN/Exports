﻿using SilverlightApplication52.ViewModels;

namespace SilverlightApplication52.Views
{
    public partial class DragDrop
    {
        public DragDrop()
        {
            InitializeComponent();

            this.DataContext = new DragDropViewModel();
        }
    }
}
