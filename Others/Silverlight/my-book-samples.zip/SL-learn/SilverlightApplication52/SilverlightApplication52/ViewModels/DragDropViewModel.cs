﻿using System.Collections.ObjectModel;
using System.IO;
using System.Linq;
using System.Windows;
using System.Windows.Shapes;
using GalaSoft.MvvmLight.Command;
using SilverlightApplication52.Models;

namespace SilverlightApplication52.ViewModels
{
    public class DragDropViewModel
    {
        public ObservableCollection<FileData> FilesList { get; private set; }

        public RelayCommand<DragEventArgs> DropCommand { get; private set; }

        public DragDropViewModel()
        {
            DropCommand = new RelayCommand<DragEventArgs>(dropped);
            FilesList = new ObservableCollection<FileData>();
        }

        private void dropped(DragEventArgs e)
        {
            if (e.Data == null) return;

            var files = e.Data.GetData(DataFormats.FileDrop) as FileInfo[];
            if (files == null) return;

            foreach (var file in files)
            {
                var fileData = new FileData
                {
                    Name = file.Name,
                    Length = file.Length 
                };

                var any = FilesList.FirstOrDefault(
                    x => x.Length == fileData.Length 
                        && x.Name == fileData.Name);
                if (any == null) FilesList.Add(fileData);
            }
        }
    }
}
