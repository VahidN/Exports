﻿namespace SilverlightApplication52.Models
{
    public class FileData
    {
        public string Name { set; get; }
        public long Length { set; get; }
    }
}
