﻿using System.Windows;

namespace SilverlightApplication39
{
    public partial class NewPage
    {
        public NewPage()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            App.ChangePage(new MainPage());
        }
    }
}
