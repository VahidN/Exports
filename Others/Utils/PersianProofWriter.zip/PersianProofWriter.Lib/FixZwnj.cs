﻿using System.Text.RegularExpressions;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Puts zwnj char/half space between word and prefix/suffix
    /// </summary>
    public static class FixZwnj
    {
        //from: https://github.com/aziz/virastar

        /// <summary>
        /// Adds zwnj char between word and prefix/suffix
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ApplyHalfSpaceRule(this string text)
        {
            //put zwnj between word and prefix (mi* nemi*)
            var phase1 = Regex.Replace(text, @"\s+(ن?می)\s+", @" $1‌");

            //put zwnj between word and suffix (*tar *tarin *ha *haye)
            var phase2 = Regex.Replace(phase1, @"\s+(تر(ی(ن)?)?|ها(ی)?)\s+", @"‌$1 ");

            return phase2;
        }

        /// <summary>
        /// Removes unnecessary zwnj char that are succeeded/preceded by a space
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string CleanupZwnj(this string text)
        {
            return Regex.Replace(text, @"\s+‌|‌\s+", " ");
        }
    }
}
