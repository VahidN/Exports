﻿using System.Text.RegularExpressions;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Replaces more than one ! or ? marks with just one or removes all extra kashida and spaces
    /// </summary>
    public static class AggressiveEditing
    {
        //from: https://github.com/aziz/virastar

        /// <summary>
        /// Replaces more than one ! or ? mark with just one
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string CleanupExtraMarks(this string text)
        {
            var phase1 = Regex.Replace(text, @"(!){2,}", "$1");
            var phase2 = Regex.Replace(phase1, "(؟){2,}", "$1");
            return phase2;
        }

        /// <summary>
        /// Removes all kashida
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string RemoveAllKashida(this string text)
        {
            return Regex.Replace(text, "ـ+", "");
        }

        /// <summary>
        /// Replaces more than one space or line break with just a single one
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string CleanupSpacingAndLineBreaks(this string text)
        {
            var phase1 = Regex.Replace(text, @"[ ]+", " ");
            var phase2 = Regex.Replace(phase1, "([\n]+)[   ‌]*", "$1");
            return phase2.Trim();
        }

        /// <summary>
        /// Fixes outside and inside spacing for () [] {}  “” «»
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string RemoveOutsideInsideSpacing(this string text)
        {
            //should fix outside and inside spacing for () [] {}  “” «»
            var phase1 = Regex.Replace(text, @"[   ‌]*(\()\s*([^)]+?)\s*?(\))[   ‌]*", " $1$2$3 ");
            var phase2 = Regex.Replace(phase1, @"[   ‌]*(\[)\s*([^)]+?)\s*?(\])[   ‌]*", " $1$2$3 ");
            var phase3 = Regex.Replace(phase2, @"[   ‌]*(\{)\s*([^)]+?)\s*?(\})[   ‌]*", " $1$2$3 ");
            var phase4 = Regex.Replace(phase3, @"[   ‌]*(“)\s*([^)]+?)\s*?(”)[   ‌]*", " $1$2$3 ");
            var phase5 = Regex.Replace(phase4, @"[   ‌]*(«)\s*([^)]+?)\s*?(»)[   ‌]*", " $1$2$3 ");

            // : ; , . ! ? and their persian equivalents should have one space after and no space before
            var phase6 = Regex.Replace(phase5, @"[ ?  ]*([:;,??.?!]{1})[ ?  ]*", "$1 ");

            // do not put space after colon that separates time parts
            var phase7 = Regex.Replace(phase6, @"([0-9]+):\s+([0-9]+)", "$1:$2");

            //should fix inside spacing for () [] {}  “” «»
            var phase8 = Regex.Replace(phase7, @"(\()\s*([^)]+?)\s*?(\))", "$1$2$3");
            var phase9 = Regex.Replace(phase8, @"(\[)\s*([^)]+?)\s*?(\])", "$1$2$3");
            var phase10 = Regex.Replace(phase9, @"(\{)\s*([^)]+?)\s*?(\})", "$1$2$3");
            var phase11 = Regex.Replace(phase10, @"(“)\s*([^)]+?)\s*?(”)", "$1$2$3");
            var phase12 = Regex.Replace(phase11, @"(«)\s*([^)]+?)\s*?(»)", "$1$2$3");

            return phase12.Trim();
        }
    }
}
