﻿// ndoc-style namespace documentation
namespace PersianProofWriter.Lib
{
    /// <summary>    
    /// The <see cref="PersianProofWriter.Lib"/> namespace contains classes for cleaning up Persian text!
    /// </summary>
    [System.Runtime.CompilerServices.CompilerGenerated]
    class NamespaceDoc
    {
    }
}
