﻿using System.Text.RegularExpressions;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Determines whether the current language is Persian or not
    /// </summary>
    public static class LanguageIdentifier
    {
        /// <summary>
        /// Does text contain Persian characters?
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>true/false</returns>
        public static bool ContainsFarsi(this string text)
        {
            return Regex.IsMatch(text, @"[\u0600-\u06FF]");
        }
    }
}
