﻿using System.Text.RegularExpressions;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Replaces three dots with ellipsis
    /// </summary>
    public static class FixDots
    {
        //from: https://github.com/aziz/virastar

        /// <summary>
        /// Replaces three dots with ellipsis
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ConvertDotsToEllipsis(this string text)
        {
            return Regex.Replace(text, @"\s*\.{3,}", @"…");
        }
    }
}
