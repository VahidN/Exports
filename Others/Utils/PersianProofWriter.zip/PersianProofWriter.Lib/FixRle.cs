﻿using System;
using System.Text;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// RLE or U+202B is the RIGHT-TO-LEFT EMBEDDING character
    /// http://www.w3.org/International/questions/qa-bidi-controls
    /// </summary>
    public static class FixRle
    {
        /// <summary>
        /// Makes the text inside right-to-left by surrounding it with RLE
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ApplyRle(this string text)
        {
            var newContent = new StringBuilder();
            const char RLEChar = (char)0x202B;

            text = text.Replace(RLEChar, '\0');

            var lines = text.Trim().Split('\n');            
            foreach (var line in lines)
            {
                if (line.ContainsFarsi())
                    newContent.AppendFormat("{0}{1}{2}", RLEChar, line.Trim(), Environment.NewLine);
                else
                    newContent.AppendFormat("{0}{1}", line.Trim(), Environment.NewLine);
            }

            return newContent.ToString().Trim();
        }
    }
}
