﻿using System.Text.RegularExpressions;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Converts ه ی to ه
    /// </summary>
    public static class FixHamzeh
    {
        //from: https://github.com/aziz/virastar

        /// <summary>
        /// Converts ه ی to ه
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ConvertYeHeToHamzeh(this string text)
        {
            return Regex.Replace(text, @"(\S)(ه[\s‌]+[یي])(\s)", "$1هٔ$3");
        }
    }
}
