﻿using System.Text.RegularExpressions;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Replaces English quotes with their Persian equivalent
    /// </summary>
    public static class FixEnglishQuotes
    {
        //from: https://github.com/aziz/virastar

        /// <summary>
        /// Replaces English quotes with their Persian equivalent
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ConvertEnglishQuotes(this string text)
        {
            return Regex.Replace(text, @"([""'`]+)(.+?)(\1)", @"«$2»");
        }
    }
}
