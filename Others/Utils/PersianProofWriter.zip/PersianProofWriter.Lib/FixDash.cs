﻿using System.Text.RegularExpressions;

namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Replaces double dash to ndash and triple dash to mdash
    /// </summary>
    public static class FixDash
    {
        //from: https://github.com/aziz/virastar

        /// <summary>
        /// Replaces double dash to ndash and triple dash to mdash
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string FixDashes(this string text)
        {
            var phase1 = Regex.Replace(text, @"-{3}", @"—");
            var phase2 = Regex.Replace(phase1, @"-{2}", @"–");
            return phase2;
        }
    }
}
