﻿namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Main entry point of the library
    /// </summary>
    public static class ProofWriter
    {
        /// <summary>
        /// Applies all of the available rules of the current library
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ApplyAllPersianRules(this string text)
        {
            if (string.IsNullOrEmpty(text))
                return string.Empty;

            if (!text.ContainsFarsi())
                return text;

            return text.ApplyPersianYeKe()
                       .ApplyHalfSpaceRule()
                       .FixDashes()
                       .ConvertDotsToEllipsis()
                       .ConvertEnglishQuotes()
                       .ConvertYeHeToHamzeh()
                       .CleanupZwnj()
                       .CleanupExtraMarks()
                       .RemoveAllKashida()
                       .CleanupSpacingAndLineBreaks()
                       .RemoveOutsideInsideSpacing();
        }

        /// <summary>
        /// Applies all of the available rules of the current library plus adding RLE char
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ApplyAllPersianRulesPlusRle(this string text)
        {
            return text.ApplyAllPersianRules().ApplyRle();
        }
    }
}
