﻿
namespace PersianProofWriter.Lib
{
    /// <summary>
    /// Fixes common writing mistakes caused by using a bad keyboard layout.
    /// </summary>
    public static class FixArabicYeKe
    {
        //from: http://www.idevcenter.com/wiki/fix_persian_string_function

        /// <summary>
        /// Fixes common writing mistakes caused by using a bad keyboard layout,
        /// such as replacing Arabic Ye with Persian one and so on ...
        /// </summary>
        /// <param name="text">Text to process</param>
        /// <returns>Processed Text</returns>
        public static string ApplyPersianYeKe(this string text)
        {
            return 
                text.Replace("\u0660", "\u06F0") // ۰
                    .Replace("\u0661", "\u06F1") // ۱
                    .Replace("\u0662", "\u06F2") // ۲
                    .Replace("\u0663", "\u06F3") // ۳
                    .Replace("\u0664", "\u06F4") // ۴
                    .Replace("\u0665", "\u06F5") // ۵
                    .Replace("\u0666", "\u06F6") // ۶
                    .Replace("\u0667", "\u06F7") // ۷
                    .Replace("\u0668", "\u06F8") // ۸
                    .Replace("\u0669", "\u06F9") // ۹
                    .Replace("\u0643", "\u06A9") // ک
                    .Replace("\u0649", "\u06CC") // ی
                    .Replace("\u064A", "\u06CC") // ی
                    .Replace("\u06C0", "\u0647\u0654"); // هٔ
        }
    }
}
