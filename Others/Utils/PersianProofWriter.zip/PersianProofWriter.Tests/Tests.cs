﻿using NUnit.Framework;
using PersianProofWriter.Lib;

namespace PersianProofWriter.Tests
{
    [TestFixture]
    public class Tests
    {
        [Test]
        public void ApplyHalfSpaceRule_Should_Put_Zwnj_Between_Word_And_Prefix_Suffix()
        {
            var test = "ما می توانیم";
            var result = "ما می‌توانیم";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test2 = "ما نمی توانیم";
            var result2 = "ما نمی‌توانیم";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());

            var test3 = "این بهترین کتاب ها است";
            var result3 = "این بهترین کتاب‌ها است";
            Assert.AreEqual(result3, test3.ApplyAllPersianRules());

            var test4 = "بزرگ تری و قدرتمند ترین زبان های دنیا";
            var result4 = "بزرگ‌تری و قدرتمند‌ترین زبان‌های دنیا";
            Assert.AreEqual(result4, test4.ApplyAllPersianRules());
        }

        [Test]
        public void ApplyPersianYeKe_Should_Replace_Arabic_Kaf_Yeh_With_Its_Persian_Equivalent()
        {
            var test = "ك";
            var result = "ک";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test2 = "كمك";
            var result2 = "کمک";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());

            var test3 = "ي";
            var result3 = "ی";
            Assert.AreEqual(result3, test3.ApplyAllPersianRules());

            var test4 = "بيني";
            var result4 = "بینی";
            Assert.AreEqual(result4, test4.ApplyAllPersianRules());
        }

        [Test]
        public void ApplyPersianYeKe_Should_Replace_Arabic_Numbers_With_Their_Persian_Equivalent()
        {
            var test = "٠١٢٣٤٥٦٧٨٩";
            var result = "۰۱۲۳۴۵۶۷۸۹";
            Assert.AreEqual(result, test.ApplyAllPersianRules());
        }

        [Test]
        public void FixDashes_Should_Replace_Double_Dash_To_Ndash_And_Triple_Dash_To_Mdash()
        {
            var test = "آزمون--";
            var result = "آزمون–";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test2 = "آزمون---";
            var result2 = "آزمون—";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());
        }

        [Test]
        public void ConvertDotsToEllipsis_Should_Replace_Three_Dots_With_Ellipsis()
        {
            var test = "آزمون...";
            var result = "آزمون…";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test2 = "آزمون....";
            var result2 = "آزمون…";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());

            var test3 = "خداحافظ ... به به";
            var result3 = "خداحافظ… به به";
            Assert.AreEqual(result3, test3.ApplyAllPersianRules());

            var test4 = "آزمون.........";
            var result4 = "آزمون…";
            Assert.AreEqual(result4, test4.ApplyAllPersianRules());
        }

        [Test]
        public void ConvertEnglishQuotes_Should_Replace_English_Quotes_With_Their_Persian_Equivalent()
        {
            var test2 = "'تست'";
            var result2 = "«تست»";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());

            var test = "''تست''";
            var result = "«تست»";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test4 = "`تست`";
            var result4 = "«تست»";
            Assert.AreEqual(result4, test4.ApplyAllPersianRules());

            var test5 = "``تست``";
            var result5 = "«تست»";
            Assert.AreEqual(result5, test5.ApplyAllPersianRules());

            var test3 = "\"گفت: سلام\"";
            var result3 = "«گفت: سلام»";
            Assert.AreEqual(result3, test3.ApplyAllPersianRules());

            var test6 = @"""آزمون"" or ""آزمون""";
            var result6 = "«آزمون» or «آزمون»";
            Assert.AreEqual(result6, test6.ApplyAllPersianRules());
        }

        [Test]
        public void ConvertYeHe_Should_Display_Hamzeh()
        {
            var test = "خانه ی ما";
            var result = "خانهٔ ما";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test2 = "خانه ی ما";
            var result2 = "خانهٔ ما";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());

            var test3 = "خانه ي ما";
            var result3 = "خانهٔ ما";
            Assert.AreEqual(result3, test3.ApplyAllPersianRules());
        }

        [Test]
        public void CleanupZwnj_Should_Remove_Unnecessary_Zwnj_Chars_That_Are_Succeeded_Preceded_By_A_Space()
        {
            var test = "سلام‌ دنیا";// before space
            var result = "سلام دنیا";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test2 = "سلام ‌دنیا"; //after space
            var result2 = "سلام دنیا";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());
        }

        [Test]
        public void CleanupExtraMarks_Should_Work()
        {
            var test = "سلام!!!";
            var result = "سلام!";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test2 = "چطور؟؟؟";
            var result2 = "چطور؟";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());
        }

        [Test]
        public void RemoveAllKashida_Should_Work()
        {
            var test = "سلامـــت";
            var result = "سلامت";
            Assert.AreEqual(result, test.ApplyAllPersianRules());
        }

        [Test]
        public void CleanupSpacingAndLineBreaks_Should_Work()
        {
            var test = "  سلام   world!  I'm virastar   ";
            var result = "سلام world! I'm virastar";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            var test1 = "this is \n \n \n     \n a آزمون";
            var result1 = "this is \n\n\n\na آزمون";
            Assert.AreEqual(result1, test1.ApplyAllPersianRules());

            var test3 = "this is\n\n\n\na آزمون";
            var result3 = "this is\n\n\n\na آزمون";
            Assert.AreEqual(result3, test3.ApplyAllPersianRules());

            var test4 = "this is \n\n\n    a آزمون";
            var result4 = "this is \n\n\na آزمون";
            Assert.AreEqual(result4, test4.ApplyAllPersianRules());

            var test5 = "this is \n  a آزمون";
            var result5 = "this is \na آزمون";
            Assert.AreEqual(result5, test5.ApplyAllPersianRules());
        }

        [Test]
        public void RemoveOutsideInsideSpacing_Should_Work()
        {
            //should not put space after time colon separator
            var test = "ساعت 12:34";
            var result = "ساعت 12:34";
            Assert.AreEqual(result, test.ApplyAllPersianRules());

            //no space before ":"
            var test1 = "گفت : سلام";
            var result1 = "گفت: سلام";
            Assert.AreEqual(result1, test1.ApplyAllPersianRules());

            //one space after "."
            var test2 = "سلام.\n\nkhoobi";
            var result2 = "سلام. \n\nkhoobi";
            Assert.AreEqual(result2, test2.ApplyAllPersianRules());

            //should fix spacing for () [] {}  “” «» (one space outside, no space inside)
            var test3 = "انجام   «   آزمون   »  ";
            var result3 = "انجام «آزمون»";
            Assert.AreEqual(result3, test3.ApplyAllPersianRules());
        }
    }
}
