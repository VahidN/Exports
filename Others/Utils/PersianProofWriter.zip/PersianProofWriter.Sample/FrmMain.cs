﻿using System;
using System.Windows.Forms;
using PersianProofWriter.Lib;

namespace PersianProofWriter.Sample
{
    public partial class FrmMain : Form
    {
        public FrmMain()
        {
            InitializeComponent();
        }

        private void btnRun_Click(object sender, EventArgs e)
        {
            txtDest.Text = txtSrc.Text.ApplyAllPersianRules();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtDest.Text = string.Empty;
            txtSrc.Text = string.Empty;
        }
    }
}
