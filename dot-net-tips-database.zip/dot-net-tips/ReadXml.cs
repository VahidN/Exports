using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Xml;
using System.Xml.Serialization;

namespace LoadSiteXml
{
    [DebuggerDisplay("{FriendlyName}")]
    public class User
    {
        public int? Id { set; get; } //کاربران عضو نشده هم می‌توانند کامنت ارسال کنند
        public string FriendlyName { set; get; }
		
        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 23 + (Id.HasValue ? this.Id.Value.GetHashCode() : 0);
                hash = hash * 23 + this.FriendlyName.GetHashCode();
                return hash;
            }
        }

        public override bool Equals(object obj)
        {
            if (obj == null)
                return false;

            var user = obj as User;
            if (user == null)
                return false;

            if (!this.Id.HasValue || !user.Id.HasValue)
                return false;

            return this.Id.Value == user.Id.Value && this.FriendlyName == user.FriendlyName;
        }		
    }

    [DebuggerDisplay("{Title}")]
    public class Post
    {
        public int Id { set; get; }
        public string Title { set; get; }
        public string Body { set; get; }
        public DateTime CreatedOn { set; get; }
        public List<Tag> Tags { set; get; }
        public User User { set; get; }
        public List<Comment> Comments { set; get; }
		
        public int CommentsCount
        {
            get 
            {
                if (Comments == null || !Comments.Any())
                    return 0;
                return Comments.Count;
            }
        }		
    }

    [DebuggerDisplay("{Name}")]
    public class Tag
    {
        public int Id { set; get; }
        public string Name { set; get; }
		
        public override int GetHashCode()
        {
            unchecked
            {
                int hash = 17;
                hash = hash * 23 + this.Id.GetHashCode();
                hash = hash * 23 + this.Name.GetHashCode();
                return hash;
            }
        }

        public override bool Equals(object obj)
        {
            if (obj == null) 
                return false;

            var tag = obj as Tag;
            if (tag == null) 
                return false;

            return this.Id == tag.Id && this.Name == tag.Name;
        }		
    }

    [DebuggerDisplay("{Body}")]
    public class Comment
    {
        public int Id { set; get; }
        public int? ReplyToId { set; get; } //شیء خود ارجاع دهنده است
        public string Body { set; get; }
        public DateTime CreatedOn { set; get; }
        public User User { set; get; }
    }

    public static class ReadXml
    {
        /// <summary>
        /// فایل اکس ام ال بانک اطلاعاتی سایت را بارگذاری می‌کند
        /// </summary>
        /// <param name="xmlFilePath">مسیر و نام فایل اکس ام ال</param>
        /// <returns>لیست مطالب و نظرات آن‌ها</returns>
        public static IList<Post> LoadDatabase(string xmlFilePath)
        {
            using (var xmlReader = new XmlTextReader(xmlFilePath))
            {
                var serializer = new XmlSerializer(typeof(List<Post>));
                return (List<Post>)serializer.Deserialize(xmlReader);
            }
        }
    }
}